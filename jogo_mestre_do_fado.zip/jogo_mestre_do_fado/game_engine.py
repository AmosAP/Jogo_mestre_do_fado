import pygame
import os

class SpriteSheet:
    def __init__(self, filename):
        """Carrega a imagem do spritesheet"""
        try:
            self.sheet = pygame.image.load(filename).convert_alpha()
        except pygame.error as e:
            print(f"Não foi possível carregar o spritesheet: {filename}")
            raise SystemExit(e)

    def image_at(self, rectangle, colorkey=None):
        """Carrega uma imagem específica do spritesheet"""
        rect = pygame.Rect(rectangle)
        image = pygame.Surface(rect.size, pygame.SRCALPHA)
        image.blit(self.sheet, (0, 0), rect)
        
        if colorkey is not None:
            if colorkey == -1:
                colorkey = image.get_at((0, 0))
            image.set_colorkey(colorkey, pygame.RLEACCEL)
            
        return image

    def images_at(self, rects, colorkey=None):
        """Carrega múltiplas imagens do spritesheet"""
        return [self.image_at(rect, colorkey) for rect in rects]

    def load_strip(self, rect, image_count, colorkey=None):
        """Carrega uma tira de imagens e retorna como uma lista"""
        tups = [(rect[0] + rect[2] * x, rect[1], rect[2], rect[3])
                for x in range(image_count)]
        return self.images_at(tups, colorkey)

class Animation:
    def __init__(self, frames, frame_duration=100):
        """Inicializa uma animação com frames e duração"""
        self.frames = frames
        self.frame_duration = frame_duration
        self.current_frame = 0
        self.last_update = 0
        self.finished = False
        
    def update(self, current_time):
        """Atualiza o frame atual baseado no tempo"""
        if current_time - self.last_update > self.frame_duration:
            self.current_frame = (self.current_frame + 1) % len(self.frames)
            self.last_update = current_time
            
            # Se chegou ao último frame, marca como finalizado
            if self.current_frame == 0:
                self.finished = True
            else:
                self.finished = False
                
        return self.frames[self.current_frame]
    
    def reset(self):
        """Reinicia a animação"""
        self.current_frame = 0
        self.finished = False

class AnimationManager:
    def __init__(self):
        """Gerencia múltiplas animações para um personagem"""
        self.animations = {}
        self.current_animation = None
        
    def add_animation(self, name, animation):
        """Adiciona uma nova animação"""
        self.animations[name] = animation
        if self.current_animation is None:
            self.current_animation = name
            
    def set_animation(self, name):
        """Muda para uma animação específica"""
        if name in self.animations and name != self.current_animation:
            self.animations[self.current_animation].reset()
            self.current_animation = name
            
    def update(self, current_time):
        """Atualiza a animação atual"""
        if self.current_animation:
            return self.animations[self.current_animation].update(current_time)
        return None

class Character(pygame.sprite.Sprite):
    def __init__(self, x, y, width, height):
        super().__init__()
        self.rect = pygame.Rect(x, y, width, height)
        self.animation_manager = AnimationManager()
        self.direction = "right"  # Direção padrão
        self.speed = 5
        self.is_moving = False
        
    def update(self, current_time):
        """Atualiza o personagem"""
        # Determina qual animação usar baseado no estado
        animation_key = "idle"
        if self.is_moving:
            animation_key = f"walk_{self.direction}"
            
        self.animation_manager.set_animation(animation_key)
        self.image = self.animation_manager.update(current_time)
        
    def move(self, dx, dy):
        """Move o personagem"""
        self.rect.x += dx * self.speed
        self.rect.y += dy * self.speed
        
        # Atualiza a direção baseada no movimento
        if dx > 0:
            self.direction = "right"
        elif dx < 0:
            self.direction = "left"
            
        self.is_moving = dx != 0 or dy != 0

class Player(Character):
    def __init__(self, x, y):
        super().__init__(x, y, 64, 96)
        self.load_animations()
        self.guitar_level = 1
        self.reputation = 0
        self.known_songs = []
        
    def load_animations(self):
        """Carrega as animações do jogador"""
        # Placeholder para quando tivermos os sprites reais
        # Por enquanto, criamos superfícies coloridas
        idle_frames = [self.create_placeholder_frame((0, 0, 255))]
        walk_right_frames = [
            self.create_placeholder_frame((0, 0, 200)),
            self.create_placeholder_frame((0, 0, 220))
        ]
        walk_left_frames = [
            self.create_placeholder_frame((0, 0, 200)),
            self.create_placeholder_frame((0, 0, 220))
        ]
        
        self.animation_manager.add_animation("idle", Animation(idle_frames, 200))
        self.animation_manager.add_animation("walk_right", Animation(walk_right_frames, 200))
        self.animation_manager.add_animation("walk_left", Animation(walk_left_frames, 200))
        
    def create_placeholder_frame(self, color):
        """Cria um frame placeholder para testes"""
        surface = pygame.Surface((64, 96), pygame.SRCALPHA)
        pygame.draw.rect(surface, color, (0, 0, 64, 96))
        pygame.draw.rect(surface, (255, 255, 255), (0, 0, 64, 96), 2)  # Borda branca
        return surface
        
    def learn_song(self, song):
        """Adiciona uma música ao repertório do jogador"""
        if song not in self.known_songs:
            self.known_songs.append(song)
            print(f"Aprendeu a música: {song}")
            
    def increase_guitar_level(self):
        """Aumenta o nível de habilidade com a guitarra"""
        self.guitar_level += 1
        print(f"Nível de guitarra aumentado para {self.guitar_level}")
        
    def increase_reputation(self, amount):
        """Aumenta a reputação do jogador"""
        self.reputation += amount
        print(f"Reputação aumentada para {self.reputation}")

class NPC(Character):
    def __init__(self, x, y, name, dialogue_data):
        super().__init__(x, y, 64, 96)
        self.name = name
        self.dialogue_data = dialogue_data
        self.interaction_rect = pygame.Rect(x - 20, y - 20, 104, 136)  # Área maior que o NPC
        self.load_animations()
        
    def load_animations(self):
        """Carrega as animações do NPC"""
        # Placeholder para quando tivermos os sprites reais
        # Cada NPC terá uma cor diferente para identificação
        if self.name == "Ana":
            color = (255, 0, 0)  # Vermelho para Ana
        elif self.name == "Mestre António":
            color = (150, 75, 0)  # Marrom para Mestre António
        else:
            color = (0, 255, 0)  # Verde para outros NPCs
            
        idle_frames = [self.create_placeholder_frame(color)]
        
        self.animation_manager.add_animation("idle", Animation(idle_frames, 200))
        
    def create_placeholder_frame(self, color):
        """Cria um frame placeholder para testes"""
        surface = pygame.Surface((64, 96), pygame.SRCALPHA)
        pygame.draw.rect(surface, color, (0, 0, 64, 96))
        pygame.draw.rect(surface, (255, 255, 255), (0, 0, 64, 96), 2)  # Borda branca
        
        # Adicionar texto com o nome do NPC
        font = pygame.font.Font(None, 20)
        text = font.render(self.name, True, (255, 255, 255))
        text_rect = text.get_rect(center=(32, 20))
        surface.blit(text, text_rect)
        
        return surface
        
    def update_interaction_rect(self):
        """Atualiza o retângulo de interação para seguir o NPC"""
        self.interaction_rect.x = self.rect.x - 20
        self.interaction_rect.y = self.rect.y - 20

class Scene:
    def __init__(self, name, background_image=None):
        self.name = name
        self.background_image = background_image
        self.npcs = pygame.sprite.Group()
        self.objects = pygame.sprite.Group()
        self.exits = []  # Lista de áreas que levam a outras cenas
        
    def add_npc(self, npc):
        """Adiciona um NPC à cena"""
        self.npcs.add(npc)
        
    def add_object(self, obj):
        """Adiciona um objeto interativo à cena"""
        self.objects.add(obj)
        
    def add_exit(self, rect, target_scene, target_position):
        """Adiciona uma saída para outra cena"""
        self.exits.append({
            "rect": rect,
            "target_scene": target_scene,
            "target_position": target_position
        })
        
    def update(self, current_time):
        """Atualiza todos os elementos da cena"""
        for npc in self.npcs:
            npc.update(current_time)
            npc.update_interaction_rect()
            
        for obj in self.objects:
            obj.update(current_time)
            
    def render(self, surface):
        """Renderiza a cena"""
        # Desenha o fundo
        if self.background_image:
            surface.blit(self.background_image, (0, 0))
        else:
            # Fundo padrão se não houver imagem
            surface.fill((200, 200, 200))
            
        # Desenha NPCs
        self.npcs.draw(surface)
        
        # Desenha objetos
        self.objects.draw(surface)
        
        # DEBUG: Desenha áreas de saída
        for exit in self.exits:
            pygame.draw.rect(surface, (255, 0, 0), exit["rect"], 2)

class SceneManager:
    def __init__(self):
        self.scenes = {}
        self.current_scene = None
        
    def add_scene(self, scene):
        """Adiciona uma cena ao gerenciador"""
        self.scenes[scene.name] = scene
        if self.current_scene is None:
            self.current_scene = scene.name
            
    def change_scene(self, scene_name, player_position=None):
        """Muda para uma cena específica"""
        if scene_name in self.scenes:
            self.current_scene = scene_name
            return True
        return False
        
    def get_current_scene(self):
        """Retorna a cena atual"""
        return self.scenes.get(self.current_scene)
        
    def update(self, current_time):
        """Atualiza a cena atual"""
        scene = self.get_current_scene()
        if scene:
            scene.update(current_time)
            
    def render(self, surface):
        """Renderiza a cena atual"""
        scene = self.get_current_scene()
        if scene:
            scene.render(surface)

class RhythmNote(pygame.sprite.Sprite):
    def __init__(self, x, lane, speed, note_type="normal"):
        super().__init__()
        self.lane = lane
        self.speed = speed
        self.note_type = note_type
        
        # Posição inicial
        self.x = x
        self.y = 0
        
        # Criar imagem baseada no tipo de nota
        self.create_image()
        
        # Configurar retângulo
        self.rect = self.image.get_rect()
        self.rect.centerx = self.x
        self.rect.y = self.y
        
    def create_image(self):
        """Cria a imagem da nota baseada no tipo"""
        if self.note_type == "normal":
            color = (0, 0, 255)  # Azul para notas normais
        elif self.note_type == "hold":
            color = (0, 255, 0)  # Verde para notas de segurar
        elif self.note_type == "special":
            color = (255, 215, 0)  # Dourado para notas especiais
        else:
            color = (255, 0, 0)  # Vermelho para outros tipos
            
        self.image = pygame.Surface((50, 20), pygame.SRCALPHA)
        pygame.draw.rect(self.image, color, (0, 0, 50, 20), border_radius=5)
        pygame.draw.rect(self.image, (255, 255, 255), (0, 0, 50, 20), 2, border_radius=5)
        
    def update(self):
        """Atualiza a posição da nota"""
        self.y += self.speed
        self.rect.y = int(self.y)
        
        # Retorna True se a nota saiu da tela
        return self.rect.y > 800

class RhythmGame:
    def __init__(self, screen_width, screen_height):
        self.screen_width = screen_width
        self.screen_height = screen_height
        self.notes = pygame.sprite.Group()
        self.target_line_y = screen_height - 100
        self.lanes = 4
        self.lane_width = screen_width // self.lanes
        self.score = 0
        self.combo = 0
        self.max_combo = 0
        self.song = None
        self.song_position = 0
        self.note_speed = 5
        self.hit_window = 30  # Janela de tempo para acertar uma nota
        self.hit_animations = []
        self.last_spawn_time = 0
        self.spawn_interval = 1000  # ms entre notas (será substituído pelo padrão da música)
        
    def start_song(self, song_name, difficulty="normal"):
        """Inicia uma música"""
        self.song = song_name
        self.score = 0
        self.combo = 0
        self.max_combo = 0
        self.song_position = 0
        self.notes.empty()
        self.hit_animations = []
        
        # Ajusta a velocidade e intervalo baseado na dificuldade
        if difficulty == "easy":
            self.note_speed = 3
            self.hit_window = 40
        elif difficulty == "normal":
            self.note_speed = 5
            self.hit_window = 30
        elif difficulty == "hard":
            self.note_speed = 7
            self.hit_window = 20
            
        # Aqui carregaríamos o padrão de notas da música
        # Por enquanto, usamos um padrão aleatório para teste
        self.last_spawn_time = pygame.time.get_ticks()
        
    def spawn_note(self, current_time):
        """Gera uma nova nota baseada no padrão da música"""
        # Verifica se é hora de gerar uma nova nota
        if current_time - self.last_spawn_time > self.spawn_interval:
            # Escolhe uma pista aleatória para teste
            lane = pygame.time.get_ticks() % self.lanes
            
            # Calcula a posição X baseada na pista
            x = (lane + 0.5) * self.lane_width
            
            # Cria a nota
            note = RhythmNote(x, lane, self.note_speed)
            self.notes.add(note)
            
            # Atualiza o tempo da última geração
            self.last_spawn_time = current_time
            
            # Varia o intervalo para tornar mais interessante
            self.spawn_interval = 500 + (pygame.time.get_ticks() % 500)
        
    def update(self, current_time):
        """Atualiza o estado do jogo de ritmo"""
        # Gera novas notas
        self.spawn_note(current_time)
        
        # Atualiza as notas existentes
        for note in list(self.notes):
            if note.update():
                # Se a nota saiu da tela, remove e quebra o combo
                self.notes.remove(note)
                self.combo = 0
                
        # Atualiza animações de acerto
        self.hit_animations = [anim for anim in self.hit_animations if current_time - anim["time"] < 500]
        
    def render(self, surface):
        """Renderiza o jogo de ritmo"""
        # Desenha fundo
        surface.fill((0, 0, 0))
        
        # Desenha linhas de pista
        for i in range(self.lanes + 1):
            x = i * self.lane_width
            pygame.draw.line(surface, (50, 50, 50), (x, 0), (x, self.screen_height), 2)
            
        # Desenha linha alvo
        pygame.draw.line(surface, (255, 255, 255), (0, self.target_line_y), 
                         (self.screen_width, self.target_line_y), 3)
                         
        # Desenha marcadores de pista na linha alvo
        for i in range(self.lanes):
            x = (i + 0.5) * self.lane_width
            pygame.draw.circle(surface, (100, 100, 100), (int(x), self.target_line_y), 25)
            
            # Desenha letra da tecla
            font = pygame.font.Font(None, 24)
            key_letter = ["A", "S", "D", "F"][i]
            text = font.render(key_letter, True, (255, 255, 255))
            text_rect = text.get_rect(center=(int(x), self.target_line_y))
            surface.blit(text, text_rect)
        
        # Desenha notas
        self.notes.draw(surface)
        
        # Desenha animações de acerto
        for anim in self.hit_animations:
            alpha = 255 - int(255 * (pygame.time.get_ticks() - anim["time"]) / 500)
            text = anim["text"]
            text.set_alpha(alpha)
            surface.blit(text, anim["pos"])
        
        # Desenha pontuação e combo
        font = pygame.font.Font(None, 36)
        score_text = font.render(f"Pontuação: {self.score}", True, (255, 255, 255))
        combo_text = font.render(f"Combo: {self.combo}x", True, (255, 255, 255))
        
        surface.blit(score_text, (20, 20))
        surface.blit(combo_text, (20, 60))
        
    def check_hit(self, lane):
        """Verifica se o jogador acertou uma nota"""
        hit_note = None
        hit_distance = float('inf')
        
        # Procura a nota mais próxima da linha alvo na pista especificada
        for note in self.notes:
            if note.lane == lane:
                distance = abs(note.rect.centery - self.target_line_y)
                if distance < self.hit_window and distance < hit_distance:
                    hit_note = note
                    hit_distance = distance
        
        if hit_note:
            # Calcula pontuação baseada na precisão
            if hit_distance < self.hit_window * 0.3:
                points = 100
                rating = "Perfeito!"
                color = (255, 215, 0)  # Dourado
            elif hit_distance < self.hit_window * 0.6:
                points = 50
                rating = "Bom!"
                color = (0, 255, 0)  # Verde
            else:
                points = 10
                rating = "Ok"
                color = (0, 0, 255)  # Azul
                
            # Adiciona pontos e aumenta combo
            self.score += points * (1 + self.combo * 0.1)  # Bônus de combo
            self.combo += 1
            
            if self.combo > self.max_combo:
                self.max_combo = self.combo
                
            # Cria animação de acerto
            font = pygame.font.Font(None, 24)
            text = font.render(rating, True, color)
            x = (lane + 0.5) * self.lane_width
            pos = text.get_rect(center=(int(x), self.target_line_y - 30))
            
            self.hit_animations.append({
                "text": text,
                "pos": pos,
                "time": pygame.time.get_ticks()
            })
            
            # Remove a nota acertada
            self.notes.remove(hit_note)
            return True
            
        return False
