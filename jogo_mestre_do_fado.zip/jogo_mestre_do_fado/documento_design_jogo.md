# Documento de Design do Jogo "O Mestre do Fado"

## Visão Geral
"O Mestre do Fado" é um jogo 2D que mergulha os jogadores na rica cultura portuguesa, com foco especial na tradição do fado e na cultura alentejana. O jogo combina elementos de aventura, ritmo musical e narrativa para criar uma experiência autêntica e envolvente que celebra o patrimônio cultural português.

## Narrativa e Enredo

### Premissa
O jogador assume o papel de Miguel, um jovem músico do interior do Alentejo que sonha em se tornar um grande mestre do fado. Após herdar uma antiga guitarra portuguesa de seu avô, Miguel decide viajar por Portugal para aprender os segredos do fado, aperfeiçoar suas habilidades musicais e eventualmente se apresentar nas mais prestigiadas casas de fado de Lisboa.

### Arco Narrativo Principal
1. **Origem**: Miguel descobre a guitarra portuguesa de seu avô em um velho baú junto com um mapa incompleto que indica locais importantes para a história do fado.
2. **Jornada**: Miguel viaja pelo Alentejo e outras regiões de Portugal, conhecendo mestres do fado e do cante alentejano, aprendendo novas técnicas e músicas.
3. **Desafios**: Durante sua jornada, Miguel enfrenta desafios musicais, resolve quebra-cabeças culturais e ajuda pessoas locais com suas habilidades musicais.
4. **Crescimento**: À medida que avança, Miguel não apenas melhora suas habilidades técnicas, mas também aprende sobre a profunda conexão emocional e cultural do fado.
5. **Clímax**: Miguel finalmente chega a Lisboa, onde deve provar seu valor como fadista em uma série de apresentações culminando em uma performance na mais prestigiada casa de fado da cidade.

### Temas
- Busca por identidade e raízes culturais
- Preservação de tradições em um mundo moderno
- A música como forma de expressão emocional e conexão humana
- A jornada do herói através da paisagem cultural portuguesa

## Personagens

### Protagonista
- **Miguel**: Jovem alentejano com talento natural para música, determinado a se tornar um mestre do fado. Inicialmente conhece apenas o cante alentejano, mas gradualmente aprende a tocar guitarra portuguesa e a cantar fado.

### Personagens Secundários
- **Ana**: Jovem fadista de Lisboa que se torna mentora e possível interesse romântico de Miguel.
- **Mestre António**: Velho construtor de guitarras portuguesas que ajuda Miguel a restaurar e compreender o instrumento de seu avô.
- **Tia Joaquina**: Tia de Miguel, conhecedora do cante alentejano, que incentiva sua jornada.
- **Grupo de Cantadores**: Grupo de cantores tradicionais do Alentejo que aparecem em momentos-chave para ajudar Miguel.
- **Rivais**: Outros fadistas que competem com Miguel em diversos desafios musicais.
- **Personagens Históricos**: Aparições de figuras históricas do fado como Amália Rodrigues, Maria Severa e Carlos Paredes (como "espíritos" ou em sonhos).

## Mecânicas de Jogo

### Mecânicas Principais

1. **Sistema de Ritmo Musical**
   - Minijogos baseados em ritmo onde o jogador deve pressionar botões no tempo certo para tocar guitarra portuguesa ou cantar.
   - Diferentes padrões rítmicos representam diferentes estilos de fado (Lisboa, Coimbra) e cante alentejano.
   - A precisão do jogador afeta a qualidade da performance e a reação do público.

2. **Sistema de Exploração**
   - Navegação em ambientes 2D com vista lateral ou superior.
   - Interação com personagens e objetos do cenário.
   - Descoberta de locais históricos e culturais relacionados ao fado e à cultura alentejana.

3. **Sistema de Diálogos e Escolhas**
   - Conversas com NPCs que revelam histórias, dicas e missões.
   - Escolhas de diálogo que afetam a relação com outros personagens e o desenvolvimento da história.
   - Opções de resposta que refletem o conhecimento crescente de Miguel sobre o fado e a cultura portuguesa.

4. **Sistema de Progressão**
   - **Habilidades Musicais**: O jogador desbloqueia novas técnicas de guitarra e canto ao longo do jogo.
   - **Repertório**: Coleta de partituras e letras de fados tradicionais que podem ser executados em performances.
   - **Reputação**: A fama de Miguel aumenta conforme ele completa desafios e impressiona personagens importantes.
   - **Equipamento**: Melhoria da guitarra portuguesa e aquisição de trajes tradicionais que oferecem bônus em performances.

5. **Missões e Desafios**
   - **Missões Principais**: Seguem o arco narrativo principal da jornada de Miguel.
   - **Missões Secundárias**: Ajudar personagens locais, descobrir histórias sobre o fado, participar em festivais tradicionais.
   - **Desafios Musicais**: Competições contra outros músicos, apresentações improvisadas, duetos com mestres.
   - **Quebra-cabeças Culturais**: Resolver enigmas baseados em conhecimentos sobre a cultura portuguesa e alentejana.

### Mecânicas Secundárias

1. **Composição Musical**
   - Sistema simplificado que permite ao jogador criar suas próprias melodias combinando elementos musicais desbloqueados.
   - As composições podem ser usadas em performances especiais para impressionar o público.

2. **Colecionáveis Culturais**
   - Itens relacionados à cultura portuguesa espalhados pelo mundo do jogo.
   - Cada item coletado adiciona entradas a uma enciclopédia cultural in-game.

3. **Sistema de Dia e Noite**
   - Ciclo que afeta quais personagens estão disponíveis e quais eventos ocorrem.
   - Performances de fado tipicamente acontecem à noite em ambientes específicos.

4. **Mini-jogos Culturais**
   - Atividades baseadas em tradições portuguesas como colheita de azeitonas, produção de vinho, tecelagem de mantas alentejanas.
   - Cada mini-jogo oferece recompensas e aprofunda a imersão cultural.

## Ambientes e Cenários

### Locais Principais

1. **Aldeia Natal (Alentejo)**
   - Pequena aldeia alentejana com casas brancas, praça central e igreja.
   - Campos de cereais e montados de sobreiros nos arredores.
   - Taberna local onde acontecem sessões de cante alentejano.

2. **Évora**
   - Centro histórico com templo romano, catedral e praça do Giraldo.
   - Oficina de Mestre António onde Miguel aprende sobre a guitarra portuguesa.
   - Universidade onde estudantes praticam o fado de Coimbra.

3. **Costa Alentejana**
   - Vilas piscatórias onde Miguel aprende fados relacionados ao mar.
   - Praias e falésias que inspiram composições musicais.

4. **Coimbra**
   - Universidade histórica onde Miguel aprende o estilo de fado de Coimbra.
   - Ponte sobre o rio Mondego onde acontecem serenatas estudantis.

5. **Lisboa**
   - Bairros históricos de Alfama, Mouraria e Bairro Alto.
   - Casas de fado tradicionais onde acontecem os desafios finais.
   - Miradouros com vista para o Tejo que servem como pontos de reflexão.

### Ambientes Secundários
- Vinhas e adegas do Alentejo
- Oficinas de artesãos tradicionais
- Festivais populares em várias localidades
- Estações de trem que conectam as diferentes regiões
- Ruínas megalíticas do Alentejo

## Estilo Visual e Sonoro

### Estilo Visual
- Arte 2D com estilo pictórico inspirado em azulejos portugueses e arte folclórica.
- Paleta de cores vibrante que reflete as diferentes regiões de Portugal:
  - Tons terrosos e dourados para o Alentejo
  - Azuis e brancos para Lisboa e áreas costeiras
  - Verdes e amarelos para regiões mais ao norte
- Animações fluidas para as performances musicais e expressões emocionais dos personagens.
- Interface inspirada em motivos decorativos portugueses.

### Estilo Sonoro
- Banda sonora original que incorpora elementos do fado, cante alentejano e música folclórica portuguesa.
- Gravações autênticas de fados tradicionais que são desbloqueadas ao longo do jogo.
- Efeitos sonoros ambientais que capturam a atmosfera de cada região (mar, campo, cidade).
- Vozes para diálogos importantes com sotaques regionais autênticos.

## Fluxo de Jogo

### Tutorial
- Introdução à história de Miguel e à mecânica básica de jogo na aldeia natal.
- Primeiras lições de cante alentejano com a Tia Joaquina.
- Descoberta da guitarra portuguesa e do mapa do avô.

### Progressão
- Estrutura em capítulos que seguem a jornada de Miguel por diferentes regiões.
- Cada região apresenta novos desafios, personagens e estilos musicais.
- Dificuldade crescente nos desafios musicais e quebra-cabeças.
- Pontos de decisão que podem alterar ligeiramente o rumo da história.

### Final
- Confronto final em Lisboa com uma série de performances desafiadoras.
- Múltiplos finais possíveis dependendo das escolhas do jogador e do nível de maestria alcançado.
- Epílogo que mostra o impacto da jornada de Miguel na preservação e divulgação do fado.

## Plataformas e Controles

### Plataformas Alvo
- PC (Windows, Mac)
- Consoles (PlayStation, Xbox, Nintendo Switch)
- Dispositivos móveis (versão simplificada)

### Controles
- **PC**: Teclado e mouse, suporte para controladores
- **Consoles**: Controladores nativos
- **Móveis**: Controles de toque otimizados

## Monetização e Expansão

### Modelo Base
- Jogo completo com preço único
- Possíveis DLCs futuros explorando outras regiões de Portugal ou aprofundando aspectos específicos da cultura portuguesa

### Conteúdo Adicional Potencial
- Novos personagens e histórias
- Estilos musicais adicionais de outras regiões portuguesas
- Modos de jogo extras (modo compositor, modo performance livre)
- Colaborações com artistas de fado contemporâneos

## Mensagem Cultural

"O Mestre do Fado" não é apenas um jogo de entretenimento, mas também uma ferramenta educativa que:
- Preserva e divulga o patrimônio cultural português
- Ensina aos jogadores sobre a história e importância do fado e do cante alentejano
- Promove o turismo cultural em Portugal
- Cria uma ponte entre tradições antigas e público contemporâneo
- Celebra a riqueza e diversidade da cultura portuguesa

Este documento de design serve como base para o desenvolvimento do jogo "O Mestre do Fado", estabelecendo sua visão criativa, mecânicas e elementos narrativos fundamentais. O desenvolvimento subsequente expandirá estes conceitos em um produto final que honra e celebra a rica tradição cultural portuguesa.
