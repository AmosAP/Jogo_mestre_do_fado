from PIL import Image, ImageDraw, ImageFont
import os

# Criar diretório para salvar as imagens se não existir
output_dir = "/home/ubuntu/jogo_mestre_do_fado/designs"
os.makedirs(output_dir, exist_ok=True)

# Configurações da imagem
width, height = 800, 1000
background_color = (255, 255, 255)
outline_color = (0, 0, 0)

# Cores para o cenário
sky_color = (180, 220, 255)  # Céu azul claro
mountain_color = (150, 130, 100)  # Montanhas em tons terrosos
field_color = (220, 200, 120)  # Campos em tons dourados
cork_tree_color = (100, 80, 60)  # Sobreiros em marrom
cork_tree_top_color = (80, 120, 80)  # Copa dos sobreiros em verde escuro
house_color = (250, 250, 250)  # Casas brancas típicas alentejanas
roof_color = (180, 100, 80)  # Telhados em terracota
road_color = (200, 180, 160)  # Estrada de terra

# Criar uma nova imagem com fundo branco
image = Image.new("RGB", (width, height), background_color)
draw = ImageDraw.Draw(image)

# Desenhar título
try:
    font = ImageFont.truetype("arial.ttf", 36)
except IOError:
    font = ImageFont.load_default()

draw.text((width//2 - 200, 30), "Aldeia Alentejana - Cenário", fill=(0, 0, 0), font=font)
draw.text((width//2 - 200, 80), "O Mestre do Fado - Concept Art", fill=(100, 100, 100), font=font)

# Desenhar o cenário
# Céu
draw.rectangle((0, 120, width, 400), fill=sky_color, outline=sky_color)

# Montanhas ao fundo
draw.polygon([(0, 400), (200, 300), (350, 350), (500, 280), (650, 330), (800, 310), (800, 400)], 
             fill=mountain_color, outline=mountain_color)

# Campos de cereais (planície alentejana)
draw.rectangle((0, 400, width, 600), fill=field_color, outline=field_color)

# Estrada de terra
draw.polygon([(300, 600), (350, 400), (450, 400), (500, 600)], fill=road_color, outline=outline_color, width=1)

# Sobreiros (árvores típicas do montado alentejano)
# Sobreiro 1
draw.rectangle((100, 450, 130, 520), fill=cork_tree_color, outline=outline_color, width=2)  # Tronco
draw.ellipse((70, 400, 160, 470), fill=cork_tree_top_color, outline=outline_color, width=2)  # Copa

# Sobreiro 2
draw.rectangle((650, 470, 680, 540), fill=cork_tree_color, outline=outline_color, width=2)  # Tronco
draw.ellipse((620, 420, 710, 490), fill=cork_tree_top_color, outline=outline_color, width=2)  # Copa

# Sobreiro 3
draw.rectangle((200, 480, 220, 530), fill=cork_tree_color, outline=outline_color, width=2)  # Tronco
draw.ellipse((180, 450, 240, 500), fill=cork_tree_top_color, outline=outline_color, width=2)  # Copa

# Aldeia alentejana
# Casa principal
draw.rectangle((400, 500, 550, 600), fill=house_color, outline=outline_color, width=2)  # Estrutura principal
draw.polygon([(390, 500), (560, 500), (475, 450)], fill=roof_color, outline=outline_color, width=2)  # Telhado
draw.rectangle((440, 550, 480, 600), fill=(150, 100, 50), outline=outline_color, width=2)  # Porta
draw.rectangle((420, 520, 450, 550), fill=(200, 230, 255), outline=outline_color, width=2)  # Janela
draw.rectangle((500, 520, 530, 550), fill=(200, 230, 255), outline=outline_color, width=2)  # Janela

# Casa secundária
draw.rectangle((580, 520, 680, 600), fill=house_color, outline=outline_color, width=2)  # Estrutura principal
draw.polygon([(570, 520), (690, 520), (630, 480)], fill=roof_color, outline=outline_color, width=2)  # Telhado
draw.rectangle((620, 560, 640, 600), fill=(150, 100, 50), outline=outline_color, width=2)  # Porta
draw.rectangle((590, 540, 610, 560), fill=(200, 230, 255), outline=outline_color, width=2)  # Janela

# Igreja (elemento típico das aldeias alentejanas)
draw.rectangle((250, 480, 320, 600), fill=house_color, outline=outline_color, width=2)  # Estrutura principal
draw.rectangle((270, 450, 300, 480), fill=house_color, outline=outline_color, width=2)  # Torre
draw.polygon([(270, 450), (300, 450), (285, 420)], fill=roof_color, outline=outline_color, width=2)  # Topo da torre
draw.rectangle((280, 560, 300, 600), fill=(150, 100, 50), outline=outline_color, width=2)  # Porta
draw.ellipse((280, 500, 300, 520), fill=(200, 230, 255), outline=outline_color, width=2)  # Janela redonda

# Detalhes adicionais
# Cercado para animais
draw.rectangle((150, 550, 200, 600), fill=(200, 180, 150), outline=outline_color, width=2)
for i in range(150, 200, 10):
    draw.line([(i, 550), (i, 600)], fill=outline_color, width=1)

# Poço tradicional
draw.rectangle((350, 550, 370, 580), fill=(150, 150, 150), outline=outline_color, width=2)
draw.arc((340, 530, 380, 550), 0, 180, fill=outline_color, width=2)
draw.line([(340, 540), (380, 540)], fill=outline_color, width=2)

# Sol
draw.ellipse((650, 150, 700, 200), fill=(255, 240, 120), outline=(255, 200, 80), width=2)
for i in range(8):
    angle = i * 45
    x1 = 675 + 30 * (angle % 90 == 0)
    y1 = 175 + 30 * (angle % 90 != 0)
    x2 = 675 + 50 * (angle % 90 == 0)
    y2 = 175 + 50 * (angle % 90 != 0)
    draw.line([(x1, y1), (x2, y2)], fill=(255, 200, 80), width=2)

# Adicionar descrição
description = [
    "Aldeia Alentejana - Cenário Principal",
    "",
    "Características:",
    "- Paisagem típica do Alentejo com planícies douradas",
    "- Montado de sobreiros (ecossistema característico da região)",
    "- Casas brancas com telhados de terracota",
    "- Igreja central (elemento típico das aldeias alentejanas)",
    "- Estrada de terra que conecta a aldeia a outras localidades",
    "- Céu azul claro característico da região",
    "",
    "Elementos culturais:",
    "- Arquitetura tradicional alentejana",
    "- Paisagem rural preservada",
    "- Ambiente tranquilo que reflete o ritmo de vida mais lento da região",
    "- Local onde Miguel inicia sua jornada para se tornar mestre do fado"
]

y_pos = 650
for line in description:
    draw.text((50, y_pos), line, fill=(0, 0, 0))
    y_pos += 20

# Salvar a imagem
output_path = os.path.join(output_dir, "aldeia_alentejana.png")
image.save(output_path)
print(f"Imagem salva em: {output_path}")
