from PIL import Image, ImageDraw, ImageFont
import os

# Criar diretório para salvar as imagens se não existir
output_dir = "/home/ubuntu/jogo_mestre_do_fado/designs"
os.makedirs(output_dir, exist_ok=True)

# Configurações da imagem
width, height = 800, 1000
background_color = (255, 255, 255)
outline_color = (0, 0, 0)

# Cores para o cenário
sky_color = (100, 150, 200)  # Céu azul
water_color = (70, 130, 180)  # Água do rio Tejo
building_color = (250, 240, 230)  # Edifícios em tons claros
roof_color = (180, 100, 80)  # Telhados em terracota
street_color = (200, 200, 200)  # Ruas em cinza claro
hill_color = (180, 200, 150)  # Colinas em verde claro

# Criar uma nova imagem com fundo branco
image = Image.new("RGB", (width, height), background_color)
draw = ImageDraw.Draw(image)

# Desenhar título
try:
    font = ImageFont.truetype("arial.ttf", 36)
except IOError:
    font = ImageFont.load_default()

draw.text((width//2 - 200, 30), "Alfama - Lisboa", fill=(0, 0, 0), font=font)
draw.text((width//2 - 200, 80), "O Mestre do Fado - Concept Art", fill=(100, 100, 100), font=font)

# Desenhar o cenário
# Céu
draw.rectangle((0, 120, width, 350), fill=sky_color, outline=sky_color)

# Rio Tejo
draw.rectangle((0, 650, width, 750), fill=water_color, outline=water_color)
# Ondulações no rio
for i in range(0, width, 50):
    draw.arc((i, 640, i+100, 660), 0, 180, fill=(90, 150, 200), width=2)

# Colinas de Lisboa
draw.polygon([(0, 350), (200, 300), (400, 330), (600, 290), (800, 320), (800, 450), (0, 450)], 
             fill=hill_color, outline=hill_color)

# Ruas em ladeira (típicas de Alfama)
draw.polygon([(300, 450), (350, 650), (450, 650), (400, 450)], fill=street_color, outline=outline_color, width=1)
draw.polygon([(500, 450), (550, 650), (650, 650), (600, 450)], fill=street_color, outline=outline_color, width=1)

# Edifícios típicos de Alfama
# Fileira de edifícios à esquerda
for i in range(3):
    x = 100 + i*100
    y = 450 - i*20  # Cada edifício um pouco mais alto na colina
    height_var = 100 + i*20
    # Estrutura principal
    draw.rectangle((x, y, x+80, y+height_var), fill=building_color, outline=outline_color, width=2)
    # Telhado
    draw.polygon([(x-5, y), (x+85, y), (x+40, y-30)], fill=roof_color, outline=outline_color, width=2)
    # Janelas
    for j in range(2):
        for k in range(2):
            window_x = x + 15 + j*40
            window_y = y + 20 + k*40
            draw.rectangle((window_x, window_y, window_x+15, window_y+20), 
                          fill=(200, 230, 255), outline=outline_color, width=1)
    # Porta
    door_x = x + 30
    door_y = y + height_var - 30
    draw.rectangle((door_x, door_y, door_x+20, y+height_var), 
                  fill=(120, 80, 50), outline=outline_color, width=1)

# Fileira de edifícios à direita
for i in range(3):
    x = 500 + i*100
    y = 450 - i*20
    height_var = 100 + i*20
    # Estrutura principal
    draw.rectangle((x, y, x+80, y+height_var), fill=building_color, outline=outline_color, width=2)
    # Telhado
    draw.polygon([(x-5, y), (x+85, y), (x+40, y-30)], fill=roof_color, outline=outline_color, width=2)
    # Janelas
    for j in range(2):
        for k in range(2):
            window_x = x + 15 + j*40
            window_y = y + 20 + k*40
            draw.rectangle((window_x, window_y, window_x+15, window_y+20), 
                          fill=(200, 230, 255), outline=outline_color, width=1)
    # Porta
    door_x = x + 30
    door_y = y + height_var - 30
    draw.rectangle((door_x, door_y, door_x+20, y+height_var), 
                  fill=(120, 80, 50), outline=outline_color, width=1)

# Elétrico 28 (bonde icônico de Lisboa)
draw.rectangle((200, 600, 280, 630), fill=(255, 220, 0), outline=outline_color, width=2)
draw.rectangle((190, 580, 290, 600), fill=(255, 220, 0), outline=outline_color, width=2)
# Janelas do elétrico
for i in range(3):
    window_x = 210 + i*20
    draw.rectangle((window_x, 585, window_x+15, 595), 
                  fill=(200, 230, 255), outline=outline_color, width=1)
# Rodas
draw.ellipse((210, 625, 225, 640), fill=(50, 50, 50), outline=outline_color, width=1)
draw.ellipse((255, 625, 270, 640), fill=(50, 50, 50), outline=outline_color, width=1)

# Igreja com torre (elemento típico da paisagem de Lisboa)
draw.rectangle((350, 350, 450, 450), fill=building_color, outline=outline_color, width=2)
draw.polygon([(340, 350), (460, 350), (400, 320)], fill=roof_color, outline=outline_color, width=2)
# Torre da igreja
draw.rectangle((380, 300, 420, 350), fill=building_color, outline=outline_color, width=2)
draw.polygon([(375, 300), (425, 300), (400, 270)], fill=roof_color, outline=outline_color, width=2)
# Porta da igreja
draw.rectangle((390, 420, 410, 450), fill=(120, 80, 50), outline=outline_color, width=1)
# Janela redonda
draw.ellipse((390, 370, 410, 390), fill=(200, 230, 255), outline=outline_color, width=1)

# Varais com roupa estendida (elemento típico de Alfama)
for i in range(2):
    x = 150 + i*300
    y = 500
    # Varal
    draw.line([(x, y), (x+100, y)], fill=outline_color, width=2)
    # Roupas
    for j in range(5):
        cloth_x = x + j*20
        cloth_y = y
        cloth_color = [(255, 200, 200), (200, 200, 255), (255, 255, 200), 
                       (200, 255, 200), (255, 200, 255)][j % 5]
        draw.rectangle((cloth_x, cloth_y, cloth_x+15, cloth_y+20), 
                      fill=cloth_color, outline=outline_color, width=1)

# Barcos no Tejo
draw.polygon([(100, 680), (150, 680), (125, 650)], fill=(150, 100, 50), outline=outline_color, width=2)
draw.polygon([(600, 690), (670, 690), (635, 650)], fill=(100, 100, 150), outline=outline_color, width=2)

# Sol
draw.ellipse((650, 150, 700, 200), fill=(255, 240, 120), outline=(255, 200, 80), width=2)

# Adicionar descrição
description = [
    "Alfama - Bairro Histórico de Lisboa",
    "",
    "Características:",
    "- Bairro mais antigo de Lisboa, berço do fado",
    "- Ruas estreitas e íngremes em ladeira",
    "- Casas tradicionais com fachadas coloridas",
    "- Vista para o rio Tejo",
    "- Elétrico 28 (bonde icônico que percorre o bairro)",
    "- Varais com roupa estendida (elemento típico da paisagem)",
    "",
    "Elementos culturais:",
    "- Arquitetura tradicional portuguesa",
    "- Ambiente onde nasceu o fado lisboeta",
    "- Local onde se encontram muitas casas de fado",
    "- Cenário do clímax da jornada de Miguel"
]

y_pos = 770
for line in description:
    draw.text((50, y_pos), line, fill=(0, 0, 0))
    y_pos += 20

# Salvar a imagem
output_path = os.path.join(output_dir, "alfama_lisboa.png")
image.save(output_path)
print(f"Imagem salva em: {output_path}")
