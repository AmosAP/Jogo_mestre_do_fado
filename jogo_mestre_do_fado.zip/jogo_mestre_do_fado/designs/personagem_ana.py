from PIL import Image, ImageDraw, ImageFont
import os

# Criar diretório para salvar as imagens se não existir
output_dir = "/home/ubuntu/jogo_mestre_do_fado/designs"
os.makedirs(output_dir, exist_ok=True)

# Configurações da imagem
width, height = 800, 1000
background_color = (255, 255, 255)
outline_color = (0, 0, 0)
fill_color = (240, 230, 210)  # Cor de pele
hair_color = (150, 100, 50)  # Cabelo castanho claro
dress_color = (180, 30, 30)  # Vestido vermelho
shawl_color = (30, 30, 30)  # Xaile preto
skin_color = (240, 220, 200)  # Cor de pele

# Criar uma nova imagem com fundo branco
image = Image.new("RGB", (width, height), background_color)
draw = ImageDraw.Draw(image)

# Desenhar título
try:
    font = ImageFont.truetype("arial.ttf", 36)
except IOError:
    font = ImageFont.load_default()

draw.text((width//2 - 150, 30), "Ana - Fadista de Lisboa", fill=(0, 0, 0), font=font)
draw.text((width//2 - 200, 80), "O Mestre do Fado - Concept Art", fill=(100, 100, 100), font=font)

# Desenhar o personagem (estilo simplificado)
# Cabeça
draw.ellipse((300, 180, 500, 380), fill=fill_color, outline=outline_color, width=2)

# Cabelo
# Cabelo longo e ondulado
draw.ellipse((280, 180, 520, 320), fill=hair_color, outline=hair_color)
draw.rectangle((280, 250, 520, 380), fill=hair_color, outline=hair_color)
# Parte frontal do cabelo (franja)
draw.ellipse((300, 180, 500, 250), fill=fill_color, outline=fill_color)

# Olhos
draw.ellipse((350, 260, 380, 280), fill=(255, 255, 255), outline=outline_color, width=2)
draw.ellipse((420, 260, 450, 280), fill=(255, 255, 255), outline=outline_color, width=2)
draw.ellipse((360, 265, 370, 275), fill=(0, 0, 0))
draw.ellipse((430, 265, 440, 275), fill=(0, 0, 0))

# Sobrancelhas
draw.arc((345, 245, 385, 260), 0, 180, fill=outline_color, width=2)
draw.arc((415, 245, 455, 260), 0, 180, fill=outline_color, width=2)

# Nariz
draw.line([(400, 280), (390, 310), (400, 320)], fill=outline_color, width=2)

# Boca
draw.arc((370, 330, 430, 350), 0, 180, fill=(180, 30, 30), width=3)

# Pescoço
draw.rectangle((380, 380, 420, 420), fill=fill_color, outline=outline_color, width=2)

# Corpo
# Xaile tradicional preto (elemento típico das fadistas)
# Parte superior do xaile (ombros)
draw.ellipse((250, 400, 550, 500), fill=shawl_color, outline=outline_color, width=2)
# Parte que cai nas costas
draw.rectangle((250, 450, 550, 650), fill=shawl_color, outline=outline_color, width=2)

# Vestido vermelho (visível na parte inferior)
draw.rectangle((320, 500, 480, 800), fill=dress_color, outline=outline_color, width=2)

# Braços
# Braço esquerdo
draw.rectangle((280, 450, 320, 600), fill=skin_color, outline=outline_color, width=2)
# Mão esquerda
draw.ellipse((270, 580, 330, 620), fill=skin_color, outline=outline_color, width=2)

# Braço direito
draw.rectangle((480, 450, 520, 600), fill=skin_color, outline=outline_color, width=2)
# Mão direita
draw.ellipse((470, 580, 530, 620), fill=skin_color, outline=outline_color, width=2)

# Brincos tradicionais
draw.ellipse((290, 320, 310, 340), fill=(220, 220, 0), outline=outline_color, width=1)
draw.ellipse((490, 320, 510, 340), fill=(220, 220, 0), outline=outline_color, width=1)

# Colar de contas
for i in range(10):
    x = 350 + i*10
    draw.ellipse((x, 390, x+10, 400), fill=(220, 220, 0), outline=outline_color, width=1)

# Pés (sapatos pretos)
draw.ellipse((330, 780, 410, 820), fill=(0, 0, 0), outline=outline_color, width=2)
draw.ellipse((390, 780, 470, 820), fill=(0, 0, 0), outline=outline_color, width=2)

# Adicionar elementos decorativos típicos do fado
# Cravo vermelho no cabelo (símbolo associado ao fado)
draw.ellipse((480, 200, 510, 230), fill=(200, 0, 0), outline=outline_color, width=2)
draw.rectangle((490, 230, 500, 260), fill=(0, 100, 0), outline=(0, 100, 0))

# Adicionar descrição
description = [
    "Ana - Fadista de Lisboa",
    "",
    "Características:",
    "- Jovem fadista talentosa de Lisboa",
    "- Veste o tradicional xaile preto das fadistas",
    "- Vestido vermelho que representa a paixão do fado",
    "- Usa um cravo vermelho no cabelo (símbolo associado ao fado)",
    "- Expressão intensa e emocional, típica dos fadistas",
    "",
    "Personalidade:",
    "- Apaixonada e emotiva",
    "- Conhecedora profunda das tradições do fado",
    "- Orgulhosa de suas raízes lisboetas",
    "- Torna-se mentora e possível interesse romântico de Miguel"
]

y_pos = 840
for line in description:
    draw.text((50, y_pos), line, fill=(0, 0, 0))
    y_pos += 20

# Salvar a imagem
output_path = os.path.join(output_dir, "ana_fadista.png")
image.save(output_path)
print(f"Imagem salva em: {output_path}")
