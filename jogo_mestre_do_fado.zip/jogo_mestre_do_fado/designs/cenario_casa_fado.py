from PIL import Image, ImageDraw, ImageFont
import os

# Criar diretório para salvar as imagens se não existir
output_dir = "/home/ubuntu/jogo_mestre_do_fado/designs"
os.makedirs(output_dir, exist_ok=True)

# Configurações da imagem
width, height = 800, 1000
background_color = (255, 255, 255)
outline_color = (0, 0, 0)

# Cores para o cenário
wall_color = (240, 230, 220)  # Paredes em tom claro
floor_color = (180, 150, 120)  # Piso de madeira
wood_color = (150, 100, 50)  # Madeira para móveis
guitar_color = (180, 130, 80)  # Cor da guitarra portuguesa
light_color = (255, 240, 200)  # Luz amarelada
shadow_color = (100, 80, 60)  # Sombras

# Criar uma nova imagem com fundo branco
image = Image.new("RGB", (width, height), background_color)
draw = ImageDraw.Draw(image)

# Desenhar título
try:
    font = ImageFont.truetype("arial.ttf", 36)
except IOError:
    font = ImageFont.load_default()

draw.text((width//2 - 200, 30), "Casa de Fado - Cenário", fill=(0, 0, 0), font=font)
draw.text((width//2 - 200, 80), "O Mestre do Fado - Concept Art", fill=(100, 100, 100), font=font)

# Desenhar o cenário
# Paredes de fundo
draw.rectangle((50, 150, 750, 600), fill=wall_color, outline=outline_color, width=2)

# Piso
draw.rectangle((50, 600, 750, 750), fill=floor_color, outline=outline_color, width=2)
# Linhas do piso de madeira
for i in range(100, 750, 50):
    draw.line([(i, 600), (i, 750)], fill=(160, 130, 100), width=1)

# Arcos decorativos (típicos da arquitetura portuguesa)
draw.arc((100, 150, 300, 350), 0, 180, fill=outline_color, width=3)
draw.arc((300, 150, 500, 350), 0, 180, fill=outline_color, width=3)
draw.arc((500, 150, 700, 350), 0, 180, fill=outline_color, width=3)

# Azulejos decorativos (elemento típico português)
for i in range(3):
    x = 150 + i*200
    y = 250
    # Quadrado azul do azulejo
    draw.rectangle((x, y, x+100, y+100), fill=(230, 230, 255), outline=(0, 0, 150), width=2)
    # Padrão decorativo
    draw.line([(x+25, y+25), (x+75, y+75)], fill=(0, 0, 150), width=2)
    draw.line([(x+25, y+75), (x+75, y+25)], fill=(0, 0, 150), width=2)
    draw.ellipse((x+40, y+40, x+60, y+60), outline=(0, 0, 150), width=2)

# Mesa central redonda
draw.ellipse((300, 500, 500, 550), fill=wood_color, outline=outline_color, width=2)
# Pernas da mesa
draw.rectangle((380, 550, 400, 600), fill=wood_color, outline=outline_color, width=2)
draw.rectangle((400, 550, 420, 600), fill=wood_color, outline=outline_color, width=2)

# Cadeiras
# Cadeira 1
draw.rectangle((250, 520, 290, 530), fill=wood_color, outline=outline_color, width=2)  # Assento
draw.rectangle((260, 530, 270, 580), fill=wood_color, outline=outline_color, width=2)  # Perna 1
draw.rectangle((270, 530, 280, 580), fill=wood_color, outline=outline_color, width=2)  # Perna 2
draw.rectangle((250, 480, 290, 520), fill=wood_color, outline=outline_color, width=2)  # Encosto

# Cadeira 2
draw.rectangle((510, 520, 550, 530), fill=wood_color, outline=outline_color, width=2)  # Assento
draw.rectangle((520, 530, 530, 580), fill=wood_color, outline=outline_color, width=2)  # Perna 1
draw.rectangle((530, 530, 540, 580), fill=wood_color, outline=outline_color, width=2)  # Perna 2
draw.rectangle((510, 480, 550, 520), fill=wood_color, outline=outline_color, width=2)  # Encosto

# Palco pequeno
draw.rectangle((100, 550, 200, 600), fill=(120, 100, 80), outline=outline_color, width=2)

# Guitarras portuguesas penduradas na parede
# Guitarra 1
draw.ellipse((150, 350, 200, 400), fill=guitar_color, outline=outline_color, width=2)  # Corpo
draw.rectangle((170, 320, 180, 360), fill=guitar_color, outline=outline_color, width=2)  # Braço

# Guitarra 2
draw.ellipse((600, 350, 650, 400), fill=guitar_color, outline=outline_color, width=2)  # Corpo
draw.rectangle((620, 320, 630, 360), fill=guitar_color, outline=outline_color, width=2)  # Braço

# Candeeiro tradicional
draw.rectangle((380, 200, 420, 220), fill=(200, 200, 200), outline=outline_color, width=2)  # Base
draw.line([(400, 220), (400, 300)], fill=(200, 200, 200), width=3)  # Haste
draw.ellipse((370, 300, 430, 330), fill=light_color, outline=outline_color, width=2)  # Luz

# Efeito de luz no chão
draw.ellipse((350, 600, 450, 620), fill=(220, 200, 180), outline=(220, 200, 180))

# Sombras para dar profundidade
draw.rectangle((50, 600, 750, 610), fill=shadow_color, outline=shadow_color)

# Cartaz de fado na parede
draw.rectangle((650, 450, 700, 500), fill=(255, 240, 220), outline=outline_color, width=2)
draw.text((660, 460), "FADO", fill=(0, 0, 0))
draw.text((655, 480), "NOITE", fill=(0, 0, 0))

# Garrafa de vinho e copos na mesa (elementos típicos de uma casa de fado)
draw.rectangle((380, 480, 395, 510), fill=(100, 20, 20), outline=outline_color, width=1)  # Garrafa
draw.ellipse((375, 470, 400, 480), fill=(50, 50, 50), outline=outline_color, width=1)  # Gargalo
draw.ellipse((370, 510, 380, 520), fill=(200, 200, 200), outline=outline_color, width=1)  # Copo 1
draw.ellipse((400, 510, 410, 520), fill=(200, 200, 200), outline=outline_color, width=1)  # Copo 2

# Adicionar descrição
description = [
    "Casa de Fado - Cenário de Lisboa",
    "",
    "Características:",
    "- Interior de uma casa de fado tradicional de Lisboa",
    "- Paredes decoradas com azulejos portugueses",
    "- Arcos decorativos típicos da arquitetura portuguesa",
    "- Guitarras portuguesas penduradas nas paredes",
    "- Palco pequeno para apresentações de fadistas",
    "- Iluminação baixa e aconchegante, típica das casas de fado",
    "- Mesa com garrafa de vinho e copos (elementos tradicionais)",
    "",
    "Elementos culturais:",
    "- Ambiente íntimo e melancólico característico do fado",
    "- Decoração que reflete a tradição portuguesa",
    "- Local onde Miguel enfrentará seu desafio final como fadista",
    "- Representa o auge da jornada do protagonista"
]

y_pos = 770
for line in description:
    draw.text((50, y_pos), line, fill=(0, 0, 0))
    y_pos += 20

# Salvar a imagem
output_path = os.path.join(output_dir, "casa_de_fado.png")
image.save(output_path)
print(f"Imagem salva em: {output_path}")
