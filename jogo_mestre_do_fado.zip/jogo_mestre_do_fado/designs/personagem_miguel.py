from PIL import Image, ImageDraw, ImageFont
import os

# Criar diretório para salvar as imagens se não existir
output_dir = "/home/ubuntu/jogo_mestre_do_fado/designs"
os.makedirs(output_dir, exist_ok=True)

# Configurações da imagem
width, height = 800, 1000
background_color = (255, 255, 255)
outline_color = (0, 0, 0)
fill_color = (240, 230, 210)  # Cor de pele
hair_color = (50, 30, 10)  # Cabelo castanho escuro
shirt_color = (220, 220, 255)  # Camisa azul claro
vest_color = (120, 60, 30)  # Colete marrom
pants_color = (50, 50, 60)  # Calças escuras
hat_color = (40, 40, 40)  # Chapéu preto
belt_color = (180, 30, 30)  # Cinta vermelha típica alentejana

# Criar uma nova imagem com fundo branco
image = Image.new("RGB", (width, height), background_color)
draw = ImageDraw.Draw(image)

# Desenhar título
try:
    font = ImageFont.truetype("arial.ttf", 36)
except IOError:
    font = ImageFont.load_default()

draw.text((width//2 - 150, 30), "Miguel - Protagonista", fill=(0, 0, 0), font=font)
draw.text((width//2 - 200, 80), "O Mestre do Fado - Concept Art", fill=(100, 100, 100), font=font)

# Desenhar o personagem (estilo simplificado)
# Chapéu alentejano (típico chapéu de abas largas)
draw.ellipse((250, 200, 550, 280), fill=hat_color, outline=outline_color, width=2)
draw.rectangle((300, 150, 500, 220), fill=hat_color, outline=hat_color)
draw.ellipse((300, 150, 500, 250), fill=hat_color, outline=hat_color)

# Cabeça
draw.ellipse((300, 220, 500, 420), fill=fill_color, outline=outline_color, width=2)

# Cabelo
draw.ellipse((290, 240, 350, 320), fill=hair_color, outline=hair_color)
draw.ellipse((450, 240, 510, 320), fill=hair_color, outline=hair_color)

# Olhos
draw.ellipse((350, 300, 380, 320), fill=(255, 255, 255), outline=outline_color, width=2)
draw.ellipse((420, 300, 450, 320), fill=(255, 255, 255), outline=outline_color, width=2)
draw.ellipse((360, 305, 370, 315), fill=(0, 0, 0))
draw.ellipse((430, 305, 440, 315), fill=(0, 0, 0))

# Nariz
draw.line([(400, 320), (390, 350), (400, 360)], fill=outline_color, width=2)

# Boca
draw.arc((370, 370, 430, 390), 0, 180, fill=outline_color, width=2)

# Pescoço
draw.rectangle((380, 420, 420, 460), fill=fill_color, outline=outline_color, width=2)

# Corpo
# Camisa
draw.rectangle((320, 460, 480, 650), fill=shirt_color, outline=outline_color, width=2)

# Colete tradicional alentejano
draw.rectangle((340, 460, 460, 620), fill=vest_color, outline=outline_color, width=2)
# Botões do colete
for y in range(480, 600, 30):
    draw.ellipse((395, y, 405, y+10), fill=(200, 200, 0), outline=outline_color, width=1)

# Cinta vermelha (típica do traje alentejano)
draw.rectangle((320, 620, 480, 650), fill=belt_color, outline=outline_color, width=2)

# Calças
draw.rectangle((340, 650, 400, 850), fill=pants_color, outline=outline_color, width=2)
draw.rectangle((400, 650, 460, 850), fill=pants_color, outline=outline_color, width=2)

# Braços
# Braço esquerdo
draw.rectangle((280, 460, 320, 600), fill=shirt_color, outline=outline_color, width=2)
# Mão esquerda
draw.ellipse((270, 580, 330, 620), fill=fill_color, outline=outline_color, width=2)

# Braço direito segurando uma guitarra portuguesa
draw.rectangle((480, 460, 520, 600), fill=shirt_color, outline=outline_color, width=2)
# Mão direita
draw.ellipse((470, 580, 530, 620), fill=fill_color, outline=outline_color, width=2)

# Guitarra Portuguesa (forma de pêra característica)
# Corpo da guitarra
draw.ellipse((500, 500, 650, 650), fill=(200, 150, 100), outline=outline_color, width=3)
# Braço da guitarra
draw.rectangle((620, 450, 650, 580), fill=(150, 100, 50), outline=outline_color, width=2)
# Cabeça da guitarra
draw.rectangle((620, 400, 660, 450), fill=(150, 100, 50), outline=outline_color, width=2)
# Cravelhas (mecanismo de afinação característico)
draw.ellipse((600, 410, 620, 430), fill=(220, 220, 0), outline=outline_color, width=1)
draw.ellipse((600, 435, 620, 455), fill=(220, 220, 0), outline=outline_color, width=1)
# Cordas
for i in range(6):
    y = 520 + i*20
    draw.line([(530, y), (630, 450)], fill=outline_color, width=1)
# Boca da guitarra
draw.ellipse((560, 560, 590, 590), fill=(50, 30, 10), outline=outline_color, width=2)

# Pés
draw.ellipse((330, 830, 410, 870), fill=(60, 30, 10), outline=outline_color, width=2)
draw.ellipse((390, 830, 470, 870), fill=(60, 30, 10), outline=outline_color, width=2)

# Adicionar descrição
description = [
    "Miguel - Protagonista do jogo 'O Mestre do Fado'",
    "",
    "Características:",
    "- Jovem alentejano com sonho de se tornar mestre do fado",
    "- Veste traje tradicional alentejano com chapéu de abas largas",
    "- Colete e cinta vermelha típicos da região",
    "- Carrega sempre sua guitarra portuguesa herdada do avô",
    "- Expressão determinada e olhar sonhador",
    "",
    "Personalidade:",
    "- Apaixonado pela música e tradições portuguesas",
    "- Determinado e persistente",
    "- Respeitoso com os mestres e tradições",
    "- Curioso e sempre disposto a aprender"
]

y_pos = 880
for line in description:
    draw.text((50, y_pos), line, fill=(0, 0, 0))
    y_pos += 20

# Salvar a imagem
output_path = os.path.join(output_dir, "miguel_protagonista.png")
image.save(output_path)
print(f"Imagem salva em: {output_path}")
