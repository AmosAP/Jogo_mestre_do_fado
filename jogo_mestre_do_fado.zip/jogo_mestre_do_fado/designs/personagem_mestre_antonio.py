from PIL import Image, ImageDraw, ImageFont
import os

# Criar diretório para salvar as imagens se não existir
output_dir = "/home/ubuntu/jogo_mestre_do_fado/designs"
os.makedirs(output_dir, exist_ok=True)

# Configurações da imagem
width, height = 800, 1000
background_color = (255, 255, 255)
outline_color = (0, 0, 0)
fill_color = (240, 230, 210)  # Cor de pele
hair_color = (200, 200, 200)  # Cabelo grisalho
beard_color = (180, 180, 180)  # Barba grisalha
shirt_color = (255, 255, 255)  # Camisa branca
vest_color = (80, 40, 20)  # Colete marrom escuro
apron_color = (180, 160, 140)  # Avental de couro claro
wood_color = (150, 100, 50)  # Madeira

# Criar uma nova imagem com fundo branco
image = Image.new("RGB", (width, height), background_color)
draw = ImageDraw.Draw(image)

# Desenhar título
try:
    font = ImageFont.truetype("arial.ttf", 36)
except IOError:
    font = ImageFont.load_default()

draw.text((width//2 - 200, 30), "Mestre António - Luthier", fill=(0, 0, 0), font=font)
draw.text((width//2 - 200, 80), "O Mestre do Fado - Concept Art", fill=(100, 100, 100), font=font)

# Desenhar o personagem (estilo simplificado)
# Cabeça
draw.ellipse((300, 180, 500, 380), fill=fill_color, outline=outline_color, width=2)

# Cabelo grisalho
draw.arc((280, 180, 520, 280), 0, 180, fill=hair_color, width=30)

# Barba grisalha
draw.arc((300, 320, 500, 420), 180, 360, fill=beard_color, width=20)
draw.rectangle((320, 350, 480, 400), fill=beard_color, outline=beard_color)

# Olhos
draw.ellipse((350, 260, 380, 280), fill=(255, 255, 255), outline=outline_color, width=2)
draw.ellipse((420, 260, 450, 280), fill=(255, 255, 255), outline=outline_color, width=2)
draw.ellipse((360, 265, 370, 275), fill=(0, 0, 0))
draw.ellipse((430, 265, 440, 275), fill=(0, 0, 0))

# Sobrancelhas espessas
draw.arc((345, 240, 385, 260), 0, 180, fill=outline_color, width=3)
draw.arc((415, 240, 455, 260), 0, 180, fill=outline_color, width=3)

# Nariz
draw.line([(400, 280), (390, 310), (400, 320)], fill=outline_color, width=2)

# Boca (parcialmente escondida pela barba)
draw.arc((370, 330, 430, 350), 0, 180, fill=outline_color, width=2)

# Pescoço
draw.rectangle((380, 380, 420, 420), fill=fill_color, outline=outline_color, width=2)

# Corpo
# Camisa branca
draw.rectangle((320, 420, 480, 600), fill=shirt_color, outline=outline_color, width=2)

# Colete tradicional
draw.rectangle((340, 420, 460, 550), fill=vest_color, outline=outline_color, width=2)
# Botões do colete
for y in range(440, 540, 30):
    draw.ellipse((395, y, 405, y+10), fill=(200, 200, 0), outline=outline_color, width=1)

# Avental de luthier
draw.rectangle((340, 550, 460, 700), fill=apron_color, outline=outline_color, width=2)

# Calças
draw.rectangle((340, 700, 400, 850), fill=(50, 50, 60), outline=outline_color, width=2)
draw.rectangle((400, 700, 460, 850), fill=(50, 50, 60), outline=outline_color, width=2)

# Braços
# Braço esquerdo
draw.rectangle((280, 420, 320, 550), fill=shirt_color, outline=outline_color, width=2)
# Mão esquerda segurando uma ferramenta de luthier
draw.ellipse((270, 530, 330, 570), fill=fill_color, outline=outline_color, width=2)
# Ferramenta (formão)
draw.rectangle((260, 540, 320, 550), fill=(150, 150, 150), outline=outline_color, width=2)
draw.rectangle((260, 550, 270, 600), fill=(100, 80, 60), outline=outline_color, width=2)

# Braço direito
draw.rectangle((480, 420, 520, 550), fill=shirt_color, outline=outline_color, width=2)
# Mão direita segurando parte de uma guitarra em construção
draw.ellipse((470, 530, 530, 570), fill=fill_color, outline=outline_color, width=2)

# Guitarra portuguesa em construção (apenas o corpo sem acabamento)
draw.ellipse((520, 500, 650, 650), fill=wood_color, outline=outline_color, width=3)
# Marcas de trabalho na madeira
for i in range(5):
    x = 540 + i*20
    draw.line([(x, 520), (x+10, 630)], fill=(120, 80, 40), width=1)

# Pés
draw.ellipse((330, 830, 410, 870), fill=(60, 30, 10), outline=outline_color, width=2)
draw.ellipse((390, 830, 470, 870), fill=(60, 30, 10), outline=outline_color, width=2)

# Bancada de trabalho (apenas parte visível)
draw.rectangle((520, 650, 700, 700), fill=wood_color, outline=outline_color, width=2)
# Ferramentas na bancada
draw.rectangle((540, 630, 560, 650), fill=(100, 100, 100), outline=outline_color, width=1)  # Martelo
draw.rectangle((580, 630, 600, 650), fill=(150, 150, 150), outline=outline_color, width=1)  # Alicate
draw.line([(620, 630), (640, 650)], fill=outline_color, width=2)  # Serrote

# Adicionar descrição
description = [
    "Mestre António - Construtor de Guitarras Portuguesas",
    "",
    "Características:",
    "- Idoso artesão com décadas de experiência na construção de guitarras",
    "- Veste roupas tradicionais de trabalho com avental de luthier",
    "- Barba e cabelos grisalhos que simbolizam sabedoria e experiência",
    "- Sempre visto em sua oficina, rodeado de instrumentos e ferramentas",
    "",
    "Personalidade:",
    "- Sábio e paciente",
    "- Guardião das tradições de construção de instrumentos",
    "- Mentor que ajuda Miguel a compreender e restaurar a guitarra do avô",
    "- Conhecedor de histórias antigas sobre o fado e seus mestres"
]

y_pos = 880
for line in description:
    draw.text((50, y_pos), line, fill=(0, 0, 0))
    y_pos += 20

# Salvar a imagem
output_path = os.path.join(output_dir, "mestre_antonio.png")
image.save(output_path)
print(f"Imagem salva em: {output_path}")
