import pygame
import os
import json

class CulturalElements:
    def __init__(self):
        # Diretório de recursos
        self.resource_dir = os.path.join(os.path.dirname(__file__), "resources")
        self.images_dir = os.path.join(self.resource_dir, "images")
        self.sounds_dir = os.path.join(self.resource_dir, "sounds")
        self.data_dir = os.path.join(self.resource_dir, "data")
        
        # Criar diretórios se não existirem
        os.makedirs(self.images_dir, exist_ok=True)
        os.makedirs(self.sounds_dir, exist_ok=True)
        os.makedirs(self.data_dir, exist_ok=True)
        
        # Carregar dados culturais
        self.fado_facts = self._load_fado_facts()
        self.portuguese_proverbs = self._load_portuguese_proverbs()
        self.cultural_landmarks = self._load_cultural_landmarks()
        self.traditional_foods = self._load_traditional_foods()
        
    def _load_fado_facts(self):
        """Carrega fatos sobre o fado"""
        return [
            {
                "title": "Origens do Fado",
                "content": "O fado surgiu nos bairros populares de Lisboa no início do século XIX. Acredita-se que tenha nascido da mistura de ritmos africanos, cantos árabes e músicas tradicionais portuguesas.",
                "image_name": "fado_origins.png"
            },
            {
                "title": "Patrimônio da Humanidade",
                "content": "Em 2011, o fado foi reconhecido pela UNESCO como Patrimônio Cultural Imaterial da Humanidade, destacando sua importância cultural para Portugal e para o mundo.",
                "image_name": "fado_unesco.png"
            },
            {
                "title": "Amália Rodrigues",
                "content": "Conhecida como a 'Rainha do Fado', Amália Rodrigues (1920-1999) foi a mais importante intérprete do fado, levando este estilo musical para o reconhecimento internacional.",
                "image_name": "amalia_rodrigues.png"
            },
            {
                "title": "Guitarra Portuguesa",
                "content": "A guitarra portuguesa é o instrumento mais emblemático do fado. Tem 12 cordas dispostas em 6 pares e um formato característico em forma de pêra.",
                "image_name": "portuguese_guitar.png"
            },
            {
                "title": "Casas de Fado",
                "content": "As casas de fado são estabelecimentos tradicionais onde se apresenta o fado. Geralmente, durante as apresentações, o público faz silêncio em sinal de respeito.",
                "image_name": "fado_house.png"
            },
            {
                "title": "Cante Alentejano",
                "content": "O cante alentejano é um canto coral tradicional do Alentejo, também reconhecido como Patrimônio Cultural Imaterial da Humanidade pela UNESCO em 2014.",
                "image_name": "cante_alentejano.png"
            },
            {
                "title": "Fado de Coimbra",
                "content": "O fado de Coimbra é uma variante do fado tradicional, associado à tradição acadêmica da Universidade de Coimbra, cantado apenas por homens e com características musicais distintas.",
                "image_name": "coimbra_fado.png"
            },
            {
                "title": "Saudade",
                "content": "O fado está intrinsecamente ligado ao conceito português de 'saudade', um sentimento de nostalgia ou melancolia profunda que é considerado parte da identidade cultural portuguesa.",
                "image_name": "saudade.png"
            }
        ]
    
    def _load_portuguese_proverbs(self):
        """Carrega provérbios portugueses tradicionais"""
        return [
            {
                "proverb": "Quem não arrisca, não petisca.",
                "meaning": "Quem não se arrisca, não consegue obter ganhos ou vantagens.",
                "equivalent": "Quem não arrisca, não ganha."
            },
            {
                "proverb": "Grão a grão enche a galinha o papo.",
                "meaning": "Com pequenos esforços contínuos, consegue-se alcançar grandes objetivos.",
                "equivalent": "De grão em grão, a galinha enche o papo."
            },
            {
                "proverb": "Há males que vêm por bem.",
                "meaning": "Às vezes, situações aparentemente negativas acabam trazendo consequências positivas.",
                "equivalent": "Há males que vêm para o bem."
            },
            {
                "proverb": "Quem vai ao mar, perde o lugar.",
                "meaning": "Quem se ausenta, corre o risco de perder sua posição ou oportunidade.",
                "equivalent": "Quem vai à guerra, dá e leva."
            },
            {
                "proverb": "Mais vale um pássaro na mão do que dois a voar.",
                "meaning": "É preferível ter algo garantido, mesmo que pequeno, do que algo maior mas incerto.",
                "equivalent": "Mais vale um pássaro na mão do que dois voando."
            },
            {
                "proverb": "Águas passadas não movem moinhos.",
                "meaning": "Não adianta lamentar-se pelo que já aconteceu, pois o passado não pode ser mudado.",
                "equivalent": "O que passou, passou."
            },
            {
                "proverb": "Quem canta, seus males espanta.",
                "meaning": "Cantar (ou fazer algo que se gosta) ajuda a esquecer os problemas e tristezas.",
                "equivalent": "A música alegra a alma."
            },
            {
                "proverb": "Filho de peixe sabe nadar.",
                "meaning": "Os filhos geralmente herdam as habilidades ou características dos pais.",
                "equivalent": "Tal pai, tal filho."
            }
        ]
    
    def _load_cultural_landmarks(self):
        """Carrega informações sobre marcos culturais portugueses"""
        return [
            {
                "name": "Alfama",
                "location": "Lisboa",
                "description": "O bairro mais antigo de Lisboa, com ruas estreitas e sinuosas, é considerado o berço do fado. Suas casas tradicionais e atmosfera única fazem dele um local imperdível.",
                "image_name": "alfama.png"
            },
            {
                "name": "Mouraria",
                "location": "Lisboa",
                "description": "Outro bairro histórico de Lisboa, onde viveu a lendária fadista Maria Severa. É um local multicultural que mantém fortes ligações com as origens do fado.",
                "image_name": "mouraria.png"
            },
            {
                "name": "Museu do Fado",
                "location": "Lisboa",
                "description": "Localizado em Alfama, este museu é dedicado à história do fado e seus intérpretes mais importantes, com exposições permanentes e temporárias sobre este patrimônio cultural.",
                "image_name": "fado_museum.png"
            },
            {
                "name": "Évora",
                "location": "Alentejo",
                "description": "Cidade histórica no Alentejo, classificada como Patrimônio Mundial pela UNESCO. Suas muralhas medievais, templo romano e capela dos ossos são atrações imperdíveis.",
                "image_name": "evora.png"
            },
            {
                "name": "Monsaraz",
                "location": "Alentejo",
                "description": "Vila medieval fortificada no Alentejo, com vista para o lago Alqueva. Suas ruas de pedra e casas brancas oferecem uma viagem no tempo.",
                "image_name": "monsaraz.png"
            },
            {
                "name": "Universidade de Coimbra",
                "location": "Coimbra",
                "description": "Uma das universidades mais antigas do mundo, fundada em 1290. É o berço do fado de Coimbra e sua biblioteca Joanina é considerada uma das mais belas do mundo.",
                "image_name": "coimbra_university.png"
            },
            {
                "name": "Mosteiro dos Jerónimos",
                "location": "Lisboa",
                "description": "Obra-prima da arquitetura manuelina, construída no século XVI. É um símbolo da Era dos Descobrimentos portuguesa e abriga os túmulos de Vasco da Gama e Luís de Camões.",
                "image_name": "jeronimos_monastery.png"
            },
            {
                "name": "Torre de Belém",
                "location": "Lisboa",
                "description": "Fortaleza do século XVI que servia como porta de entrada a Lisboa e ponto de partida para os navegadores. É um ícone da arquitetura manuelina.",
                "image_name": "belem_tower.png"
            }
        ]
    
    def _load_traditional_foods(self):
        """Carrega informações sobre comidas tradicionais portuguesas"""
        return [
            {
                "name": "Pastéis de Belém",
                "region": "Lisboa",
                "description": "Também conhecidos como pastéis de nata, são doces de massa folhada com recheio de creme de ovos. A receita original é mantida em segredo desde 1837.",
                "image_name": "pastel_de_belem.png"
            },
            {
                "name": "Bacalhau à Brás",
                "region": "Nacional",
                "description": "Prato feito com bacalhau desfiado, batatas palha, ovos, cebola, alho, salsa e azeitonas. É um dos muitos pratos de bacalhau da culinária portuguesa.",
                "image_name": "bacalhau_bras.png"
            },
            {
                "name": "Caldo Verde",
                "region": "Norte",
                "description": "Sopa tradicional feita com couve portuguesa finamente cortada, batata, cebola, alho e rodelas de chouriço. É considerada a sopa nacional de Portugal.",
                "image_name": "caldo_verde.png"
            },
            {
                "name": "Açorda Alentejana",
                "region": "Alentejo",
                "description": "Prato típico do Alentejo feito com pão, alho, coentro, azeite e ovos escalfados. Representa a simplicidade e sabor da cozinha alentejana.",
                "image_name": "acorda.png"
            },
            {
                "name": "Migas Alentejanas",
                "region": "Alentejo",
                "description": "Prato tradicional feito com pão, alho, azeite e ervas aromáticas, geralmente servido como acompanhamento de carne de porco ou caça.",
                "image_name": "migas.png"
            },
            {
                "name": "Ginjinha",
                "region": "Lisboa",
                "description": "Licor tradicional feito de ginja (tipo de cereja ácida) com açúcar e aguardente. É tradicionalmente servido em pequenos copos de chocolate.",
                "image_name": "ginjinha.png"
            },
            {
                "name": "Vinho do Alentejo",
                "region": "Alentejo",
                "description": "Os vinhos alentejanos são conhecidos por seu sabor encorpado e frutado. A região tem uma longa tradição vinícola que remonta aos romanos.",
                "image_name": "alentejo_wine.png"
            },
            {
                "name": "Queijo de Évora",
                "region": "Alentejo",
                "description": "Queijo de ovelha curado, com Denominação de Origem Protegida. Tem sabor intenso e é frequentemente servido como entrada ou em tábuas de queijos.",
                "image_name": "evora_cheese.png"
            }
        ]
    
    def save_cultural_data(self):
        """Salva os dados culturais em arquivos JSON"""
        # Salvar fatos sobre o fado
        with open(os.path.join(self.data_dir, 'fado_facts.json'), 'w', encoding='utf-8') as f:
            json.dump(self.fado_facts, f, ensure_ascii=False, indent=4)
        
        # Salvar provérbios portugueses
        with open(os.path.join(self.data_dir, 'portuguese_proverbs.json'), 'w', encoding='utf-8') as f:
            json.dump(self.portuguese_proverbs, f, ensure_ascii=False, indent=4)
        
        # Salvar marcos culturais
        with open(os.path.join(self.data_dir, 'cultural_landmarks.json'), 'w', encoding='utf-8') as f:
            json.dump(self.cultural_landmarks, f, ensure_ascii=False, indent=4)
        
        # Salvar comidas tradicionais
        with open(os.path.join(self.data_dir, 'traditional_foods.json'), 'w', encoding='utf-8') as f:
            json.dump(self.traditional_foods, f, ensure_ascii=False, indent=4)
        
        print("Dados culturais salvos com sucesso!")
    
    def get_random_fado_fact(self):
        """Retorna um fato aleatório sobre o fado"""
        import random
        return random.choice(self.fado_facts)
    
    def get_random_proverb(self):
        """Retorna um provérbio português aleatório"""
        import random
        return random.choice(self.portuguese_proverbs)
    
    def get_landmark_by_name(self, name):
        """Retorna informações sobre um marco cultural específico"""
        for landmark in self.cultural_landmarks:
            if landmark["name"].lower() == name.lower():
                return landmark
        return None
    
    def get_landmarks_by_location(self, location):
        """Retorna marcos culturais de uma localização específica"""
        return [landmark for landmark in self.cultural_landmarks if landmark["location"].lower() == location.lower()]
    
    def get_food_by_name(self, name):
        """Retorna informações sobre uma comida tradicional específica"""
        for food in self.traditional_foods:
            if food["name"].lower() == name.lower():
                return food
        return None
    
    def get_foods_by_region(self, region):
        """Retorna comidas tradicionais de uma região específica"""
        return [food for food in self.traditional_foods if food["region"].lower() == region.lower()]

class PortugueseMusic:
    def __init__(self):
        self.fado_songs = [
            {
                "title": "Fado Português",
                "artist": "Amália Rodrigues",
                "year": 1952,
                "description": "Uma das mais emblemáticas canções de fado, que fala sobre a própria essência do fado como expressão da alma portuguesa.",
                "lyrics_excerpt": "O fado nasceu um dia, quando o vento mal bulia e o céu o mar prolongava, na amurada dum veleiro, no peito dum marinheiro que, estando triste, cantava."
            },
            {
                "title": "Barco Negro",
                "artist": "Amália Rodrigues",
                "year": 1954,
                "description": "Canção que retrata a dor de uma mulher que vê seu amado partir para o mar, sem saber se ele voltará.",
                "lyrics_excerpt": "De manhã, que medo, que me achasses feia! Acordei, tremendo, deitada n'areia. Mas logo os teus olhos disseram que não, e o sol penetrou no meu coração."
            },
            {
                "title": "Lágrima",
                "artist": "Amália Rodrigues",
                "year": 1983,
                "description": "Uma canção melancólica sobre a dor e a saudade, sentimentos profundamente ligados ao fado.",
                "lyrics_excerpt": "Cheia de penas, cheia de penas me deito. E com mais penas, com mais penas me levanto. No meu peito, já me ficou no meu peito, este jeito, o jeito de te querer tanto."
            },
            {
                "title": "Que Deus Me Perdoe",
                "artist": "Carlos do Carmo",
                "year": 1972,
                "description": "Uma reflexão sobre o amor e o arrependimento, temas recorrentes no fado.",
                "lyrics_excerpt": "Que Deus me perdoe se peco ao confessar, que mesmo sem querer eu te quero. Que Deus me perdoe se peco ao confessar, que mesmo sem querer eu te quero."
            },
            {
                "title": "Canção do Mar",
                "artist": "Dulce Pontes",
                "year": 1993,
                "description": "Uma canção que evoca o mar, elemento tão presente na cultura e história portuguesas.",
                "lyrics_excerpt": "Fui bailar no meu batel, além do mar cruel, e o mar bramindo, diz que eu fui roubar, a luz sem par do teu olhar tão lindo."
            },
            {
                "title": "Chuva",
                "artist": "Mariza",
                "year": 2001,
                "description": "Uma canção contemporânea que mantém a essência do fado tradicional, falando sobre a chuva como metáfora para as lágrimas.",
                "lyrics_excerpt": "Chuva, cai serena nesta tarde. Chuva, és tão bela quando cais. Chuva, traz alívio e saudade. Chuva, não me deixes nunca mais."
            },
            {
                "title": "Balada do Alentejo",
                "artist": "Grupo Coral de Beja",
                "year": 1980,
                "description": "Um exemplo clássico de cante alentejano, cantado em grupo e sem acompanhamento instrumental.",
                "lyrics_excerpt": "Alentejo, Alentejo, terra sagrada. Alentejo, Alentejo, terra abençoada. Quem te não conhece, não sabe o que é bom. Quem te não conhece, não sabe o que é bom."
            },
            {
                "title": "Balada da Despedida",
                "artist": "Estudantes de Coimbra",
                "year": "Tradicional",
                "description": "Um exemplo de fado de Coimbra, associado à tradição acadêmica da Universidade de Coimbra.",
                "lyrics_excerpt": "Coimbra tem mais encanto na hora da despedida. Coimbra tem mais encanto na hora da despedida. Que as lágrimas do estudante, que as lágrimas do estudante, são a luz da nossa vida."
            }
        ]
        
        self.traditional_instruments = [
            {
                "name": "Guitarra Portuguesa",
                "description": "Instrumento de cordas com formato de pêra e 12 cordas metálicas dispostas em 6 pares. É o instrumento mais emblemático do fado.",
                "origin": "Portugal, evoluiu de instrumentos como o cistre e a guitarra inglesa",
                "playing_technique": "Dedilhado com unhas longas ou palhetas nos dedos indicador e polegar"
            },
            {
                "name": "Viola de Fado",
                "description": "Semelhante a um violão clássico, mas com características específicas para acompanhar o fado. Tem 6 cordas e serve como base harmônica.",
                "origin": "Portugal, derivada da guitarra clássica espanhola",
                "playing_technique": "Principalmente acordes rasgueados e arpejos"
            },
            {
                "name": "Cavaquinho",
                "description": "Pequeno instrumento de 4 cordas, semelhante a um ukulele. Comum na música tradicional portuguesa e levado ao Brasil pelos colonizadores.",
                "origin": "Norte de Portugal, especialmente Braga e Minho",
                "playing_technique": "Dedilhado ou com palheta, usado principalmente para ritmos"
            },
            {
                "name": "Acordeão",
                "description": "Instrumento de teclas e foles muito popular na música folclórica portuguesa, especialmente no norte do país.",
                "origin": "Adaptado em Portugal a partir do século XIX",
                "playing_technique": "Pressionando teclas ou botões enquanto se move o fole para criar som"
            },
            {
                "name": "Adufe",
                "description": "Pandeiro quadrado tradicional, feito de pele de cabra esticada sobre uma armação de madeira, com sementes ou pequenas pedras no interior.",
                "origin": "Região da Beira Baixa, com influências árabes",
                "playing_technique": "Percutido com as mãos ou agitado para produzir som com os elementos internos"
            },
            {
                "name": "Bombo",
                "description": "Grande tambor tradicional usado em festas populares e procissões, especialmente no norte de Portugal.",
                "origin": "Tradição popular portuguesa",
                "playing_technique": "Percutido com baquetas de madeira"
            },
            {
                "name": "Gaita-de-foles",
                "description": "Instrumento de sopro com bolsa de ar e tubos, comum em Trás-os-Montes e na região fronteiriça com a Galiza.",
                "origin": "Tradição celta do norte de Portugal",
                "playing_technique": "Enchendo a bolsa de ar e pressionando-a enquanto se tocam as notas nos tubos"
            },
            {
                "name": "Viola Campaniça",
                "description": "Instrumento de cordas tradicional do Baixo Alentejo, com 10 cordas metálicas dispostas em 5 pares.",
                "origin": "Alentejo, Portugal",
                "playing_technique": "Dedilhado ou rasgueado, acompanhando o cante alentejano"
            }
        ]
    
    def get_random_fado_song(self):
        """Retorna uma canção de fado aleatória"""
        import random
        return random.choice(self.fado_songs)
    
    def get_song_by_title(self, title):
        """Retorna informações sobre uma canção específica"""
        for song in self.fado_songs:
            if song["title"].lower() == title.lower():
                return song
        return None
    
    def get_songs_by_artist(self, artist):
        """Retorna canções de um artista específico"""
        return [song for song in self.fado_songs if artist.lower() in song["artist"].lower()]
    
    def get_instrument_by_name(self, name):
        """Retorna informações sobre um instrumento específico"""
        for instrument in self.traditional_instruments:
            if instrument["name"].lower() == name.lower():
                return instrument
        return None

class PortugueseArt:
    def __init__(self):
        self.azulejos = [
            {
                "name": "Azulejos Geométricos",
                "period": "Século XVI",
                "description": "Inspirados na arte islâmica, estes azulejos apresentam padrões geométricos repetitivos em cores como azul, amarelo e verde.",
                "locations": ["Palácio Nacional de Sintra", "Convento de Cristo em Tomar"]
            },
            {
                "name": "Azulejos Figura Avulsa",
                "period": "Século XVII",
                "description": "Cada azulejo contém uma figura completa (flores, animais, barcos, pessoas), geralmente em azul sobre fundo branco, influenciados pela porcelana chinesa.",
                "locations": ["Museu Nacional do Azulejo", "Casas particulares por todo o país"]
            },
            {
                "name": "Painéis Narrativos",
                "period": "Séculos XVII-XVIII",
                "description": "Grandes painéis que contam histórias bíblicas, mitológicas ou históricas, predominantemente em azul e branco.",
                "locations": ["Igreja de São Lourenço em Almancil", "Mosteiro de São Vicente de Fora"]
            },
            {
                "name": "Azulejos Pombalinos",
                "period": "Século XVIII",
                "description": "Padrões mais simples e repetitivos, criados após o terremoto de Lisboa de 1755 para reconstrução rápida da cidade.",
                "locations": ["Baixa Pombalina em Lisboa", "Fachadas de edifícios em Lisboa"]
            },
            {
                "name": "Azulejos Art Nouveau",
                "period": "Final do século XIX - início do século XX",
                "description": "Influenciados pelo movimento Art Nouveau, apresentam motivos florais estilizados e linhas curvas.",
                "locations": ["Estação de São Bento no Porto", "Edifícios da Avenida da Liberdade em Lisboa"]
            },
            {
                "name": "Azulejos Contemporâneos",
                "period": "Século XX-XXI",
                "description": "Reinterpretações modernas da tradição do azulejo, muitas vezes em espaços públicos como estações de metrô.",
                "locations": ["Estações do Metro de Lisboa", "Obras de artistas como Maria Keil e Eduardo Nery"]
            }
        ]
        
        self.traditional_crafts = [
            {
                "name": "Olaria do Alentejo",
                "region": "Alentejo",
                "description": "Cerâmica tradicional alentejana, conhecida por seus barros vermelhos e decorações simples, geralmente em branco ou cores terrosas.",
                "notable_items": ["Talhas para armazenar azeite e vinho", "Bilhas de água", "Assadores de castanhas"]
            },
            {
                "name": "Bordado de Castelo Branco",
                "region": "Beira Baixa",
                "description": "Bordado colorido em linho ou algodão, com motivos florais, pássaros e árvores da vida, usando fios de seda.",
                "notable_items": ["Colchas", "Painéis decorativos", "Almofadas"]
            },
            {
                "name": "Rendas de Bilros",
                "region": "Principalmente Vila do Conde e Peniche",
                "description": "Técnica de renda feita com bilros (pequenas peças de madeira), alfinetes e uma almofada cilíndrica, criando padrões delicados.",
                "notable_items": ["Toalhas", "Golas", "Cortinas", "Acessórios de vestuário"]
            },
            {
                "name": "Tapetes de Arraiolos",
                "region": "Alentejo (Arraiolos)",
                "description": "Tapetes bordados à mão em tela de juta com lã, usando ponto de arraiolos (meio ponto), com desenhos tradicionais de influência oriental.",
                "notable_items": ["Tapetes de várias dimensões", "Almofadas", "Painéis decorativos"]
            },
            {
                "name": "Filigrana",
                "region": "Norte (Gondomar e Póvoa de Lanhoso)",
                "description": "Técnica de ourivesaria que consiste em entrelaçar finos fios de ouro ou prata, criando peças delicadas e rendilhadas.",
                "notable_items": ["Coração de Viana", "Brincos de rainha", "Cruzes", "Arrecadas"]
            },
            {
                "name": "Cortiça",
                "region": "Alentejo",
                "description": "Artesanato feito com cortiça, material natural extraído do sobreiro, árvore típica do montado alentejano.",
                "notable_items": ["Bolsas", "Chapéus", "Acessórios de moda", "Objetos decorativos"]
            },
            {
                "name": "Bonecos de Estremoz",
                "region": "Alentejo (Estremoz)",
                "description": "Figuras de barro policromado que representam cenas da vida rural, religiosa e tradicional portuguesa. Reconhecidos como Patrimônio Cultural Imaterial da UNESCO.",
                "notable_items": ["Presépio", "Figuras de pastores", "Representações de profissões tradicionais"]
            },
            {
                "name": "Cestaria",
                "region": "Todo o país, com variações regionais",
                "description": "Arte de tecer cestos e outros objetos usando vime, cana, junco ou outras fibras vegetais.",
                "notable_items": ["Cestos para vindima", "Canastras", "Cestos para pão", "Mobiliário em vime"]
            }
        ]
    
    def get_random_azulejo(self):
        """Retorna um tipo de azulejo aleatório"""
        import random
        return random.choice(self.azulejos)
    
    def get_azulejo_by_period(self, period):
        """Retorna azulejos de um período específico"""
        return [azulejo for azulejo in self.azulejos if period.lower() in azulejo["period"].lower()]
    
    def get_random_craft(self):
        """Retorna um artesanato tradicional aleatório"""
        import random
        return random.choice(self.traditional_crafts)
    
    def get_crafts_by_region(self, region):
        """Retorna artesanatos de uma região específica"""
        return [craft for craft in self.traditional_crafts if region.lower() in craft["region"].lower()]

# Função para criar e salvar os dados culturais
def create_cultural_data():
    cultural_elements = CulturalElements()
    cultural_elements.save_cultural_data()
    
    print("Dados culturais portugueses criados e salvos com sucesso!")
    
if __name__ == "__main__":
    create_cultural_data()
