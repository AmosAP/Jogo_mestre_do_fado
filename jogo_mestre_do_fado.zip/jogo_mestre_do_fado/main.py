import pygame
import sys
import os
import random
from game_engine import Player, NPC, Scene, SceneManager, RhythmGame

# Inicialização do Pygame
pygame.init()

# Configurações da tela
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("O Mestre do Fado")

# Cores
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)

# Diretório de recursos
RESOURCE_DIR = os.path.join(os.path.dirname(__file__), "resources")
IMAGES_DIR = os.path.join(RESOURCE_DIR, "images")
SOUNDS_DIR = os.path.join(RESOURCE_DIR, "sounds")
FONTS_DIR = os.path.join(RESOURCE_DIR, "fonts")

# Criar diretórios se não existirem
os.makedirs(IMAGES_DIR, exist_ok=True)
os.makedirs(SOUNDS_DIR, exist_ok=True)
os.makedirs(FONTS_DIR, exist_ok=True)

# Classe para gerenciar estados do jogo
class GameState:
    def __init__(self):
        self.current_state = "menu"
        self.player = Player(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2)
        self.scene_manager = SceneManager()
        self.rhythm_game = RhythmGame(SCREEN_WIDTH, SCREEN_HEIGHT)
        
        # Inicializar cenas
        self.setup_scenes()
        
        self.states = {
            "menu": MenuState(),
            "game": GameplayState(self.player, self.scene_manager),
            "dialogue": DialogueState(),
            "rhythm": RhythmGameState(self.rhythm_game),
            "pause": PauseState()
        }
    
    def setup_scenes(self):
        # Criar cenas do jogo
        
        # Aldeia Alentejana
        aldeia_scene = Scene("aldeia")
        
        # Adicionar NPCs à aldeia
        mestre_antonio_dialogue = {
            "speaker": "Mestre António",
            "lines": [
                "Ah, então você é o jovem que quer aprender sobre a guitarra portuguesa?",
                "Esta guitarra que você tem... pertenceu ao seu avô?",
                "Posso ver que precisa de alguns reparos. Vamos trabalhar nisso juntos."
            ]
        }
        
        mestre_antonio = NPC(300, 300, "Mestre António", mestre_antonio_dialogue)
        aldeia_scene.add_npc(mestre_antonio)
        
        # Adicionar saídas da aldeia
        aldeia_scene.add_exit(
            pygame.Rect(700, 250, 100, 100),
            "lisboa",
            (100, 300)  # Posição do jogador ao entrar em Lisboa
        )
        
        # Lisboa - Alfama
        lisboa_scene = Scene("lisboa")
        
        # Adicionar NPCs a Lisboa
        ana_dialogue = {
            "speaker": "Ana",
            "lines": [
                "Olá, Miguel! Bem-vindo a Lisboa.",
                "Estou ansiosa para te ensinar os segredos do fado.",
                "Vamos começar com algumas lições básicas de guitarra portuguesa?"
            ]
        }
        
        ana = NPC(400, 350, "Ana", ana_dialogue)
        lisboa_scene.add_npc(ana)
        
        # Adicionar saídas de Lisboa
        lisboa_scene.add_exit(
            pygame.Rect(0, 250, 100, 100),
            "aldeia",
            (650, 300)  # Posição do jogador ao voltar para a aldeia
        )
        
        lisboa_scene.add_exit(
            pygame.Rect(500, 400, 100, 100),
            "casa_fado",
            (150, 300)  # Posição do jogador ao entrar na casa de fado
        )
        
        # Casa de Fado
        casa_fado_scene = Scene("casa_fado")
        
        # Adicionar saídas da casa de fado
        casa_fado_scene.add_exit(
            pygame.Rect(50, 500, 100, 50),
            "lisboa",
            (450, 450)  # Posição do jogador ao voltar para Lisboa
        )
        
        # Adicionar cenas ao gerenciador
        self.scene_manager.add_scene(aldeia_scene)
        self.scene_manager.add_scene(lisboa_scene)
        self.scene_manager.add_scene(casa_fado_scene)
        
        # Definir cena inicial
        self.scene_manager.change_scene("aldeia")
    
    def change_state(self, new_state):
        if new_state in self.states:
            self.current_state = new_state
            print(f"Estado alterado para: {new_state}")
        else:
            print(f"Estado {new_state} não existe")
    
    def update(self, dt, current_time):
        self.states[self.current_state].update(dt, current_time)
    
    def render(self, screen):
        self.states[self.current_state].render(screen)
    
    def handle_event(self, event):
        self.states[self.current_state].handle_event(event)

# Classes base para os diferentes estados do jogo
class State:
    def update(self, dt, current_time):
        pass
    
    def render(self, screen):
        pass
    
    def handle_event(self, event):
        pass

class MenuState(State):
    def __init__(self):
        self.title_font = pygame.font.Font(None, 64)
        self.menu_font = pygame.font.Font(None, 32)
        self.title_text = self.title_font.render("O Mestre do Fado", True, BLACK)
        self.start_text = self.menu_font.render("Iniciar Jogo", True, BLACK)
        self.options_text = self.menu_font.render("Opções", True, BLACK)
        self.exit_text = self.menu_font.render("Sair", True, BLACK)
        self.selected_option = 0
        self.options = ["start", "options", "exit"]
    
    def update(self, dt, current_time):
        pass
    
    def render(self, screen):
        screen.fill(WHITE)
        
        # Desenhar título
        title_rect = self.title_text.get_rect(center=(SCREEN_WIDTH/2, 100))
        screen.blit(self.title_text, title_rect)
        
        # Desenhar opções de menu
        start_rect = self.start_text.get_rect(center=(SCREEN_WIDTH/2, 250))
        options_rect = self.options_text.get_rect(center=(SCREEN_WIDTH/2, 300))
        exit_rect = self.exit_text.get_rect(center=(SCREEN_WIDTH/2, 350))
        
        # Destacar opção selecionada
        if self.selected_option == 0:
            pygame.draw.rect(screen, RED, start_rect.inflate(20, 10), 2)
        elif self.selected_option == 1:
            pygame.draw.rect(screen, RED, options_rect.inflate(20, 10), 2)
        elif self.selected_option == 2:
            pygame.draw.rect(screen, RED, exit_rect.inflate(20, 10), 2)
        
        screen.blit(self.start_text, start_rect)
        screen.blit(self.options_text, options_rect)
        screen.blit(self.exit_text, exit_rect)
    
    def handle_event(self, event):
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_UP:
                self.selected_option = (self.selected_option - 1) % len(self.options)
            elif event.key == pygame.K_DOWN:
                self.selected_option = (self.selected_option + 1) % len(self.options)
            elif event.key == pygame.K_RETURN:
                if self.options[self.selected_option] == "start":
                    game_state.change_state("game")
                elif self.options[self.selected_option] == "options":
                    print("Opções não implementadas ainda")
                elif self.options[self.selected_option] == "exit":
                    pygame.quit()
                    sys.exit()

class GameplayState(State):
    def __init__(self, player, scene_manager):
        self.player = player
        self.scene_manager = scene_manager
        self.font = pygame.font.Font(None, 24)
        self.interaction_text = self.font.render("Pressione E para interagir", True, BLACK)
        self.can_interact = False
        self.interaction_target = None
    
    def update(self, dt, current_time):
        # Atualizar cena atual
        self.scene_manager.update(current_time)
        
        # Atualizar jogador
        self.player.update(current_time)
        
        # Verificar interações possíveis
        self.can_interact = False
        self.interaction_target = None
        
        current_scene = self.scene_manager.get_current_scene()
        if current_scene:
            # Verificar colisão com NPCs
            for npc in current_scene.npcs:
                if self.player.rect.colliderect(npc.interaction_rect):
                    self.can_interact = True
                    self.interaction_target = npc
                    break
            
            # Verificar colisão com saídas
            for exit in current_scene.exits:
                if self.player.rect.colliderect(exit["rect"]):
                    # Mudar para a nova cena
                    self.scene_manager.change_scene(exit["target_scene"])
                    # Posicionar o jogador no ponto de entrada da nova cena
                    self.player.rect.x = exit["target_position"][0]
                    self.player.rect.y = exit["target_position"][1]
                    break
    
    def render(self, screen):
        screen.fill(WHITE)
        
        # Renderizar cena atual
        self.scene_manager.render(screen)
        
        # Renderizar jogador
        screen.blit(self.player.image, self.player.rect)
        
        # Mostrar texto de interação se possível
        if self.can_interact:
            text_rect = self.interaction_text.get_rect(center=(SCREEN_WIDTH/2, 50))
            screen.blit(self.interaction_text, text_rect)
    
    def handle_event(self, event):
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                game_state.change_state("pause")
            elif event.key == pygame.K_e and self.can_interact:
                game_state.change_state("dialogue")
                game_state.states["dialogue"].start_dialogue(self.interaction_target.dialogue_data)
            
            # Controles de movimento
            if event.key == pygame.K_LEFT:
                self.player.direction["left"] = True
            elif event.key == pygame.K_RIGHT:
                self.player.direction["right"] = True
            elif event.key == pygame.K_UP:
                self.player.direction["up"] = True
            elif event.key == pygame.K_DOWN:
                self.player.direction["down"] = True
        
        elif event.type == pygame.KEYUP:
            if event.key == pygame.K_LEFT:
                self.player.direction["left"] = False
            elif event.key == pygame.K_RIGHT:
                self.player.direction["right"] = False
            elif event.key == pygame.K_UP:
                self.player.direction["up"] = False
            elif event.key == pygame.K_DOWN:
                self.player.direction["down"] = False
        
        # Atualizar estado de movimento do jogador
        self.player.is_moving = any(self.player.direction.values())
        
        # Calcular movimento
        dx = 0
        dy = 0
        
        if self.player.direction["left"]:
            dx -= 1
        if self.player.direction["right"]:
            dx += 1
        if self.player.direction["up"]:
            dy -= 1
        if self.player.direction["down"]:
            dy += 1
        
        # Mover jogador
        self.player.move(dx, dy)

class DialogueState(State):
    def __init__(self):
        self.font = pygame.font.Font(None, 28)
        self.dialogue_box = pygame.Rect(50, 400, SCREEN_WIDTH - 100, 150)
        self.current_dialogue = []
        self.current_line = 0
        self.text_speed = 2  # caracteres por frame
        self.text_progress = 0
        self.current_text = ""
        self.dialogue_complete = False
        self.speaker_name = ""
        self.name_font = pygame.font.Font(None, 32)
    
    def start_dialogue(self, dialogue_data):
        self.current_dialogue = dialogue_data["lines"]
        self.speaker_name = dialogue_data["speaker"]
        self.current_line = 0
        self.text_progress = 0
        self.current_text = ""
        self.dialogue_complete = False
    
    def update(self, dt, current_time):
        if self.current_line < len(self.current_dialogue):
            full_text = self.current_dialogue[self.current_line]
            
            if self.text_progress < len(full_text):
                self.text_progress += self.text_speed
                self.current_text = full_text[:int(self.text_progress)]
            else:
                self.dialogue_complete = True
    
    def render(self, screen):
        # Manter o fundo do estado anterior
        game_state.states["game"].render(screen)
        
        # Desenhar caixa de diálogo
        pygame.draw.rect(screen, WHITE, self.dialogue_box)
        pygame.draw.rect(screen, BLACK, self.dialogue_box, 2)
        
        # Desenhar nome do falante
        name_bg = pygame.Rect(self.dialogue_box.x, self.dialogue_box.y - 30, 150, 30)
        pygame.draw.rect(screen, WHITE, name_bg)
        pygame.draw.rect(screen, BLACK, name_bg, 2)
        
        name_text = self.name_font.render(self.speaker_name, True, BLACK)
        screen.blit(name_text, (name_bg.x + 10, name_bg.y + 5))
        
        # Desenhar texto atual
        text_surface = self.font.render(self.current_text, True, BLACK)
        screen.blit(text_surface, (self.dialogue_box.x + 20, self.dialogue_box.y + 20))
        
        # Indicador para continuar
        if self.dialogue_complete:
            continue_text = self.font.render("Pressione ESPAÇO para continuar", True, BLACK)
            screen.blit(continue_text, (self.dialogue_box.right - 300, self.dialogue_box.bottom - 30))
    
    def handle_event(self, event):
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE:
                if self.dialogue_complete:
                    self.current_line += 1
                    if self.current_line >= len(self.current_dialogue):
                        game_state.change_state("game")
                    else:
                        self.text_progress = 0
                        self.current_text = ""
                        self.dialogue_complete = False
                else:
                    # Mostrar todo o texto imediatamente
                    self.text_progress = len(self.current_dialogue[self.current_line])
                    self.current_text = self.current_dialogue[self.current_line]
                    self.dialogue_complete = True

class RhythmGameState(State):
    def __init__(self, rhythm_game):
        self.rhythm_game = rhythm_game
        self.font = pygame.font.Font(None, 36)
        self.back_button = pygame.Rect(20, 20, 100, 40)
        self.back_text = self.font.render("Voltar", True, BLACK)
    
    def start_song(self, song_name, difficulty="normal"):
        self.rhythm_game.start_song(song_name, difficulty)
    
    def update(self, dt, current_time):
        self.rhythm_game.update(current_time)
    
    def render(self, screen):
        self.rhythm_game.render(screen)
        
        # Botão de voltar
        pygame.draw.rect(screen, WHITE, self.back_button)
        pygame.draw.rect(screen, BLACK, self.back_button, 2)
        screen.blit(self.back_text, (self.back_button.x + 10, self.back_button.y + 10))
    
    def handle_event(self, event):
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                game_state.change_state("game")
            
            # Verificar teclas de ritmo
            if event.key == pygame.K_a:
                self.rhythm_game.check_hit(0)
            elif event.key == pygame.K_s:
                self.rhythm_game.check_hit(1)
            elif event.key == pygame.K_d:
                self.rhythm_game.check_hit(2)
            elif event.key == pygame.K_f:
                self.rhythm_game.check_hit(3)
        
        elif event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 1:  # Botão esquerdo do mouse
                if self.back_button.collidepoint(event.pos):
                    game_state.change_state("game")

class PauseState(State):
    def __init__(self):
        self.font = pygame.font.Font(None, 48)
        self.pause_text = self.font.render("JOGO PAUSADO", True, BLACK)
        self.resume_text = self.font.render("Continuar", True, BLACK)
        self.menu_text = self.font.render("Menu Principal", True, BLACK)
        self.selected_option = 0
        self.options = ["resume", "menu"]
    
    def update(self, dt, current_time):
        pass
    
    def render(self, screen):
        # Semi-transparente sobre o jogo
        game_state.states["game"].render(screen)
        overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 128))
        screen.blit(overlay, (0, 0))
        
        # Texto de pausa
        pause_rect = self.pause_text.get_rect(center=(SCREEN_WIDTH/2, 150))
        screen.blit(self.pause_text, pause_rect)
        
        # Opções
        resume_rect = self.resume_text.get_rect(center=(SCREEN_WIDTH/2, 250))
        menu_rect = self.menu_text.get_rect(center=(SCREEN_WIDTH/2, 300))
        
        # Destacar opção selecionada
        if self.selected_option == 0:
            pygame.draw.rect(screen, RED, resume_rect.inflate(20, 10), 2)
        else:
            pygame.draw.rect(screen, RED, menu_rect.inflate(20, 10), 2)
        
        screen.blit(self.resume_text, resume_rect)
        screen.blit(self.menu_text, menu_rect)
    
    def handle_event(self, event):
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_UP or event.key == pygame.K_DOWN:
                self.selected_option = 1 - self.selected_option
            elif event.key == pygame.K_RETURN:
                if self.options[self.selected_option] == "resume":
                    game_state.change_state("game")
                elif self.options[self.selected_option] == "menu":
                    game_state.change_state("menu")
            elif event.key == pygame.K_ESCAPE:
                game_state.change_state("game")

# Inicialização do estado do jogo
game_state = GameState()

# Loop principal do jogo
def main():
    clock = pygame.time.Clock()
    running = True
    
    while running:
        current_time = pygame.time.get_ticks()
        dt = clock.tick(60) / 1000.0  # Delta time em segundos
        
        # Processar eventos
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            
            # Passar evento para o estado atual
            game_state.handle_event(event)
        
        # Atualizar
        game_state.update(dt, current_time)
        
        # Renderizar
        game_state.render(screen)
        
        # Atualizar tela
        pygame.display.flip()
    
    pygame.quit()
    sys.exit()

if __name__ == "__main__":
    main()
