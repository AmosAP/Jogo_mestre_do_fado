import pygame
import sys
import os
import random
from game_engine import Player, NPC, Scene, SceneManager, RhythmGame
from game_mechanics import MusicRhythmSystem, QuestSystem, DialogueSystem
from cultural_integration import CulturalIntegration

# Inicialização do Pygame
pygame.init()

# Configurações da tela
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("O Mestre do Fado")

# Cores
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)

# Diretório de recursos
RESOURCE_DIR = os.path.join(os.path.dirname(__file__), "resources")
IMAGES_DIR = os.path.join(RESOURCE_DIR, "images")
SOUNDS_DIR = os.path.join(RESOURCE_DIR, "sounds")
FONTS_DIR = os.path.join(RESOURCE_DIR, "fonts")

# Criar diretórios se não existirem
os.makedirs(IMAGES_DIR, exist_ok=True)
os.makedirs(SOUNDS_DIR, exist_ok=True)
os.makedirs(FONTS_DIR, exist_ok=True)

# Classe para gerenciar estados do jogo
class GameState:
    def __init__(self):
        self.current_state = "menu"
        self.player = Player(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2)
        self.scene_manager = SceneManager()
        self.rhythm_game = RhythmGame(SCREEN_WIDTH, SCREEN_HEIGHT)
        self.music_system = MusicRhythmSystem(SCREEN_WIDTH, SCREEN_HEIGHT)
        self.quest_system = QuestSystem()
        self.dialogue_system = DialogueSystem()
        self.cultural_integration = CulturalIntegration(SCREEN_WIDTH, SCREEN_HEIGHT)
        
        # Inicializar cenas
        self.setup_scenes()
        
        self.states = {
            "menu": MenuState(),
            "game": GameplayState(self.player, self.scene_manager, self.quest_system, self.cultural_integration),
            "dialogue": DialogueState(self.dialogue_system, self.quest_system),
            "rhythm": RhythmGameState(self.music_system, self.quest_system),
            "pause": PauseState(),
            "quest_log": QuestLogState(self.quest_system),
            "encyclopedia": EncyclopediaState(self.cultural_integration)
        }
        
        # Iniciar a missão tutorial
        self.quest_system.start_quest("tutorial")
        
        # Dica cultural atual
        self.current_cultural_tip = self.cultural_integration.get_random_cultural_tip()
        self.tip_timer = 0
        self.tip_duration = 15000  # 15 segundos
    
    def setup_scenes(self):
        # Criar cenas do jogo
        
        # Aldeia Alentejana
        aldeia_scene = Scene("aldeia")
        
        # Adicionar NPCs à aldeia
        mestre_antonio = NPC(300, 300, "Mestre António", {"speaker": "Mestre António", "dialogue_id": "mestre_antonio_intro"})
        aldeia_scene.add_npc(mestre_antonio)
        
        # Adicionar saídas da aldeia
        aldeia_scene.add_exit(
            pygame.Rect(700, 250, 100, 100),
            "lisboa",
            (100, 300)  # Posição do jogador ao entrar em Lisboa
        )
        
        # Lisboa - Alfama
        lisboa_scene = Scene("lisboa")
        
        # Adicionar NPCs a Lisboa
        ana = NPC(400, 350, "Ana", {"speaker": "Ana", "dialogue_id": "ana_intro"})
        lisboa_scene.add_npc(ana)
        
        # Adicionar saídas de Lisboa
        lisboa_scene.add_exit(
            pygame.Rect(0, 250, 100, 100),
            "aldeia",
            (650, 300)  # Posição do jogador ao voltar para a aldeia
        )
        
        lisboa_scene.add_exit(
            pygame.Rect(500, 400, 100, 100),
            "casa_fado",
            (150, 300)  # Posição do jogador ao entrar na casa de fado
        )
        
        # Casa de Fado
        casa_fado_scene = Scene("casa_fado")
        
        # Adicionar saídas da casa de fado
        casa_fado_scene.add_exit(
            pygame.Rect(50, 500, 100, 50),
            "lisboa",
            (450, 450)  # Posição do jogador ao voltar para Lisboa
        )
        
        # Adicionar cenas ao gerenciador
        self.scene_manager.add_scene(aldeia_scene)
        self.scene_manager.add_scene(lisboa_scene)
        self.scene_manager.add_scene(casa_fado_scene)
        
        # Definir cena inicial
        self.scene_manager.change_scene("aldeia")
    
    def change_state(self, new_state):
        if new_state in self.states:
            self.current_state = new_state
            print(f"Estado alterado para: {new_state}")
        else:
            print(f"Estado {new_state} não existe")
    
    def update(self, dt, current_time):
        # Atualizar estado atual
        self.states[self.current_state].update(dt, current_time)
        
        # Atualizar timer de dica cultural
        if self.current_state == "game":
            self.tip_timer += dt * 1000  # Converter para milissegundos
            if self.tip_timer >= self.tip_duration:
                self.current_cultural_tip = self.cultural_integration.get_random_cultural_tip()
                self.tip_timer = 0
    
    def render(self, screen):
        self.states[self.current_state].render(screen)
        
        # Mostrar dica cultural no estado de jogo
        if self.current_state == "game" and self.current_cultural_tip:
            self._render_cultural_tip(screen)
    
    def _render_cultural_tip(self, screen):
        # Desenhar caixa de dica cultural
        tip_box = pygame.Rect(10, SCREEN_HEIGHT - 80, SCREEN_WIDTH - 20, 70)
        pygame.draw.rect(screen, (240, 240, 240, 200), tip_box)
        pygame.draw.rect(screen, BLACK, tip_box, 2)
        
        # Desenhar categoria
        category_font = pygame.font.Font(None, 20)
        category_text = category_font.render(f"[{self.current_cultural_tip['category']}]", True, (100, 100, 100))
        screen.blit(category_text, (tip_box.x + 10, tip_box.y + 10))
        
        # Desenhar título
        title_font = pygame.font.Font(None, 24)
        title_text = title_font.render(self.current_cultural_tip["title"], True, BLACK)
        screen.blit(title_text, (tip_box.x + 10 + category_text.get_width() + 10, tip_box.y + 10))
        
        # Desenhar conteúdo
        content_font = pygame.font.Font(None, 20)
        content_lines = self._wrap_text(self.current_cultural_tip["content"], content_font, tip_box.width - 20)
        for i, line in enumerate(content_lines[:2]):  # Limitar a 2 linhas
            line_text = content_font.render(line, True, BLACK)
            screen.blit(line_text, (tip_box.x + 10, tip_box.y + 35 + i * 20))
    
    def _wrap_text(self, text, font, max_width):
        """Quebra o texto em linhas para caber na largura especificada"""
        words = text.split(' ')
        lines = []
        current_line = []
        
        for word in words:
            # Testar se adicionar esta palavra excede a largura máxima
            test_line = ' '.join(current_line + [word])
            test_width = font.size(test_line)[0]
            
            if test_width <= max_width:
                current_line.append(word)
            else:
                # Se a linha atual não estiver vazia, adicioná-la às linhas
                if current_line:
                    lines.append(' '.join(current_line))
                    current_line = [word]
                else:
                    # Se a palavra sozinha é maior que a largura máxima, adicioná-la mesmo assim
                    lines.append(word)
                    current_line = []
        
        # Adicionar a última linha
        if current_line:
            lines.append(' '.join(current_line))
        
        return lines
    
    def handle_event(self, event):
        self.states[self.current_state].handle_event(event)
    
    def process_dialogue_trigger(self, trigger):
        if trigger:
            parts = trigger.split(":")
            action = parts[0]
            
            if action == "start_quest" and len(parts) > 1:
                quest_id = parts[1]
                self.quest_system.start_quest(quest_id)
            
            elif action == "objective" and len(parts) > 2:
                quest_id = parts[1]
                objective_id = parts[2]
                self.quest_system.complete_objective(quest_id, objective_id)
            
            elif action == "start_rhythm_game" and len(parts) > 1:
                song_key = parts[1]
                self.change_state("rhythm")
                self.states["rhythm"].start_song(song_key)

# Classes base para os diferentes estados do jogo
class State:
    def update(self, dt, current_time):
        pass
    
    def render(self, screen):
        pass
    
    def handle_event(self, event):
        pass

class MenuState(State):
    def __init__(self):
        self.title_font = pygame.font.Font(None, 64)
        self.menu_font = pygame.font.Font(None, 32)
        self.title_text = self.title_font.render("O Mestre do Fado", True, BLACK)
        self.start_text = self.menu_font.render("Iniciar Jogo", True, BLACK)
        self.options_text = self.menu_font.render("Opções", True, BLACK)
        self.exit_text = self.menu_font.render("Sair", True, BLACK)
        self.selected_option = 0
        self.options = ["start", "options", "exit"]
    
    def update(self, dt, current_time):
        pass
    
    def render(self, screen):
        screen.fill(WHITE)
        
        # Desenhar título
        title_rect = self.title_text.get_rect(center=(SCREEN_WIDTH/2, 100))
        screen.blit(self.title_text, title_rect)
        
        # Desenhar opções de menu
        start_rect = self.start_text.get_rect(center=(SCREEN_WIDTH/2, 250))
        options_rect = self.options_text.get_rect(center=(SCREEN_WIDTH/2, 300))
        exit_rect = self.exit_text.get_rect(center=(SCREEN_WIDTH/2, 350))
        
        # Destacar opção selecionada
        if self.selected_option == 0:
            pygame.draw.rect(screen, RED, start_rect.inflate(20, 10), 2)
        elif self.selected_option == 1:
            pygame.draw.rect(screen, RED, options_rect.inflate(20, 10), 2)
        elif self.selected_option == 2:
            pygame.draw.rect(screen, RED, exit_rect.inflate(20, 10), 2)
        
        screen.blit(self.start_text, start_rect)
        screen.blit(self.options_text, options_rect)
        screen.blit(self.exit_text, exit_rect)
        
        # Desenhar informações sobre o jogo
        info_font = pygame.font.Font(None, 24)
        info_text1 = info_font.render("Um jogo sobre a cultura portuguesa e o fado", True, BLACK)
        info_text2 = info_font.render("Explore o Alentejo e Lisboa, aprenda a tocar guitarra portuguesa", True, BLACK)
        info_text3 = info_font.render("e torne-se um verdadeiro Mestre do Fado", True, BLACK)
        
        screen.blit(info_text1, (SCREEN_WIDTH/2 - info_text1.get_width()/2, 450))
        screen.blit(info_text2, (SCREEN_WIDTH/2 - info_text2.get_width()/2, 480))
        screen.blit(info_text3, (SCREEN_WIDTH/2 - info_text3.get_width()/2, 510))
    
    def handle_event(self, event):
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_UP:
                self.selected_option = (self.selected_option - 1) % len(self.options)
            elif event.key == pygame.K_DOWN:
                self.selected_option = (self.selected_option + 1) % len(self.options)
            elif event.key == pygame.K_RETURN:
                if self.options[self.selected_option] == "start":
                    game_state.change_state("game")
                elif self.options[self.selected_option] == "options":
                    print("Opções não implementadas ainda")
                elif self.options[self.selected_option] == "exit":
                    pygame.quit()
                    sys.exit()

class GameplayState(State):
    def __init__(self, player, scene_manager, quest_system, cultural_integration):
        self.player = player
        self.scene_manager = scene_manager
        self.quest_system = quest_system
        self.cultural_integration = cultural_integration
        self.font = pygame.font.Font(None, 24)
        self.interaction_text = self.font.render("Pressione E para interagir", True, BLACK)
        self.can_interact = False
        self.interaction_target = None
        
        # Interface do jogador
        self.show_help = False
        self.help_text = [
            "Controles:",
            "Setas: Mover personagem",
            "E: Interagir com NPCs",
            "Q: Abrir registro de missões",
            "C: Abrir enciclopédia cultural",
            "ESC: Pausar jogo",
            "H: Mostrar/ocultar ajuda"
        ]
    
    def update(self, dt, current_time):
        # Atualizar cena atual
        self.scene_manager.update(current_time)
        
        # Atualizar jogador
        self.player.update(current_time)
        
        # Verificar interações possíveis
        self.can_interact = False
        self.interaction_target = None
        
        current_scene = self.scene_manager.get_current_scene()
        if current_scene:
            # Verificar colisão com NPCs
            for npc in current_scene.npcs:
                if self.player.rect.colliderect(npc.interaction_rect):
                    self.can_interact = True
                    self.interaction_target = npc
                    break
            
            # Verificar colisão com saídas
            for exit in current_scene.exits:
                if self.player.rect.colliderect(exit["rect"]):
                    # Mudar para a nova cena
                    new_scene = exit["target_scene"]
                    self.scene_manager.change_scene(new_scene)
                    
                    # Posicionar o jogador no ponto de entrada da nova cena
                    self.player.rect.x = exit["target_position"][0]
                    self.player.rect.y = exit["target_position"][1]
                    
                    # Verificar objetivos de missão relacionados a locais
                    if new_scene == "lisboa":
                        self.quest_system.complete_objective("lisboa_journey", "reach_lisboa")
                    elif new_scene == "casa_fado":
                        self.quest_system.complete_objective("first_performance", "visit_fado_house")
                    
                    break
    
    def render(self, screen):
        screen.fill(WHITE)
        
        # Renderizar cena atual
        self.scene_manager.render(screen)
        
        # Renderizar jogador
        screen.blit(self.player.image, self.player.rect)
        
        # Mostrar texto de interação se possível
        if self.can_interact:
            text_rect = self.interaction_text.get_rect(center=(SCREEN_WIDTH/2, 50))
            screen.blit(self.interaction_text, text_rect)
        
        # Mostrar informações da cena atual
        scene_name = self.scene_manager.current_scene
        scene_text = self.font.render(f"Local: {self._get_location_name(scene_name)}", True, BLACK)
        screen.blit(scene_text, (20, 20))
        
        # Mostrar ajuda se ativada
        if self.show_help:
            help_bg = pygame.Rect(SCREEN_WIDTH - 250, 20, 230, 200)
            pygame.draw.rect(screen, (240, 240, 240), help_bg)
            pygame.draw.rect(screen, BLACK, help_bg, 2)
            
            for i, line in enumerate(self.help_text):
                help_line = self.font.render(line, True, BLACK)
                screen.blit(help_line, (help_bg.x + 10, help_bg.y + 10 + i * 25))
    
    def _get_location_name(self, scene_id):
        """Retorna o nome formatado da localização"""
        if scene_id == "aldeia":
            return "Aldeia Alentejana"
        elif scene_id == "lisboa":
            return "Lisboa - Alfama"
        elif scene_id == "casa_fado":
            return "Casa de Fado"
        return scene_id
    
    def handle_event(self, event):
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                game_state.change_state("pause")
            elif event.key == pygame.K_e and self.can_interact:
                game_state.change_state("dialogue")
                dialogue_data = self.interaction_target.dialogue_data
                if "dialogue_id" in dialogue_data:
                    game_state.states["dialogue"].start_dialogue(dialogue_data["dialogue_id"])
                else:
                    game_state.states["dialogue"].start_dialogue_direct(dialogue_data)
            elif event.key == pygame.K_q:
                game_state.change_state("quest_log")
            elif event.key == pygame.K_c:
                game_state.change_state("encyclopedia")
            elif event.key == pygame.K_h:
                self.show_help = not self.show_help
            
            # Controles de movimento
            if event.key == pygame.K_LEFT:
                self.player.direction["left"] = True
            elif event.key == pygame.K_RIGHT:
                self.player.direction["right"] = True
            elif event.key == pygame.K_UP:
                self.player.direction["up"] = True
            elif event.key == pygame.K_DOWN:
                self.player.direction["down"] = True
        
        elif event.type == pygame.KEYUP:
            if event.key == pygame.K_LEFT:
                self.player.direction["left"] = False
            elif event.key == pygame.K_RIGHT:
                self.player.direction["right"] = False
            elif event.key == pygame.K_UP:
                self.player.direction["up"] = False
            elif event.key == pygame.K_DOWN:
                self.player.direction["down"] = False
        
        # Atualizar estado de movimento do jogador
        self.player.is_moving = any(self.player.direction.values())
        
        # Calcular movimento
        dx = 0
        dy = 0
        
        if self.player.direction["left"]:
            dx -= 1
        if self.player.direction["right"]:
            dx += 1
        if self.player.direction["up"]:
            dy -= 1
        if self.player.direction["down"]:
            dy += 1
        
        # Mover jogador
        self.player.move(dx, dy)

class DialogueState(State):
    def __init__(self, dialogue_system, quest_system):
        self.dialogue_system = dialogue_system
        self.quest_system = quest_system
        self.font = pygame.font.Font(None, 28)
        self.dialogue_box = pygame.Rect(50, 400, SCREEN_WIDTH - 100, 150)
        self.current_dialogue_id = None
        self.current_dialogue = None
        self.current_line = 0
        self.text_speed = 2  # caracteres por frame
        self.text_progress = 0
        self.current_text = ""
        self.dialogue_complete = False
        self.speaker_name = ""
        self.name_font = pygame.font.Font(None, 32)
        self.show_responses = False
        self.selected_response = 0
        self.responses = []
    
    def start_dialogue(self, dialogue_id):
        """Inicia um diálogo a partir do ID"""
        dialogue = self.dialogue_system.get_dialogue(dialogue_id)
        if dialogue:
            self.current_dialogue_id = dialogue_id
            self.current_dialogue = dialogue
            self.speaker_name = dialogue["speaker"]
            self.current_line = 0
            self.text_progress = 0
            self.current_text = ""
            self.dialogue_complete = False
            self.show_responses = False
            self.selected_response = 0
            self.responses = dialogue.get("responses", [])
    
    def start_dialogue_direct(self, dialogue_data):
        """Inicia um diálogo diretamente a partir dos dados"""
        if dialogue_data:
            self.current_dialogue_id = None
            self.current_dialogue = dialogue_data
            self.speaker_name = dialogue_data["speaker"]
            self.current_line = 0
            self.text_progress = 0
            self.current_text = ""
            self.dialogue_complete = False
            self.show_responses = False
            self.selected_response = 0
            self.responses = []
    
    def update(self, dt, current_time):
        if self.current_dialogue:
            if not self.show_responses:
                # Mostrar texto gradualmente
                if self.current_line < len(self.current_dialogue["lines"]):
                    full_text = self.current_dialogue["lines"][self.current_line]
                    
                    if self.text_progress < len(full_text):
                        self.text_progress += self.text_speed
                        self.current_text = full_text[:int(self.text_progress)]
                    else:
                        self.dialogue_complete = True
    
    def render(self, screen):
        # Manter o fundo do estado anterior
        game_state.states["game"].render(screen)
        
        # Desenhar caixa de diálogo
        pygame.draw.rect(screen, WHITE, self.dialogue_box)
        pygame.draw.rect(screen, BLACK, self.dialogue_box, 2)
        
        # Desenhar nome do falante
        name_bg = pygame.Rect(self.dialogue_box.x, self.dialogue_box.y - 30, 150, 30)
        pygame.draw.rect(screen, WHITE, name_bg)
        pygame.draw.rect(screen, BLACK, name_bg, 2)
        
        name_text = self.name_font.render(self.speaker_name, True, BLACK)
        screen.blit(name_text, (name_bg.x + 10, name_bg.y + 5))
        
        # Desenhar texto atual
        text_surface = self.font.render(self.current_text, True, BLACK)
        screen.blit(text_surface, (self.dialogue_box.x + 20, self.dialogue_box.y + 20))
        
        if self.show_responses:
            # Desenhar opções de resposta
            response_box = pygame.Rect(self.dialogue_box.x, self.dialogue_box.y + self.dialogue_box.height + 10, 
                                      self.dialogue_box.width, 30 * len(self.responses))
            pygame.draw.rect(screen, WHITE, response_box)
            pygame.draw.rect(screen, BLACK, response_box, 2)
            
            for i, response in enumerate(self.responses):
                response_text = self.font.render(response["text"], True, BLACK)
                response_y = response_box.y + 10 + i * 30
                
                # Destacar resposta selecionada
                if i == self.selected_response:
                    response_rect = pygame.Rect(response_box.x + 5, response_y - 5, 
                                              response_box.width - 10, 30)
                    pygame.draw.rect(screen, (200, 200, 255), response_rect)
                
                screen.blit(response_text, (response_box.x + 20, response_y))
        
        elif self.dialogue_complete:
            # Indicador para continuar
            continue_text = self.font.render("Pressione ESPAÇO para continuar", True, BLACK)
            screen.blit(continue_text, (self.dialogue_box.right - 300, self.dialogue_box.bottom - 30))
    
    def handle_event(self, event):
        if event.type == pygame.KEYDOWN:
            if self.show_responses:
                # Navegação entre respostas
                if event.key == pygame.K_UP:
                    self.selected_response = (self.selected_response - 1) % len(self.responses)
                elif event.key == pygame.K_DOWN:
                    self.selected_response = (self.selected_response + 1) % len(self.responses)
                elif event.key == pygame.K_RETURN or event.key == pygame.K_SPACE:
                    # Processar resposta selecionada
                    selected = self.responses[self.selected_response]
                    result = self.dialogue_system.process_response(self.current_dialogue_id, self.selected_response)
                    
                    if result:
                        # Processar gatilhos
                        if result["trigger"]:
                            game_state.process_dialogue_trigger(result["trigger"])
                        
                        # Mudar para próximo diálogo ou voltar ao jogo
                        next_dialogue = result["next_dialogue"]
                        if next_dialogue:
                            self.start_dialogue(next_dialogue)
                        else:
                            game_state.change_state("game")
                    else:
                        game_state.change_state("game")
            
            elif event.key == pygame.K_SPACE:
                if self.dialogue_complete:
                    self.current_line += 1
                    if self.current_line >= len(self.current_dialogue["lines"]):
                        # Verificar se há respostas para mostrar
                        if "responses" in self.current_dialogue and self.current_dialogue["responses"]:
                            self.show_responses = True
                            self.responses = self.current_dialogue["responses"]
                            self.selected_response = 0
                        else:
                            game_state.change_state("game")
                    else:
                        self.text_progress = 0
                        self.current_text = ""
                        self.dialogue_complete = False
                else:
                    # Mostrar todo o texto imediatamente
                    self.text_progress = len(self.current_dialogue["lines"][self.current_line])
                    self.current_text = self.current_dialogue["lines"][self.current_line]
                    self.dialogue_complete = True

class RhythmGameState(State):
    def __init__(self, music_system, quest_system):
        self.music_system = music_system
        self.quest_system = quest_system
        self.font = pygame.font.Font(None, 36)
        self.back_button = pygame.Rect(20, 20, 100, 40)
        self.back_text = self.font.render("Voltar", True, BLACK)
        self.current_song = None
        self.difficulty = "normal"
    
    def start_song(self, song_key, difficulty="normal"):
        self.current_song = song_key
        self.difficulty = difficulty
        self.music_system.start_song(song_key, difficulty)
    
    def update(self, dt, current_time):
        self.music_system.update(current_time)
        
        # Verificar se a música terminou para atualizar objetivos de missão
        if self.music_system.song_finished:
            if self.current_song == "fado_basico":
                self.quest_system.complete_objective("tutorial", "play_basic_rhythm")
                self.quest_system.complete_objective("tutorial", "learn_basic_chord")
            elif self.current_song == "fado_lisboa":
                self.quest_system.complete_objective("lisboa_journey", "learn_lisboa_style")
            elif self.current_song == "fado_mestre":
                self.quest_system.complete_objective("first_performance", "perform_song")
    
    def render(self, screen):
        self.music_system.render(screen)
        
        # Botão de voltar
        pygame.draw.rect(screen, WHITE, self.back_button)
        pygame.draw.rect(screen, BLACK, self.back_button, 2)
        screen.blit(self.back_text, (self.back_button.x + 10, self.back_button.y + 10))
    
    def handle_event(self, event):
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                game_state.change_state("game")
            elif event.key == pygame.K_SPACE and self.music_system.song_finished:
                game_state.change_state("game")
            
            # Verificar teclas de ritmo
            if event.key == pygame.K_a:
                self.music_system.check_hit(0)
            elif event.key == pygame.K_s:
                self.music_system.check_hit(1)
            elif event.key == pygame.K_d:
                self.music_system.check_hit(2)
            elif event.key == pygame.K_f:
                self.music_system.check_hit(3)
        
        elif event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 1:  # Botão esquerdo do mouse
                if self.back_button.collidepoint(event.pos):
                    game_state.change_state("game")

class PauseState(State):
    def __init__(self):
        self.font = pygame.font.Font(None, 48)
        self.pause_text = self.font.render("JOGO PAUSADO", True, BLACK)
        self.resume_text = self.font.render("Continuar", True, BLACK)
        self.menu_text = self.font.render("Menu Principal", True, BLACK)
        self.selected_option = 0
        self.options = ["resume", "menu"]
    
    def update(self, dt, current_time):
        pass
    
    def render(self, screen):
        # Semi-transparente sobre o jogo
        game_state.states["game"].render(screen)
        overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 128))
        screen.blit(overlay, (0, 0))
        
        # Texto de pausa
        pause_rect = self.pause_text.get_rect(center=(SCREEN_WIDTH/2, 150))
        screen.blit(self.pause_text, pause_rect)
        
        # Opções
        resume_rect = self.resume_text.get_rect(center=(SCREEN_WIDTH/2, 250))
        menu_rect = self.menu_text.get_rect(center=(SCREEN_WIDTH/2, 300))
        
        # Destacar opção selecionada
        if self.selected_option == 0:
            pygame.draw.rect(screen, RED, resume_rect.inflate(20, 10), 2)
        else:
            pygame.draw.rect(screen, RED, menu_rect.inflate(20, 10), 2)
        
        screen.blit(self.resume_text, resume_rect)
        screen.blit(self.menu_text, menu_rect)
    
    def handle_event(self, event):
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_UP or event.key == pygame.K_DOWN:
                self.selected_option = 1 - self.selected_option
            elif event.key == pygame.K_RETURN:
                if self.options[self.selected_option] == "resume":
                    game_state.change_state("game")
                elif self.options[self.selected_option] == "menu":
                    game_state.change_state("menu")
            elif event.key == pygame.K_ESCAPE:
                game_state.change_state("game")

class QuestLogState(State):
    def __init__(self, quest_system):
        self.quest_system = quest_system
        self.font_title = pygame.font.Font(None, 36)
        self.font_quest = pygame.font.Font(None, 28)
        self.font_objective = pygame.font.Font(None, 24)
        self.scroll_offset = 0
        self.max_scroll = 0
    
    def update(self, dt, current_time):
        # Calcular scroll máximo baseado no número de missões
        active_quests = self.quest_system.get_active_quests()
        self.max_scroll = max(0, len(active_quests) * 150 - 400)  # 150 pixels por missão, 400 pixels de área visível
    
    def render(self, screen):
        # Semi-transparente sobre o jogo
        game_state.states["game"].render(screen)
        overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 180))
        screen.blit(overlay, (0, 0))
        
        # Título
        title_text = self.font_title.render("Registro de Missões", True, WHITE)
        title_rect = title_text.get_rect(center=(SCREEN_WIDTH/2, 50))
        screen.blit(title_text, title_rect)
        
        # Área de missões
        quest_area = pygame.Rect(100, 100, SCREEN_WIDTH - 200, 400)
        pygame.draw.rect(screen, (50, 50, 50), quest_area)
        pygame.draw.rect(screen, WHITE, quest_area, 2)
        
        # Renderizar missões ativas
        active_quests = self.quest_system.get_active_quests()
        y_offset = quest_area.y - self.scroll_offset
        
        for quest in active_quests:
            # Verificar se a missão está na área visível
            if y_offset + 150 > quest_area.y and y_offset < quest_area.y + quest_area.height:
                # Fundo da missão
                quest_bg = pygame.Rect(quest_area.x + 10, y_offset + 10, quest_area.width - 20, 130)
                pygame.draw.rect(screen, (80, 80, 80), quest_bg)
                pygame.draw.rect(screen, (150, 150, 150), quest_bg, 2)
                
                # Título da missão
                quest_title = self.font_quest.render(quest["title"], True, WHITE)
                screen.blit(quest_title, (quest_bg.x + 10, quest_bg.y + 10))
                
                # Descrição da missão
                quest_desc = self.font_objective.render(quest["description"], True, (200, 200, 200))
                screen.blit(quest_desc, (quest_bg.x + 10, quest_bg.y + 40))
                
                # Objetivos
                obj_y = quest_bg.y + 70
                for objective in quest["objectives"]:
                    # Ícone de status
                    status_color = GREEN if objective["completed"] else (150, 150, 150)
                    pygame.draw.rect(screen, status_color, (quest_bg.x + 10, obj_y + 5, 10, 10))
                    
                    # Texto do objetivo
                    obj_text = self.font_objective.render(objective["description"], True, WHITE)
                    screen.blit(obj_text, (quest_bg.x + 30, obj_y))
                    
                    obj_y += 20
            
            y_offset += 150
        
        # Instruções
        instructions = self.font_objective.render("Use as setas para navegar, ESC ou Q para voltar", True, WHITE)
        instructions_rect = instructions.get_rect(center=(SCREEN_WIDTH/2, SCREEN_HEIGHT - 50))
        screen.blit(instructions, instructions_rect)
    
    def handle_event(self, event):
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE or event.key == pygame.K_q:
                game_state.change_state("game")
            elif event.key == pygame.K_UP:
                self.scroll_offset = max(0, self.scroll_offset - 30)
            elif event.key == pygame.K_DOWN:
                self.scroll_offset = min(self.max_scroll, self.scroll_offset + 30)

class EncyclopediaState(State):
    def __init__(self, cultural_integration):
        self.cultural_integration = cultural_integration
    
    def update(self, dt, current_time):
        pass
    
    def render(self, screen):
        self.cultural_integration.render_cultural_encyclopedia(screen)
    
    def handle_event(self, event):
        # Processar eventos da enciclopédia
        if not self.cultural_integration.handle_encyclopedia_event(event):
            game_state.change_state("game")

# Inicialização do estado do jogo
game_state = GameState()

# Loop principal do jogo
def main():
    clock = pygame.time.Clock()
    running = True
    
    while running:
        current_time = pygame.time.get_ticks()
        dt = clock.tick(60) / 1000.0  # Delta time em segundos
        
        # Processar eventos
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            
            # Passar evento para o estado atual
            game_state.handle_event(event)
        
        # Atualizar
        game_state.update(dt, current_time)
        
        # Renderizar
        game_state.render(screen)
        
        # Atualizar tela
        pygame.display.flip()
    
    pygame.quit()
    sys.exit()

if __name__ == "__main__":
    main()
