import unittest
import os
import sys
import pygame
from unittest.mock import patch, MagicMock

# Adicionar o diretório do projeto ao path para importar os módulos
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# Importar os módulos do jogo para testar
try:
    from cultural_elements import CulturalElements, PortugueseMusic, PortugueseArt
    from cultural_integration import CulturalIntegration
    from game_mechanics import MusicRhythmSystem, QuestSystem, DialogueSystem
except ImportError as e:
    print(f"Erro ao importar módulos: {e}")

class TestCulturalElements(unittest.TestCase):
    """Testes para o módulo de elementos culturais"""
    
    def setUp(self):
        """Configuração inicial para os testes"""
        self.cultural_elements = CulturalElements()
        self.portuguese_music = PortugueseMusic()
        self.portuguese_art = PortugueseArt()
    
    def test_fado_facts_loaded(self):
        """Verifica se os fatos sobre o fado foram carregados corretamente"""
        self.assertIsNotNone(self.cultural_elements.fado_facts)
        self.assertGreater(len(self.cultural_elements.fado_facts), 0)
        
        # Verificar estrutura de um fato
        fact = self.cultural_elements.fado_facts[0]
        self.assertIn("title", fact)
        self.assertIn("content", fact)
    
    def test_proverbs_loaded(self):
        """Verifica se os provérbios foram carregados corretamente"""
        self.assertIsNotNone(self.cultural_elements.portuguese_proverbs)
        self.assertGreater(len(self.cultural_elements.portuguese_proverbs), 0)
        
        # Verificar estrutura de um provérbio
        proverb = self.cultural_elements.portuguese_proverbs[0]
        self.assertIn("proverb", proverb)
        self.assertIn("meaning", proverb)
    
    def test_landmarks_loaded(self):
        """Verifica se os marcos culturais foram carregados corretamente"""
        self.assertIsNotNone(self.cultural_elements.cultural_landmarks)
        self.assertGreater(len(self.cultural_elements.cultural_landmarks), 0)
        
        # Verificar estrutura de um marco cultural
        landmark = self.cultural_elements.cultural_landmarks[0]
        self.assertIn("name", landmark)
        self.assertIn("location", landmark)
        self.assertIn("description", landmark)
    
    def test_foods_loaded(self):
        """Verifica se as comidas tradicionais foram carregadas corretamente"""
        self.assertIsNotNone(self.cultural_elements.traditional_foods)
        self.assertGreater(len(self.cultural_elements.traditional_foods), 0)
        
        # Verificar estrutura de uma comida
        food = self.cultural_elements.traditional_foods[0]
        self.assertIn("name", food)
        self.assertIn("region", food)
        self.assertIn("description", food)
    
    def test_music_loaded(self):
        """Verifica se as músicas foram carregadas corretamente"""
        self.assertIsNotNone(self.portuguese_music.fado_songs)
        self.assertGreater(len(self.portuguese_music.fado_songs), 0)
        
        # Verificar estrutura de uma música
        song = self.portuguese_music.fado_songs[0]
        self.assertIn("title", song)
        self.assertIn("artist", song)
        self.assertIn("description", song)
    
    def test_instruments_loaded(self):
        """Verifica se os instrumentos foram carregados corretamente"""
        self.assertIsNotNone(self.portuguese_music.traditional_instruments)
        self.assertGreater(len(self.portuguese_music.traditional_instruments), 0)
        
        # Verificar estrutura de um instrumento
        instrument = self.portuguese_music.traditional_instruments[0]
        self.assertIn("name", instrument)
        self.assertIn("description", instrument)
        self.assertIn("origin", instrument)
    
    def test_art_loaded(self):
        """Verifica se os elementos de arte foram carregados corretamente"""
        self.assertIsNotNone(self.portuguese_art.azulejos)
        self.assertGreater(len(self.portuguese_art.azulejos), 0)
        
        self.assertIsNotNone(self.portuguese_art.traditional_crafts)
        self.assertGreater(len(self.portuguese_art.traditional_crafts), 0)
        
        # Verificar estrutura de um azulejo
        azulejo = self.portuguese_art.azulejos[0]
        self.assertIn("name", azulejo)
        self.assertIn("period", azulejo)
        self.assertIn("description", azulejo)
        
        # Verificar estrutura de um artesanato
        craft = self.portuguese_art.traditional_crafts[0]
        self.assertIn("name", craft)
        self.assertIn("region", craft)
        self.assertIn("description", craft)

class TestGameMechanics(unittest.TestCase):
    """Testes para o módulo de mecânicas do jogo"""
    
    def setUp(self):
        """Configuração inicial para os testes"""
        # Mock do pygame para evitar inicialização real
        self.pygame_mock = MagicMock()
        with patch('pygame.init'), patch('pygame.font.Font'):
            self.music_system = MusicRhythmSystem(800, 600)
            self.quest_system = QuestSystem()
            self.dialogue_system = DialogueSystem()
    
    def test_music_rhythm_system_initialization(self):
        """Verifica se o sistema de ritmo musical foi inicializado corretamente"""
        self.assertEqual(self.music_system.screen_width, 800)
        self.assertEqual(self.music_system.screen_height, 600)
        self.assertEqual(self.music_system.lanes, 4)
        self.assertEqual(self.music_system.score, 0)
        self.assertEqual(self.music_system.combo, 0)
        
        # Verificar se as músicas foram carregadas
        self.assertIn("fado_basico", self.music_system.songs)
        self.assertIn("fado_lisboa", self.music_system.songs)
        self.assertIn("cante_alentejano", self.music_system.songs)
        self.assertIn("fado_mestre", self.music_system.songs)
    
    def test_quest_system_initialization(self):
        """Verifica se o sistema de missões foi inicializado corretamente"""
        # Verificar se as missões foram carregadas
        self.assertIn("tutorial", self.quest_system.quests)
        self.assertIn("repair_guitar", self.quest_system.quests)
        self.assertIn("lisboa_journey", self.quest_system.quests)
        self.assertIn("first_performance", self.quest_system.quests)
        self.assertIn("master_quest", self.quest_system.quests)
        
        # Verificar estrutura de uma missão
        quest = self.quest_system.quests["tutorial"]
        self.assertIn("title", quest)
        self.assertIn("description", quest)
        self.assertIn("objectives", quest)
        self.assertIn("reward", quest)
    
    def test_quest_system_functionality(self):
        """Verifica a funcionalidade do sistema de missões"""
        # Iniciar missão
        result = self.quest_system.start_quest("tutorial")
        self.assertTrue(result)
        self.assertIn("tutorial", self.quest_system.active_quests)
        
        # Completar objetivo
        result = self.quest_system.complete_objective("tutorial", "talk_to_antonio")
        self.assertTrue(result)
        
        # Verificar se o objetivo foi marcado como concluído
        quest = self.quest_system.quests["tutorial"]
        objective = next(obj for obj in quest["objectives"] if obj["id"] == "talk_to_antonio")
        self.assertTrue(objective["completed"])
    
    def test_dialogue_system_initialization(self):
        """Verifica se o sistema de diálogos foi inicializado corretamente"""
        # Verificar se os diálogos foram carregados
        self.assertIn("mestre_antonio_intro", self.dialogue_system.dialogues)
        self.assertIn("ana_intro", self.dialogue_system.dialogues)
        
        # Verificar estrutura de um diálogo
        dialogue = self.dialogue_system.dialogues["mestre_antonio_intro"]
        self.assertIn("speaker", dialogue)
        self.assertIn("lines", dialogue)
        self.assertIn("responses", dialogue)
    
    def test_dialogue_system_functionality(self):
        """Verifica a funcionalidade do sistema de diálogos"""
        # Obter diálogo
        dialogue = self.dialogue_system.get_dialogue("mestre_antonio_intro")
        self.assertIsNotNone(dialogue)
        self.assertEqual(dialogue["speaker"], "Mestre António")
        
        # Processar resposta
        result = self.dialogue_system.process_response("mestre_antonio_intro", 0)
        self.assertIsNotNone(result)
        self.assertIn("next_dialogue", result)
        self.assertIn("trigger", result)

class TestCulturalIntegration(unittest.TestCase):
    """Testes para o módulo de integração cultural"""
    
    def setUp(self):
        """Configuração inicial para os testes"""
        # Mock do pygame para evitar inicialização real
        with patch('pygame.init'), patch('pygame.font.Font'):
            self.cultural_integration = CulturalIntegration(800, 600)
    
    def test_cultural_integration_initialization(self):
        """Verifica se a integração cultural foi inicializada corretamente"""
        self.assertEqual(self.cultural_integration.screen_width, 800)
        self.assertEqual(self.cultural_integration.screen_height, 600)
        
        # Verificar se os dados culturais foram carregados
        self.assertIsNotNone(self.cultural_integration.cultural_elements)
        self.assertIsNotNone(self.cultural_integration.portuguese_music)
        self.assertIsNotNone(self.cultural_integration.portuguese_art)
    
    def test_get_random_cultural_tip(self):
        """Verifica se as dicas culturais aleatórias funcionam corretamente"""
        tip = self.cultural_integration.get_random_cultural_tip()
        self.assertIsNotNone(tip)
        self.assertIn("title", tip)
        self.assertIn("content", tip)
        self.assertIn("category", tip)
    
    def test_get_cultural_quiz_question(self):
        """Verifica se as perguntas de quiz cultural funcionam corretamente"""
        question = self.cultural_integration.get_cultural_quiz_question()
        
        # O quiz pode retornar None em alguns casos, então verificamos apenas se não causa erro
        if question:
            self.assertIn("question", question)
            self.assertIn("answers", question)
            self.assertIn("correct_index", question)
            self.assertIn("category", question)
    
    def test_wrap_text_functionality(self):
        """Verifica a funcionalidade de quebra de texto sem usar mock"""
        # Criar uma classe simulada para substituir o Font
        class MockFont:
            def size(self, text):
                # Retorna um tamanho proporcional ao comprimento do texto
                return (len(text) * 10, 20)
        
        # Usar a classe simulada em vez de tentar fazer mock do pygame.font.Font
        mock_font = MockFont()
        
        # Testar a função _wrap_text diretamente
        text = "Este é um texto longo que deve ser quebrado em várias linhas para caber na largura especificada."
        max_width = 200  # 20 caracteres por linha
        
        # Chamar a função diretamente
        lines = self.cultural_integration._wrap_text(text, mock_font, max_width)
        
        # Verificar se o texto foi quebrado em várias linhas
        self.assertGreater(len(lines), 1)
        
        # Verificar se cada linha tem comprimento adequado
        for line in lines:
            # Cada linha deve ter menos de 20 caracteres (exceto talvez a última)
            self.assertLessEqual(len(line), 30)

if __name__ == '__main__':
    unittest.main()
