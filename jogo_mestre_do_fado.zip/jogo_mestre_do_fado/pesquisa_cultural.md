# Pesquisa Cultural para o Jogo "O Mestre do Fado"

## História e Origens do Fado

O fado é um gênero musical tradicional português que se desenvolveu principalmente em Lisboa a partir do final do século XIX. Nascido nos contextos populares da Lisboa oitocentista, o fado estava presente nos momentos de convívio e lazer, manifestando-se de forma espontânea em diversos ambientes como hortas, esperas de touros, retiros, ruas, vielas, tabernas e cafés.

Inicialmente, o fado estava associado a contextos sociais marginais, frequentado por prostitutas, faias, marujos, boleeiros e marialvas. A história do fado cristalizou em mito o episódio do envolvimento amoroso do Conde de Vimioso com Maria Severa Onofriana (1820-1846), meretriz consagrada pelos seus dotes de cantadeira, que se transformou num dos grandes mitos da História do Fado.

A partir das primeiras décadas do século XX, o fado conheceu uma gradual divulgação e consagração popular através da publicação de periódicos dedicados ao tema e da consolidação de novos espaços performativos. O aparecimento das companhias de fadistas profissionais a partir da década de 30 permitiu a promoção de espetáculos com elencos de renome e sua circulação pelos teatros de norte a sul do país, e mesmo em digressões internacionais.

Em 27 de novembro de 2011, a UNESCO reconheceu o fado como Patrimônio Cultural Imaterial da Humanidade.

## Cante Alentejano

O cante alentejano é um gênero musical tradicional do Alentejo, Portugal. Em 27 de novembro de 2014, a UNESCO considerou o cante alentejano como Patrimônio Cultural Imaterial da Humanidade.

É um canto coral, em que alternam um "ponto" a sós e um coro, havendo um "alto" preenchendo as pausas e rematando as estrofes. O canto começa invariavelmente com um "ponto" dando a deixa, cedendo o lugar ao "alto" e logo intervindo o coro em que participam também o "ponto" e o "alto".

No cante são utilizados modos gregos extintos tanto na música erudita como na popular europeia. Esta face helênica do cante poderá provir tanto do canto gregoriano como da cultura árabe, embora certos musicólogos percebam no cante aspectos mais primitivos, pré-cristãos e possivelmente pré-romanos.

Antigamente, o cante acompanhava ambos os sexos nos trabalhos da lavoura, embora fosse mais típico de homens. Também era cantado nos momentos masculinos de ócio e libação, seja em quietude, seja em percurso nas chamadas "arruadas". Havia ainda o cante mais solene das ocasiões religiosas e o cante doméstico, exercido principalmente por mulheres e no qual participariam também crianças.

## Instrumentos Musicais Tradicionais Portugueses

### Guitarra Portuguesa

A guitarra portuguesa é um instrumento musical de cordas fundamental para o fado. Existem principalmente dois tipos: a guitarra de Lisboa e a guitarra de Coimbra, que diferem em tamanho, forma e afinação.

A guitarra portuguesa representa, tanto ao nível da afinação como ao nível da construção, um dos desenvolvimentos diretos do cistre europeu renascentista. Este instrumento esteve fortemente presente na música de corte de toda a Europa, especialmente na Itália, França e Inglaterra desde meados do século XVI até finais do século XVIII.

A afinação de Lisboa é atualmente a mais utilizada na guitarra portuguesa. Inicialmente era chamada de "afinação do fado" ou "afinação do fado corrido", tendo provavelmente sido desenvolvida no início do século XIX, sendo majoritariamente adotada pelos fadistas de Lisboa em meados desse século.

Guitarristas notáveis incluem Carlos Paredes, Artur Paredes, António Chainho, entre outros, que contribuíram significativamente para o desenvolvimento e popularização do instrumento.

## Paisagens Alentejanas

O Alentejo é caracterizado por suas vastas planícies e pelo montado, um ecossistema florestal típico da região. O montado é caracterizado pela presença de azinheiras, sobreiros (árvore da qual se extrai a cortiça), carvalhos e castanheiros, alinhados em paisagens que lembram savanas.

As paisagens alentejanas são marcadas por:
- Planícies a perder de vista
- Montados de sobreiros e azinheiras
- Campos de cereais com tons ocres
- Pequenas aldeias brancas
- Castelos e fortificações históricas
- Barragens e lagos (como o Alqueva)

A região é conhecida por seu ritmo de vida mais lento e pela valorização da simplicidade, da comunidade e das tradições.

## Vestimentas Tradicionais Alentejanas

### Traje Masculino
- Chapéu de pano desabado, às vezes com uma fita de cor e uma grande borla preta à esquerda
- Jaqueta
- Cinta (faixa) vermelha a apertar as calças
- No trabalho de campo no verão: chapéu de pano, lenço ao pescoço, camisa e camisola de riscado, ceroulas e calças, peúgos e sapatos grossos
- No inverno: gorro (carapuça ou barrete saloio) preto por fora e pinhão por dentro, samarro sobre os ombros, camisola, colete, camisa, calças de saragoça forte, ceroulas e "acefões" encorreados, sapatos grossos ou botas

### Traje Feminino
- Saias longas (no trabalho de campo, dobradas e atadas em volta das pernas formando "calças")
- Aventais bordados
- Blusas com rendas
- Lenço de sarja na cabeça, atado atrás na nuca, com chapéu de pano por cima (para proteção do sol e chuva)
- Mangueiras de riscado nos braços
- No inverno: lenço de malha ao pescoço, xailes grandes em bico
- Saia de castorina (geralmente encarnada) à roda da cintura

## Tradições e Costumes Alentejanos

O Alentejo é uma região com uma cultura bem definida, onde cada povoação tem suas histórias peculiares, tradições gastronômicas e costumes que a distinguem das outras. A região é conhecida pela lentidão do passar do tempo e pela valorização da simplicidade.

A gastronomia alentejana é rica e variada, com destaque para:
- Açordas (sopas com pão alentejano)
- Migas (acompanhamento de pratos de carne)
- Queijos, enchidos, presunto
- Doces como queijadas, pastéis de toucinho, pão de rala, sericaia

O vinho alentejano é reconhecido internacionalmente, com oito sub-regiões de Denominação de Origem Alentejo: Borba, Évora, Granja-Amareleja, Moura, Portalegre, Redondo, Reguengos de Monsaraz e Vidigueira.

O artesanato tradicional inclui as mantas alentejanas, feitas em teares com lã de ovelha, com destaque para Reguengos de Monsaraz e Mértola.

A região também é rica em monumentos megalíticos, com mais de cem menires isolados, perto de oitocentas antas e cerca de quatrocentas e cinquenta povoações megalíticas apenas no distrito de Évora.
