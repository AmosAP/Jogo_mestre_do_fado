import pygame
import os
import json
import random
from cultural_elements import CulturalElements, PortugueseMusic, PortugueseArt

class CulturalIntegration:
    def __init__(self, screen_width, screen_height):
        self.screen_width = screen_width
        self.screen_height = screen_height
        
        # Carregar elementos culturais
        self.cultural_elements = CulturalElements()
        self.portuguese_music = PortugueseMusic()
        self.portuguese_art = PortugueseArt()
        
        # Carregar dados dos arquivos JSON
        self.data_dir = os.path.join(os.path.dirname(__file__), "resources", "data")
        self.fado_facts = self._load_json_data('fado_facts.json')
        self.proverbs = self._load_json_data('portuguese_proverbs.json')
        self.landmarks = self._load_json_data('cultural_landmarks.json')
        self.foods = self._load_json_data('traditional_foods.json')
        
        # Configurações da interface
        self.font_title = pygame.font.Font(None, 36)
        self.font_content = pygame.font.Font(None, 24)
        self.font_small = pygame.font.Font(None, 18)
        
        # Estado atual
        self.current_category = "fado_facts"
        self.current_item_index = 0
        self.scroll_offset = 0
        self.max_scroll = 0
    
    def _load_json_data(self, filename):
        """Carrega dados de um arquivo JSON"""
        try:
            with open(os.path.join(self.data_dir, filename), 'r', encoding='utf-8') as f:
                return json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            print(f"Erro ao carregar {filename}")
            return []
    
    def get_random_cultural_tip(self):
        """Retorna uma dica cultural aleatória para mostrar durante o jogo"""
        categories = [
            ("Fado", self.fado_facts),
            ("Provérbio", self.proverbs),
            ("Local", self.landmarks),
            ("Gastronomia", self.foods),
            ("Música", self.portuguese_music.fado_songs),
            ("Instrumento", self.portuguese_music.traditional_instruments),
            ("Arte", self.portuguese_art.azulejos + self.portuguese_art.traditional_crafts)
        ]
        
        category_name, category_data = random.choice(categories)
        
        if not category_data:
            return {"title": "Cultura Portuguesa", "content": "Portugal tem uma rica tradição cultural."}
        
        item = random.choice(category_data)
        
        if category_name == "Fado":
            return {
                "title": item["title"],
                "content": item["content"],
                "category": "Fado"
            }
        elif category_name == "Provérbio":
            return {
                "title": "Provérbio Português",
                "content": f'"{item["proverb"]}" - {item["meaning"]}',
                "category": "Provérbio"
            }
        elif category_name == "Local":
            return {
                "title": item["name"],
                "content": f"{item['location']}: {item['description']}",
                "category": "Local"
            }
        elif category_name == "Gastronomia":
            return {
                "title": item["name"],
                "content": f"{item['region']}: {item['description']}",
                "category": "Gastronomia"
            }
        elif category_name == "Música":
            return {
                "title": item["title"],
                "content": f"{item['artist']} ({item['year']}): {item['description']}",
                "category": "Música"
            }
        elif category_name == "Instrumento":
            return {
                "title": item["name"],
                "content": f"{item['description']} - Origem: {item['origin']}",
                "category": "Instrumento"
            }
        elif category_name == "Arte":
            if "period" in item:  # É um azulejo
                return {
                    "title": item["name"],
                    "content": f"Período: {item['period']} - {item['description']}",
                    "category": "Azulejo"
                }
            else:  # É um artesanato
                return {
                    "title": item["name"],
                    "content": f"Região: {item['region']} - {item['description']}",
                    "category": "Artesanato"
                }
    
    def get_cultural_quiz_question(self):
        """Gera uma pergunta de quiz sobre cultura portuguesa"""
        categories = [
            ("fado", self.fado_facts),
            ("provérbio", self.proverbs),
            ("local", self.landmarks),
            ("gastronomia", self.foods),
            ("música", self.portuguese_music.fado_songs),
            ("instrumento", self.portuguese_music.traditional_instruments)
        ]
        
        category_name, category_data = random.choice(categories)
        
        if not category_data:
            return None
        
        if category_name == "fado":
            item = random.choice(category_data)
            question = f"Qual fato sobre o fado está correto?"
            correct_answer = item["content"]
            
            # Gerar respostas incorretas
            wrong_answers = []
            for _ in range(3):
                wrong_item = random.choice(category_data)
                while wrong_item["content"] == correct_answer or wrong_item["content"] in wrong_answers:
                    wrong_item = random.choice(category_data)
                wrong_answers.append(wrong_item["content"])
            
            answers = [correct_answer] + wrong_answers
            random.shuffle(answers)
            
            return {
                "question": question,
                "answers": answers,
                "correct_index": answers.index(correct_answer),
                "category": "Fado"
            }
            
        elif category_name == "provérbio":
            item = random.choice(category_data)
            question = f'Complete o provérbio: "{item["proverb"].split(",")[0]}..."'
            correct_answer = item["proverb"].split(",")[1].strip() if "," in item["proverb"] else item["proverb"]
            
            # Gerar respostas incorretas
            wrong_answers = []
            for _ in range(3):
                wrong_item = random.choice(category_data)
                wrong_part = wrong_item["proverb"].split(",")[1].strip() if "," in wrong_item["proverb"] else wrong_item["proverb"]
                while wrong_part == correct_answer or wrong_part in wrong_answers:
                    wrong_item = random.choice(category_data)
                    wrong_part = wrong_item["proverb"].split(",")[1].strip() if "," in wrong_item["proverb"] else wrong_item["proverb"]
                wrong_answers.append(wrong_part)
            
            answers = [correct_answer] + wrong_answers
            random.shuffle(answers)
            
            return {
                "question": question,
                "answers": answers,
                "correct_index": answers.index(correct_answer),
                "category": "Provérbio"
            }
            
        elif category_name == "local":
            item = random.choice(category_data)
            question = f"Onde fica {item['name']}?"
            correct_answer = item["location"]
            
            # Gerar respostas incorretas
            locations = list(set(landmark["location"] for landmark in category_data))
            wrong_answers = []
            for location in locations:
                if location != correct_answer and len(wrong_answers) < 3:
                    wrong_answers.append(location)
            
            # Se não tiver 3 respostas erradas, adicionar algumas genéricas
            generic_locations = ["Porto", "Coimbra", "Faro", "Braga", "Setúbal"]
            while len(wrong_answers) < 3:
                loc = random.choice(generic_locations)
                if loc != correct_answer and loc not in wrong_answers:
                    wrong_answers.append(loc)
            
            answers = [correct_answer] + wrong_answers
            random.shuffle(answers)
            
            return {
                "question": question,
                "answers": answers,
                "correct_index": answers.index(correct_answer),
                "category": "Geografia"
            }
            
        elif category_name == "gastronomia":
            item = random.choice(category_data)
            question = f"De qual região é típico o prato {item['name']}?"
            correct_answer = item["region"]
            
            # Gerar respostas incorretas
            regions = list(set(food["region"] for food in category_data))
            wrong_answers = []
            for region in regions:
                if region != correct_answer and len(wrong_answers) < 3:
                    wrong_answers.append(region)
            
            # Se não tiver 3 respostas erradas, adicionar algumas genéricas
            generic_regions = ["Norte", "Centro", "Sul", "Ilhas", "Beira Alta", "Trás-os-Montes"]
            while len(wrong_answers) < 3:
                reg = random.choice(generic_regions)
                if reg != correct_answer and reg not in wrong_answers:
                    wrong_answers.append(reg)
            
            answers = [correct_answer] + wrong_answers
            random.shuffle(answers)
            
            return {
                "question": question,
                "answers": answers,
                "correct_index": answers.index(correct_answer),
                "category": "Gastronomia"
            }
            
        elif category_name == "música":
            item = random.choice(category_data)
            question = f"Quem é o intérprete da canção '{item['title']}'?"
            correct_answer = item["artist"]
            
            # Gerar respostas incorretas
            artists = list(set(song["artist"] for song in category_data))
            wrong_answers = []
            for artist in artists:
                if artist != correct_answer and len(wrong_answers) < 3:
                    wrong_answers.append(artist)
            
            # Se não tiver 3 respostas erradas, adicionar algumas genéricas
            generic_artists = ["Carlos Paredes", "António Variações", "Carminho", "Ana Moura", "Camané"]
            while len(wrong_answers) < 3:
                art = random.choice(generic_artists)
                if art != correct_answer and art not in wrong_answers:
                    wrong_answers.append(art)
            
            answers = [correct_answer] + wrong_answers
            random.shuffle(answers)
            
            return {
                "question": question,
                "answers": answers,
                "correct_index": answers.index(correct_answer),
                "category": "Música"
            }
            
        elif category_name == "instrumento":
            item = random.choice(category_data)
            question = f"Qual a característica principal do instrumento '{item['name']}'?"
            correct_answer = item["description"].split(".")[0]
            
            # Gerar respostas incorretas
            wrong_answers = []
            for _ in range(3):
                wrong_item = random.choice(category_data)
                wrong_desc = wrong_item["description"].split(".")[0]
                while wrong_desc == correct_answer or wrong_desc in wrong_answers:
                    wrong_item = random.choice(category_data)
                    wrong_desc = wrong_item["description"].split(".")[0]
                wrong_answers.append(wrong_desc)
            
            answers = [correct_answer] + wrong_answers
            random.shuffle(answers)
            
            return {
                "question": question,
                "answers": answers,
                "correct_index": answers.index(correct_answer),
                "category": "Instrumentos"
            }
        
        return None
    
    def render_cultural_encyclopedia(self, screen):
        """Renderiza a enciclopédia cultural"""
        # Fundo
        pygame.draw.rect(screen, (240, 240, 240), (50, 50, self.screen_width - 100, self.screen_height - 100))
        pygame.draw.rect(screen, (0, 0, 0), (50, 50, self.screen_width - 100, self.screen_height - 100), 2)
        
        # Título
        title_text = self.font_title.render("Enciclopédia Cultural Portuguesa", True, (0, 0, 0))
        screen.blit(title_text, (self.screen_width/2 - title_text.get_width()/2, 70))
        
        # Abas de categorias
        categories = [
            ("Fado", "fado_facts"),
            ("Provérbios", "proverbs"),
            ("Locais", "landmarks"),
            ("Gastronomia", "foods"),
            ("Música", "music"),
            ("Instrumentos", "instruments"),
            ("Arte", "art")
        ]
        
        tab_width = (self.screen_width - 100) / len(categories)
        for i, (cat_name, cat_id) in enumerate(categories):
            tab_x = 50 + i * tab_width
            tab_rect = pygame.Rect(tab_x, 110, tab_width, 30)
            
            # Destacar aba selecionada
            if cat_id == self.current_category:
                pygame.draw.rect(screen, (200, 200, 255), tab_rect)
            
            pygame.draw.rect(screen, (0, 0, 0), tab_rect, 1)
            
            tab_text = self.font_small.render(cat_name, True, (0, 0, 0))
            screen.blit(tab_text, (tab_x + tab_width/2 - tab_text.get_width()/2, 115))
        
        # Área de conteúdo
        content_rect = pygame.Rect(60, 150, self.screen_width - 120, self.screen_height - 220)
        pygame.draw.rect(screen, (255, 255, 255), content_rect)
        pygame.draw.rect(screen, (0, 0, 0), content_rect, 1)
        
        # Renderizar conteúdo baseado na categoria selecionada
        if self.current_category == "fado_facts" and self.fado_facts:
            self._render_fado_facts(screen, content_rect)
        elif self.current_category == "proverbs" and self.proverbs:
            self._render_proverbs(screen, content_rect)
        elif self.current_category == "landmarks" and self.landmarks:
            self._render_landmarks(screen, content_rect)
        elif self.current_category == "foods" and self.foods:
            self._render_foods(screen, content_rect)
        elif self.current_category == "music":
            self._render_music(screen, content_rect)
        elif self.current_category == "instruments":
            self._render_instruments(screen, content_rect)
        elif self.current_category == "art":
            self._render_art(screen, content_rect)
        
        # Botões de navegação
        nav_y = self.screen_height - 60
        
        prev_button = pygame.Rect(60, nav_y, 100, 30)
        pygame.draw.rect(screen, (200, 200, 200), prev_button)
        pygame.draw.rect(screen, (0, 0, 0), prev_button, 1)
        prev_text = self.font_small.render("Anterior", True, (0, 0, 0))
        screen.blit(prev_text, (prev_button.x + prev_button.width/2 - prev_text.get_width()/2, nav_y + 5))
        
        next_button = pygame.Rect(self.screen_width - 160, nav_y, 100, 30)
        pygame.draw.rect(screen, (200, 200, 200), next_button)
        pygame.draw.rect(screen, (0, 0, 0), next_button, 1)
        next_text = self.font_small.render("Próximo", True, (0, 0, 0))
        screen.blit(next_text, (next_button.x + next_button.width/2 - next_text.get_width()/2, nav_y + 5))
        
        close_button = pygame.Rect(self.screen_width/2 - 50, nav_y, 100, 30)
        pygame.draw.rect(screen, (200, 200, 200), close_button)
        pygame.draw.rect(screen, (0, 0, 0), close_button, 1)
        close_text = self.font_small.render("Fechar", True, (0, 0, 0))
        screen.blit(close_text, (close_button.x + close_button.width/2 - close_text.get_width()/2, nav_y + 5))
    
    def _render_fado_facts(self, screen, content_rect):
        """Renderiza fatos sobre o fado"""
        if self.current_item_index < len(self.fado_facts):
            fact = self.fado_facts[self.current_item_index]
            
            # Título
            title_text = self.font_title.render(fact["title"], True, (0, 0, 0))
            screen.blit(title_text, (content_rect.x + 10, content_rect.y + 10))
            
            # Conteúdo
            content_lines = self._wrap_text(fact["content"], self.font_content, content_rect.width - 20)
            for i, line in enumerate(content_lines):
                line_text = self.font_content.render(line, True, (0, 0, 0))
                screen.blit(line_text, (content_rect.x + 10, content_rect.y + 50 + i * 30))
            
            # Contador de itens
            counter_text = self.font_small.render(f"Fato {self.current_item_index + 1} de {len(self.fado_facts)}", True, (100, 100, 100))
            screen.blit(counter_text, (content_rect.x + content_rect.width - counter_text.get_width() - 10, content_rect.y + content_rect.height - 30))
    
    def _render_proverbs(self, screen, content_rect):
        """Renderiza provérbios portugueses"""
        if self.current_item_index < len(self.proverbs):
            proverb = self.proverbs[self.current_item_index]
            
            # Provérbio
            proverb_text = self.font_title.render(f'"{proverb["proverb"]}"', True, (0, 0, 0))
            screen.blit(proverb_text, (content_rect.x + 10, content_rect.y + 10))
            
            # Significado
            meaning_title = self.font_content.render("Significado:", True, (0, 0, 0))
            screen.blit(meaning_title, (content_rect.x + 10, content_rect.y + 60))
            
            meaning_lines = self._wrap_text(proverb["meaning"], self.font_content, content_rect.width - 20)
            for i, line in enumerate(meaning_lines):
                line_text = self.font_content.render(line, True, (0, 0, 0))
                screen.blit(line_text, (content_rect.x + 10, content_rect.y + 90 + i * 30))
            
            # Equivalente
            if "equivalent" in proverb and proverb["equivalent"]:
                equiv_title = self.font_content.render("Equivalente:", True, (0, 0, 0))
                screen.blit(equiv_title, (content_rect.x + 10, content_rect.y + 150))
                
                equiv_text = self.font_content.render(proverb["equivalent"], True, (0, 0, 0))
                screen.blit(equiv_text, (content_rect.x + 10, content_rect.y + 180))
            
            # Contador de itens
            counter_text = self.font_small.render(f"Provérbio {self.current_item_index + 1} de {len(self.proverbs)}", True, (100, 100, 100))
            screen.blit(counter_text, (content_rect.x + content_rect.width - counter_text.get_width() - 10, content_rect.y + content_rect.height - 30))
    
    def _render_landmarks(self, screen, content_rect):
        """Renderiza marcos culturais"""
        if self.current_item_index < len(self.landmarks):
            landmark = self.landmarks[self.current_item_index]
            
            # Nome
            name_text = self.font_title.render(landmark["name"], True, (0, 0, 0))
            screen.blit(name_text, (content_rect.x + 10, content_rect.y + 10))
            
            # Localização
            location_text = self.font_content.render(f"Localização: {landmark['location']}", True, (0, 0, 0))
            screen.blit(location_text, (content_rect.x + 10, content_rect.y + 50))
            
            # Descrição
            desc_lines = self._wrap_text(landmark["description"], self.font_content, content_rect.width - 20)
            for i, line in enumerate(desc_lines):
                line_text = self.font_content.render(line, True, (0, 0, 0))
                screen.blit(line_text, (content_rect.x + 10, content_rect.y + 80 + i * 30))
            
            # Contador de itens
            counter_text = self.font_small.render(f"Local {self.current_item_index + 1} de {len(self.landmarks)}", True, (100, 100, 100))
            screen.blit(counter_text, (content_rect.x + content_rect.width - counter_text.get_width() - 10, content_rect.y + content_rect.height - 30))
    
    def _render_foods(self, screen, content_rect):
        """Renderiza comidas tradicionais"""
        if self.current_item_index < len(self.foods):
            food = self.foods[self.current_item_index]
            
            # Nome
            name_text = self.font_title.render(food["name"], True, (0, 0, 0))
            screen.blit(name_text, (content_rect.x + 10, content_rect.y + 10))
            
            # Região
            region_text = self.font_content.render(f"Região: {food['region']}", True, (0, 0, 0))
            screen.blit(region_text, (content_rect.x + 10, content_rect.y + 50))
            
            # Descrição
            desc_lines = self._wrap_text(food["description"], self.font_content, content_rect.width - 20)
            for i, line in enumerate(desc_lines):
                line_text = self.font_content.render(line, True, (0, 0, 0))
                screen.blit(line_text, (content_rect.x + 10, content_rect.y + 80 + i * 30))
            
            # Contador de itens
            counter_text = self.font_small.render(f"Prato {self.current_item_index + 1} de {len(self.foods)}", True, (100, 100, 100))
            screen.blit(counter_text, (content_rect.x + content_rect.width - counter_text.get_width() - 10, content_rect.y + content_rect.height - 30))
    
    def _render_music(self, screen, content_rect):
        """Renderiza informações sobre música portuguesa"""
        songs = self.portuguese_music.fado_songs
        if self.current_item_index < len(songs):
            song = songs[self.current_item_index]
            
            # Título
            title_text = self.font_title.render(song["title"], True, (0, 0, 0))
            screen.blit(title_text, (content_rect.x + 10, content_rect.y + 10))
            
            # Artista e Ano
            artist_text = self.font_content.render(f"Artista: {song['artist']} ({song['year']})", True, (0, 0, 0))
            screen.blit(artist_text, (content_rect.x + 10, content_rect.y + 50))
            
            # Descrição
            desc_lines = self._wrap_text(song["description"], self.font_content, content_rect.width - 20)
            for i, line in enumerate(desc_lines):
                line_text = self.font_content.render(line, True, (0, 0, 0))
                screen.blit(line_text, (content_rect.x + 10, content_rect.y + 80 + i * 30))
            
            # Trecho da letra
            if "lyrics_excerpt" in song:
                lyrics_title = self.font_content.render("Trecho da letra:", True, (0, 0, 0))
                screen.blit(lyrics_title, (content_rect.x + 10, content_rect.y + 150))
                
                lyrics_lines = self._wrap_text(song["lyrics_excerpt"], self.font_content, content_rect.width - 20)
                for i, line in enumerate(lyrics_lines):
                    line_text = self.font_content.render(line, True, (0, 0, 0))
                    screen.blit(line_text, (content_rect.x + 10, content_rect.y + 180 + i * 30))
            
            # Contador de itens
            counter_text = self.font_small.render(f"Música {self.current_item_index + 1} de {len(songs)}", True, (100, 100, 100))
            screen.blit(counter_text, (content_rect.x + content_rect.width - counter_text.get_width() - 10, content_rect.y + content_rect.height - 30))
    
    def _render_instruments(self, screen, content_rect):
        """Renderiza informações sobre instrumentos tradicionais portugueses"""
        instruments = self.portuguese_music.traditional_instruments
        if self.current_item_index < len(instruments):
            instrument = instruments[self.current_item_index]
            
            # Nome
            name_text = self.font_title.render(instrument["name"], True, (0, 0, 0))
            screen.blit(name_text, (content_rect.x + 10, content_rect.y + 10))
            
            # Descrição
            desc_lines = self._wrap_text(instrument["description"], self.font_content, content_rect.width - 20)
            for i, line in enumerate(desc_lines):
                line_text = self.font_content.render(line, True, (0, 0, 0))
                screen.blit(line_text, (content_rect.x + 10, content_rect.y + 50 + i * 30))
            
            # Origem
            origin_title = self.font_content.render("Origem:", True, (0, 0, 0))
            screen.blit(origin_title, (content_rect.x + 10, content_rect.y + 120))
            
            origin_lines = self._wrap_text(instrument["origin"], self.font_content, content_rect.width - 20)
            for i, line in enumerate(origin_lines):
                line_text = self.font_content.render(line, True, (0, 0, 0))
                screen.blit(line_text, (content_rect.x + 10, content_rect.y + 150 + i * 30))
            
            # Técnica
            technique_title = self.font_content.render("Técnica de execução:", True, (0, 0, 0))
            screen.blit(technique_title, (content_rect.x + 10, content_rect.y + 210))
            
            technique_lines = self._wrap_text(instrument["playing_technique"], self.font_content, content_rect.width - 20)
            for i, line in enumerate(technique_lines):
                line_text = self.font_content.render(line, True, (0, 0, 0))
                screen.blit(line_text, (content_rect.x + 10, content_rect.y + 240 + i * 30))
            
            # Contador de itens
            counter_text = self.font_small.render(f"Instrumento {self.current_item_index + 1} de {len(instruments)}", True, (100, 100, 100))
            screen.blit(counter_text, (content_rect.x + content_rect.width - counter_text.get_width() - 10, content_rect.y + content_rect.height - 30))
    
    def _render_art(self, screen, content_rect):
        """Renderiza informações sobre arte portuguesa"""
        # Alternar entre azulejos e artesanato
        if self.current_item_index % 2 == 0:
            # Azulejos
            azulejos = self.portuguese_art.azulejos
            azulejo_index = self.current_item_index // 2
            if azulejo_index < len(azulejos):
                azulejo = azulejos[azulejo_index]
                
                # Nome
                name_text = self.font_title.render(azulejo["name"], True, (0, 0, 0))
                screen.blit(name_text, (content_rect.x + 10, content_rect.y + 10))
                
                # Período
                period_text = self.font_content.render(f"Período: {azulejo['period']}", True, (0, 0, 0))
                screen.blit(period_text, (content_rect.x + 10, content_rect.y + 50))
                
                # Descrição
                desc_lines = self._wrap_text(azulejo["description"], self.font_content, content_rect.width - 20)
                for i, line in enumerate(desc_lines):
                    line_text = self.font_content.render(line, True, (0, 0, 0))
                    screen.blit(line_text, (content_rect.x + 10, content_rect.y + 80 + i * 30))
                
                # Locais
                locations_title = self.font_content.render("Onde encontrar:", True, (0, 0, 0))
                screen.blit(locations_title, (content_rect.x + 10, content_rect.y + 150))
                
                for i, location in enumerate(azulejo["locations"]):
                    location_text = self.font_content.render(f"- {location}", True, (0, 0, 0))
                    screen.blit(location_text, (content_rect.x + 10, content_rect.y + 180 + i * 30))
                
                # Contador de itens
                counter_text = self.font_small.render(f"Azulejo {azulejo_index + 1} de {len(azulejos)}", True, (100, 100, 100))
                screen.blit(counter_text, (content_rect.x + content_rect.width - counter_text.get_width() - 10, content_rect.y + content_rect.height - 30))
        else:
            # Artesanato
            crafts = self.portuguese_art.traditional_crafts
            craft_index = self.current_item_index // 2
            if craft_index < len(crafts):
                craft = crafts[craft_index]
                
                # Nome
                name_text = self.font_title.render(craft["name"], True, (0, 0, 0))
                screen.blit(name_text, (content_rect.x + 10, content_rect.y + 10))
                
                # Região
                region_text = self.font_content.render(f"Região: {craft['region']}", True, (0, 0, 0))
                screen.blit(region_text, (content_rect.x + 10, content_rect.y + 50))
                
                # Descrição
                desc_lines = self._wrap_text(craft["description"], self.font_content, content_rect.width - 20)
                for i, line in enumerate(desc_lines):
                    line_text = self.font_content.render(line, True, (0, 0, 0))
                    screen.blit(line_text, (content_rect.x + 10, content_rect.y + 80 + i * 30))
                
                # Itens notáveis
                items_title = self.font_content.render("Itens notáveis:", True, (0, 0, 0))
                screen.blit(items_title, (content_rect.x + 10, content_rect.y + 150))
                
                for i, item in enumerate(craft["notable_items"]):
                    item_text = self.font_content.render(f"- {item}", True, (0, 0, 0))
                    screen.blit(item_text, (content_rect.x + 10, content_rect.y + 180 + i * 30))
                
                # Contador de itens
                counter_text = self.font_small.render(f"Artesanato {craft_index + 1} de {len(crafts)}", True, (100, 100, 100))
                screen.blit(counter_text, (content_rect.x + content_rect.width - counter_text.get_width() - 10, content_rect.y + content_rect.height - 30))
    
    def _wrap_text(self, text, font, max_width):
        """Quebra o texto em linhas para caber na largura especificada"""
        words = text.split(' ')
        lines = []
        current_line = []
        
        for word in words:
            # Testar se adicionar esta palavra excede a largura máxima
            test_line = ' '.join(current_line + [word])
            test_width = font.size(test_line)[0]
            
            if test_width <= max_width:
                current_line.append(word)
            else:
                # Se a linha atual não estiver vazia, adicioná-la às linhas
                if current_line:
                    lines.append(' '.join(current_line))
                    current_line = [word]
                else:
                    # Se a palavra sozinha é maior que a largura máxima, adicioná-la mesmo assim
                    lines.append(word)
                    current_line = []
        
        # Adicionar a última linha
        if current_line:
            lines.append(' '.join(current_line))
        
        return lines
    
    def handle_encyclopedia_event(self, event):
        """Processa eventos da enciclopédia cultural"""
        if event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 1:  # Botão esquerdo do mouse
                # Verificar cliques nas abas
                categories = [
                    ("Fado", "fado_facts"),
                    ("Provérbios", "proverbs"),
                    ("Locais", "landmarks"),
                    ("Gastronomia", "foods"),
                    ("Música", "music"),
                    ("Instrumentos", "instruments"),
                    ("Arte", "art")
                ]
                
                tab_width = (self.screen_width - 100) / len(categories)
                for i, (cat_name, cat_id) in enumerate(categories):
                    tab_x = 50 + i * tab_width
                    tab_rect = pygame.Rect(tab_x, 110, tab_width, 30)
                    
                    if tab_rect.collidepoint(event.pos):
                        self.current_category = cat_id
                        self.current_item_index = 0
                        return True
                
                # Verificar cliques nos botões de navegação
                nav_y = self.screen_height - 60
                
                prev_button = pygame.Rect(60, nav_y, 100, 30)
                if prev_button.collidepoint(event.pos):
                    self._navigate_prev()
                    return True
                
                next_button = pygame.Rect(self.screen_width - 160, nav_y, 100, 30)
                if next_button.collidepoint(event.pos):
                    self._navigate_next()
                    return True
                
                close_button = pygame.Rect(self.screen_width/2 - 50, nav_y, 100, 30)
                if close_button.collidepoint(event.pos):
                    return False  # Sinaliza para fechar a enciclopédia
        
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_LEFT:
                self._navigate_prev()
                return True
            elif event.key == pygame.K_RIGHT:
                self._navigate_next()
                return True
            elif event.key == pygame.K_ESCAPE:
                return False  # Sinaliza para fechar a enciclopédia
        
        return True  # Continuar mostrando a enciclopédia
    
    def _navigate_prev(self):
        """Navega para o item anterior"""
        if self.current_category == "fado_facts":
            self.current_item_index = (self.current_item_index - 1) % len(self.fado_facts) if self.fado_facts else 0
        elif self.current_category == "proverbs":
            self.current_item_index = (self.current_item_index - 1) % len(self.proverbs) if self.proverbs else 0
        elif self.current_category == "landmarks":
            self.current_item_index = (self.current_item_index - 1) % len(self.landmarks) if self.landmarks else 0
        elif self.current_category == "foods":
            self.current_item_index = (self.current_item_index - 1) % len(self.foods) if self.foods else 0
        elif self.current_category == "music":
            self.current_item_index = (self.current_item_index - 1) % len(self.portuguese_music.fado_songs)
        elif self.current_category == "instruments":
            self.current_item_index = (self.current_item_index - 1) % len(self.portuguese_music.traditional_instruments)
        elif self.current_category == "art":
            total_items = len(self.portuguese_art.azulejos) * 2 + len(self.portuguese_art.traditional_crafts) * 2
            self.current_item_index = (self.current_item_index - 1) % total_items
    
    def _navigate_next(self):
        """Navega para o próximo item"""
        if self.current_category == "fado_facts":
            self.current_item_index = (self.current_item_index + 1) % len(self.fado_facts) if self.fado_facts else 0
        elif self.current_category == "proverbs":
            self.current_item_index = (self.current_item_index + 1) % len(self.proverbs) if self.proverbs else 0
        elif self.current_category == "landmarks":
            self.current_item_index = (self.current_item_index + 1) % len(self.landmarks) if self.landmarks else 0
        elif self.current_category == "foods":
            self.current_item_index = (self.current_item_index + 1) % len(self.foods) if self.foods else 0
        elif self.current_category == "music":
            self.current_item_index = (self.current_item_index + 1) % len(self.portuguese_music.fado_songs)
        elif self.current_category == "instruments":
            self.current_item_index = (self.current_item_index + 1) % len(self.portuguese_music.traditional_instruments)
        elif self.current_category == "art":
            total_items = len(self.portuguese_art.azulejos) * 2 + len(self.portuguese_art.traditional_crafts) * 2
            self.current_item_index = (self.current_item_index + 1) % total_items
