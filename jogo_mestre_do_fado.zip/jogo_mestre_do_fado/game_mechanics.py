import pygame
import os
import random

class MusicRhythmSystem:
    def __init__(self, screen_width, screen_height):
        self.screen_width = screen_width
        self.screen_height = screen_height
        self.target_line_y = screen_height - 100
        self.lanes = 4
        self.lane_width = screen_width // self.lanes
        
        # Configurações do jogo
        self.score = 0
        self.combo = 0
        self.max_combo = 0
        self.notes = []
        self.hit_animations = []
        
        # Configurações de dificuldade
        self.note_speed = 5
        self.hit_window = 30  # Pixels de distância para acertar
        
        # Músicas disponíveis
        self.songs = {
            "fado_basico": {
                "name": "Fado Básico",
                "bpm": 80,
                "difficulty": 1,
                "patterns": self._generate_basic_patterns()
            },
            "fado_lisboa": {
                "name": "Fado de Lisboa",
                "bpm": 90,
                "difficulty": 2,
                "patterns": self._generate_intermediate_patterns()
            },
            "cante_alentejano": {
                "name": "Cante Alentejano",
                "bpm": 70,
                "difficulty": 2,
                "patterns": self._generate_intermediate_patterns()
            },
            "fado_mestre": {
                "name": "Fado do Mestre",
                "bpm": 100,
                "difficulty": 3,
                "patterns": self._generate_advanced_patterns()
            }
        }
        
        # Configurações da música atual
        self.current_song = None
        self.current_pattern_index = 0
        self.last_note_time = 0
        self.song_started = False
        self.song_finished = False
        
        # Fontes
        self.font = pygame.font.Font(None, 36)
        self.small_font = pygame.font.Font(None, 24)
        
    def _generate_basic_patterns(self):
        """Gera padrões básicos para iniciantes"""
        patterns = []
        
        # Padrão 1: Notas simples em sequência
        pattern1 = []
        for i in range(16):
            lane = i % 4
            pattern1.append({"time": i * 1000, "lane": lane, "type": "normal"})
        patterns.append(pattern1)
        
        # Padrão 2: Alternando entre duas pistas
        pattern2 = []
        for i in range(16):
            lane = 0 if i % 2 == 0 else 2
            pattern2.append({"time": i * 1000, "lane": lane, "type": "normal"})
        patterns.append(pattern2)
        
        # Padrão 3: Grupos de duas notas
        pattern3 = []
        for i in range(8):
            lane1 = i % 4
            lane2 = (i + 1) % 4
            pattern3.append({"time": i * 2000, "lane": lane1, "type": "normal"})
            pattern3.append({"time": i * 2000 + 500, "lane": lane2, "type": "normal"})
        patterns.append(pattern3)
        
        return patterns
    
    def _generate_intermediate_patterns(self):
        """Gera padrões de dificuldade intermediária"""
        patterns = []
        
        # Padrão 1: Sequência com espaços
        pattern1 = []
        for i in range(20):
            if i % 5 != 4:  # Pula a cada 5ª nota
                lane = i % 4
                pattern1.append({"time": i * 800, "lane": lane, "type": "normal"})
        patterns.append(pattern1)
        
        # Padrão 2: Notas duplas ocasionais
        pattern2 = []
        for i in range(16):
            lane = i % 4
            pattern2.append({"time": i * 1000, "lane": lane, "type": "normal"})
            if i % 4 == 0:  # A cada 4 notas, adiciona uma nota dupla
                pattern2.append({"time": i * 1000, "lane": (lane + 2) % 4, "type": "normal"})
        patterns.append(pattern2)
        
        # Padrão 3: Ritmo variado
        pattern3 = []
        times = [0, 500, 1200, 1800, 2200, 2800, 3500, 4000]
        for i, time in enumerate(times):
            lane = i % 4
            pattern3.append({"time": time, "lane": lane, "type": "normal"})
        patterns.append(pattern3)
        
        return patterns
    
    def _generate_advanced_patterns(self):
        """Gera padrões avançados para jogadores experientes"""
        patterns = []
        
        # Padrão 1: Notas rápidas em sequência
        pattern1 = []
        for i in range(32):
            lane = i % 4
            pattern1.append({"time": i * 500, "lane": lane, "type": "normal"})
        patterns.append(pattern1)
        
        # Padrão 2: Notas duplas e triplas
        pattern2 = []
        for i in range(12):
            base_time = i * 1200
            if i % 3 == 0:  # Nota única
                pattern2.append({"time": base_time, "lane": i % 4, "type": "normal"})
            elif i % 3 == 1:  # Nota dupla
                pattern2.append({"time": base_time, "lane": i % 4, "type": "normal"})
                pattern2.append({"time": base_time, "lane": (i + 2) % 4, "type": "normal"})
            else:  # Nota tripla
                pattern2.append({"time": base_time, "lane": 0, "type": "normal"})
                pattern2.append({"time": base_time, "lane": 1, "type": "normal"})
                pattern2.append({"time": base_time, "lane": 2, "type": "normal"})
        patterns.append(pattern2)
        
        # Padrão 3: Ritmo complexo com notas especiais
        pattern3 = []
        times = [0, 400, 800, 1000, 1400, 1800, 2000, 2200, 2600, 3000, 3400, 3800]
        for i, time in enumerate(times):
            lane = i % 4
            note_type = "special" if i % 6 == 0 else "normal"
            pattern3.append({"time": time, "lane": lane, "type": note_type})
        patterns.append(pattern3)
        
        return patterns
    
    def start_song(self, song_key, difficulty="normal"):
        """Inicia uma música para o minigame de ritmo"""
        if song_key in self.songs:
            self.current_song = self.songs[song_key]
            self.score = 0
            self.combo = 0
            self.max_combo = 0
            self.notes = []
            self.hit_animations = []
            self.current_pattern_index = 0
            self.last_note_time = pygame.time.get_ticks()
            self.song_started = True
            self.song_finished = False
            
            # Ajusta dificuldade
            if difficulty == "easy":
                self.note_speed = 3
                self.hit_window = 40
            elif difficulty == "normal":
                self.note_speed = 5
                self.hit_window = 30
            elif difficulty == "hard":
                self.note_speed = 7
                self.hit_window = 20
            
            print(f"Iniciando música: {self.current_song['name']} (Dificuldade: {difficulty})")
            return True
        else:
            print(f"Música não encontrada: {song_key}")
            return False
    
    def update(self, current_time):
        """Atualiza o estado do jogo de ritmo"""
        if not self.song_started or self.song_finished:
            return
        
        # Gerar notas baseadas no padrão atual
        if self.current_song:
            current_pattern = self.current_song["patterns"][self.current_pattern_index % len(self.current_song["patterns"])]
            
            # Ajustar tempo baseado no BPM da música
            time_scale = 60000 / self.current_song["bpm"]
            
            for note_data in current_pattern:
                # Verificar se é hora de criar esta nota
                note_time = self.last_note_time + (note_data["time"] * time_scale / 1000)
                
                if current_time >= note_time and note_data not in self.notes:
                    # Calcular posição X baseada na pista
                    lane = note_data["lane"]
                    x = (lane + 0.5) * self.lane_width
                    
                    # Criar nota
                    self.notes.append({
                        "x": x,
                        "y": 0,
                        "lane": lane,
                        "type": note_data["type"],
                        "speed": self.note_speed,
                        "active": True
                    })
            
            # Verificar se todas as notas do padrão foram processadas
            all_notes_processed = True
            for note_data in current_pattern:
                note_time = self.last_note_time + (note_data["time"] * time_scale / 1000)
                if current_time < note_time:
                    all_notes_processed = False
                    break
            
            # Se todas as notas foram processadas e não há mais notas ativas, avançar para o próximo padrão
            if all_notes_processed and not any(note["active"] for note in self.notes):
                self.current_pattern_index += 1
                self.last_note_time = current_time
                
                # Verificar se chegamos ao fim da música (3 padrões)
                if self.current_pattern_index >= 3:
                    self.song_finished = True
        
        # Atualizar posição das notas
        for note in self.notes:
            if note["active"]:
                note["y"] += note["speed"]
                
                # Verificar se a nota passou da linha alvo
                if note["y"] > self.target_line_y + 50:
                    note["active"] = False
                    self.combo = 0
        
        # Remover notas inativas
        self.notes = [note for note in self.notes if note["active"]]
        
        # Atualizar animações de acerto
        self.hit_animations = [anim for anim in self.hit_animations if current_time - anim["time"] < 500]
    
    def render(self, surface):
        """Renderiza o jogo de ritmo"""
        # Desenhar fundo
        surface.fill((0, 0, 0))
        
        # Desenhar título da música
        if self.current_song:
            title_text = self.font.render(self.current_song["name"], True, (255, 255, 255))
            surface.blit(title_text, (20, 20))
        
        # Desenhar linhas de pista
        for i in range(self.lanes + 1):
            x = i * self.lane_width
            pygame.draw.line(surface, (50, 50, 50), (x, 0), (x, self.screen_height), 2)
        
        # Desenhar linha alvo
        pygame.draw.line(surface, (255, 255, 255), (0, self.target_line_y), 
                         (self.screen_width, self.target_line_y), 3)
        
        # Desenhar marcadores de pista na linha alvo
        for i in range(self.lanes):
            x = (i + 0.5) * self.lane_width
            pygame.draw.circle(surface, (100, 100, 100), (int(x), self.target_line_y), 25)
            
            # Desenhar letra da tecla
            key_letter = ["A", "S", "D", "F"][i]
            text = self.small_font.render(key_letter, True, (255, 255, 255))
            text_rect = text.get_rect(center=(int(x), self.target_line_y))
            surface.blit(text, text_rect)
        
        # Desenhar notas
        for note in self.notes:
            if note["active"]:
                # Cor baseada no tipo de nota
                if note["type"] == "normal":
                    color = (0, 0, 255)  # Azul
                elif note["type"] == "hold":
                    color = (0, 255, 0)  # Verde
                elif note["type"] == "special":
                    color = (255, 215, 0)  # Dourado
                else:
                    color = (255, 0, 0)  # Vermelho
                
                # Desenhar nota
                pygame.draw.rect(surface, color, 
                                (note["x"] - 25, note["y"] - 10, 50, 20), 
                                border_radius=5)
                pygame.draw.rect(surface, (255, 255, 255), 
                                (note["x"] - 25, note["y"] - 10, 50, 20), 
                                2, border_radius=5)
        
        # Desenhar animações de acerto
        for anim in self.hit_animations:
            alpha = 255 - int(255 * (pygame.time.get_ticks() - anim["time"]) / 500)
            text = anim["text"]
            text.set_alpha(alpha)
            surface.blit(text, anim["pos"])
        
        # Desenhar pontuação e combo
        score_text = self.font.render(f"Pontuação: {int(self.score)}", True, (255, 255, 255))
        combo_text = self.font.render(f"Combo: {self.combo}x", True, (255, 255, 255))
        
        surface.blit(score_text, (20, 60))
        surface.blit(combo_text, (20, 100))
        
        # Mostrar mensagem de conclusão se a música terminou
        if self.song_finished:
            finish_text = self.font.render("Música Concluída!", True, (255, 255, 255))
            finish_rect = finish_text.get_rect(center=(self.screen_width/2, self.screen_height/2 - 50))
            surface.blit(finish_text, finish_rect)
            
            score_summary = self.font.render(f"Pontuação Final: {int(self.score)}", True, (255, 255, 255))
            score_rect = score_summary.get_rect(center=(self.screen_width/2, self.screen_height/2))
            surface.blit(score_summary, score_rect)
            
            combo_summary = self.font.render(f"Combo Máximo: {self.max_combo}x", True, (255, 255, 255))
            combo_rect = combo_summary.get_rect(center=(self.screen_width/2, self.screen_height/2 + 50))
            surface.blit(combo_summary, combo_rect)
            
            continue_text = self.small_font.render("Pressione ESPAÇO para continuar", True, (255, 255, 255))
            continue_rect = continue_text.get_rect(center=(self.screen_width/2, self.screen_height/2 + 100))
            surface.blit(continue_text, continue_rect)
    
    def check_hit(self, lane):
        """Verifica se o jogador acertou uma nota"""
        hit_note = None
        hit_distance = float('inf')
        
        # Procura a nota mais próxima da linha alvo na pista especificada
        for note in self.notes:
            if note["active"] and note["lane"] == lane:
                distance = abs(note["y"] - self.target_line_y)
                if distance < self.hit_window and distance < hit_distance:
                    hit_note = note
                    hit_distance = distance
        
        if hit_note:
            # Calcula pontuação baseada na precisão
            if hit_distance < self.hit_window * 0.3:
                points = 100
                rating = "Perfeito!"
                color = (255, 215, 0)  # Dourado
                multiplier = 1.5
            elif hit_distance < self.hit_window * 0.6:
                points = 50
                rating = "Bom!"
                color = (0, 255, 0)  # Verde
                multiplier = 1.0
            else:
                points = 10
                rating = "Ok"
                color = (0, 0, 255)  # Azul
                multiplier = 0.5
            
            # Bônus para notas especiais
            if hit_note["type"] == "special":
                points *= 2
                rating = "Especial!"
                color = (255, 215, 0)  # Dourado
            
            # Adiciona pontos e aumenta combo
            self.score += points * (1 + self.combo * 0.1)  # Bônus de combo
            self.combo += 1
            
            if self.combo > self.max_combo:
                self.max_combo = self.combo
            
            # Cria animação de acerto
            font = pygame.font.Font(None, 24)
            text = font.render(rating, True, color)
            x = (lane + 0.5) * self.lane_width
            pos = text.get_rect(center=(int(x), self.target_line_y - 30))
            
            self.hit_animations.append({
                "text": text,
                "pos": pos,
                "time": pygame.time.get_ticks()
            })
            
            # Remove a nota acertada
            hit_note["active"] = False
            self.notes = [note for note in self.notes if note["active"]]
            return True
        
        return False

class QuestSystem:
    def __init__(self):
        self.quests = {
            "tutorial": {
                "title": "Primeiros Passos",
                "description": "Aprenda os básicos da guitarra portuguesa com Mestre António.",
                "objectives": [
                    {"id": "talk_to_antonio", "description": "Fale com Mestre António", "completed": False},
                    {"id": "learn_basic_chord", "description": "Aprenda o acorde básico", "completed": False},
                    {"id": "play_basic_rhythm", "description": "Complete o minigame de ritmo básico", "completed": False}
                ],
                "reward": {"reputation": 10, "guitar_skill": 1},
                "completed": False,
                "location": "aldeia"
            },
            "repair_guitar": {
                "title": "Restaurando a Herança",
                "description": "Ajude Mestre António a restaurar a guitarra do seu avô.",
                "objectives": [
                    {"id": "find_materials", "description": "Encontre materiais para o reparo", "completed": False},
                    {"id": "help_antonio", "description": "Ajude Mestre António no reparo", "completed": False},
                    {"id": "test_guitar", "description": "Teste a guitarra restaurada", "completed": False}
                ],
                "reward": {"reputation": 20, "guitar_skill": 1, "item": "restored_guitar"},
                "completed": False,
                "location": "aldeia",
                "prerequisite": "tutorial"
            },
            "lisboa_journey": {
                "title": "Jornada a Lisboa",
                "description": "Viaje para Lisboa para aprender mais sobre o fado.",
                "objectives": [
                    {"id": "reach_lisboa", "description": "Chegue a Lisboa", "completed": False},
                    {"id": "find_ana", "description": "Encontre Ana, a fadista", "completed": False},
                    {"id": "learn_lisboa_style", "description": "Aprenda o estilo de fado lisboeta", "completed": False}
                ],
                "reward": {"reputation": 30, "guitar_skill": 1, "song": "fado_lisboa"},
                "completed": False,
                "location": "lisboa",
                "prerequisite": "repair_guitar"
            },
            "first_performance": {
                "title": "Primeira Apresentação",
                "description": "Faça sua primeira apresentação em uma casa de fado.",
                "objectives": [
                    {"id": "prepare_song", "description": "Prepare uma música para apresentação", "completed": False},
                    {"id": "visit_fado_house", "description": "Visite a Casa de Fado", "completed": False},
                    {"id": "perform_song", "description": "Apresente-se na Casa de Fado", "completed": False}
                ],
                "reward": {"reputation": 50, "guitar_skill": 2, "song": "fado_mestre"},
                "completed": False,
                "location": "casa_fado",
                "prerequisite": "lisboa_journey"
            },
            "master_quest": {
                "title": "O Verdadeiro Mestre",
                "description": "Prove seu valor como um verdadeiro Mestre do Fado.",
                "objectives": [
                    {"id": "master_all_songs", "description": "Domine todas as músicas", "completed": False},
                    {"id": "gain_reputation", "description": "Alcance 100 pontos de reputação", "completed": False},
                    {"id": "final_performance", "description": "Faça a apresentação final", "completed": False}
                ],
                "reward": {"title": "Mestre do Fado", "ending": True},
                "completed": False,
                "location": "casa_fado",
                "prerequisite": "first_performance"
            }
        }
        
        self.active_quests = []
        self.completed_quests = []
    
    def start_quest(self, quest_id):
        """Inicia uma nova missão"""
        if quest_id in self.quests and quest_id not in self.active_quests:
            # Verificar pré-requisitos
            prerequisite = self.quests[quest_id].get("prerequisite")
            if prerequisite and prerequisite not in self.completed_quests:
                print(f"Não pode iniciar a missão {quest_id}. Complete {prerequisite} primeiro.")
                return False
            
            self.active_quests.append(quest_id)
            print(f"Missão iniciada: {self.quests[quest_id]['title']}")
            return True
        return False
    
    def complete_objective(self, quest_id, objective_id):
        """Marca um objetivo como concluído"""
        if quest_id in self.quests and quest_id in self.active_quests:
            quest = self.quests[quest_id]
            for objective in quest["objectives"]:
                if objective["id"] == objective_id and not objective["completed"]:
                    objective["completed"] = True
                    print(f"Objetivo concluído: {objective['description']}")
                    
                    # Verificar se todos os objetivos foram concluídos
                    if all(obj["completed"] for obj in quest["objectives"]):
                        self.complete_quest(quest_id)
                    
                    return True
        return False
    
    def complete_quest(self, quest_id):
        """Marca uma missão como concluída e concede recompensas"""
        if quest_id in self.quests and quest_id in self.active_quests:
            self.quests[quest_id]["completed"] = True
            self.active_quests.remove(quest_id)
            self.completed_quests.append(quest_id)
            
            print(f"Missão concluída: {self.quests[quest_id]['title']}")
            print(f"Recompensas: {self.quests[quest_id]['reward']}")
            
            return self.quests[quest_id]["reward"]
        return None
    
    def get_available_quests(self, location):
        """Retorna missões disponíveis em uma localização"""
        available = []
        for quest_id, quest in self.quests.items():
            if quest["location"] == location and not quest["completed"] and quest_id not in self.active_quests:
                # Verificar pré-requisitos
                prerequisite = quest.get("prerequisite")
                if not prerequisite or prerequisite in self.completed_quests:
                    available.append(quest_id)
        return available
    
    def get_active_quests(self):
        """Retorna as missões ativas"""
        return [self.quests[quest_id] for quest_id in self.active_quests]
    
    def get_quest_details(self, quest_id):
        """Retorna detalhes de uma missão específica"""
        return self.quests.get(quest_id)

class DialogueSystem:
    def __init__(self):
        self.dialogues = {
            "mestre_antonio_intro": {
                "speaker": "Mestre António",
                "lines": [
                    "Ah, você deve ser Miguel! Ouvi falar que está interessado em aprender sobre a guitarra portuguesa.",
                    "Essa guitarra... pertenceu ao seu avô, não é? Posso ver que precisa de alguns reparos.",
                    "O fado está no seu sangue, jovem. Seu avô era um grande fadista.",
                    "Se quiser, posso te ensinar os básicos e ajudar a restaurar este instrumento."
                ],
                "responses": [
                    {"text": "Sim, quero aprender tudo sobre o fado.", "next": "mestre_antonio_accept"},
                    {"text": "Talvez mais tarde.", "next": "mestre_antonio_decline"}
                ]
            },
            "mestre_antonio_accept": {
                "speaker": "Mestre António",
                "lines": [
                    "Excelente! Vamos começar com os acordes básicos.",
                    "A guitarra portuguesa tem uma afinação única e uma técnica de dedilhado especial.",
                    "Primeiro, precisamos restaurar este instrumento. Vou precisar de alguns materiais."
                ],
                "responses": [
                    {"text": "Quais materiais você precisa?", "next": "mestre_antonio_materials", "trigger": "start_quest:repair_guitar"},
                    {"text": "Vamos começar com as lições básicas primeiro.", "next": "mestre_antonio_lesson", "trigger": "start_quest:tutorial"}
                ]
            },
            "mestre_antonio_decline": {
                "speaker": "Mestre António",
                "lines": [
                    "Compreendo. O caminho do fado exige dedicação.",
                    "Quando estiver pronto, estarei aqui."
                ],
                "responses": [
                    {"text": "Voltarei em breve.", "next": None}
                ]
            },
            "mestre_antonio_materials": {
                "speaker": "Mestre António",
                "lines": [
                    "Precisarei de cordas novas, madeira de qualidade para reparar algumas rachaduras, e verniz especial.",
                    "As cordas podem ser encontradas na loja de música em Lisboa.",
                    "A madeira... talvez possamos encontrar um bom pedaço de madeira de oliveira por aqui mesmo.",
                    "Quanto ao verniz, tenho um pouco em minha oficina."
                ],
                "responses": [
                    {"text": "Vou procurar esses materiais.", "next": None, "trigger": "objective:repair_guitar:find_materials"}
                ]
            },
            "mestre_antonio_lesson": {
                "speaker": "Mestre António",
                "lines": [
                    "Muito bem! Vamos começar com a postura correta para segurar a guitarra.",
                    "A guitarra portuguesa se apoia no antebraço direito, diferente da guitarra clássica.",
                    "Os dedos da mão direita usam unhas para dedilhar as cordas, criando o som característico.",
                    "Vamos praticar um ritmo simples. Preste atenção e tente reproduzir."
                ],
                "responses": [
                    {"text": "Estou pronto para praticar.", "next": None, "trigger": "start_rhythm_game:fado_basico"}
                ]
            },
            "ana_intro": {
                "speaker": "Ana",
                "lines": [
                    "Olá! Você deve ser Miguel, não é? Mestre António me falou sobre você.",
                    "Sou Ana, fadista aqui em Lisboa. Ouvi dizer que você está aprendendo a tocar guitarra portuguesa.",
                    "O fado de Lisboa tem um estilo próprio, diferente do que você pode ter ouvido no Alentejo.",
                    "Se quiser, posso te mostrar algumas técnicas e levá-lo a uma casa de fado autêntica."
                ],
                "responses": [
                    {"text": "Adoraria aprender o estilo lisboeta.", "next": "ana_accept", "trigger": "objective:lisboa_journey:find_ana"},
                    {"text": "Estou apenas explorando por enquanto.", "next": "ana_decline"}
                ]
            },
            "ana_accept": {
                "speaker": "Ana",
                "lines": [
                    "Maravilhoso! O fado lisboeta tem uma expressão única, cheia de saudade e emoção.",
                    "Vamos começar com uma música tradicional. Observe como faço o acompanhamento.",
                    "A guitarra portuguesa dialoga com a voz, é quase como uma conversa musical."
                ],
                "responses": [
                    {"text": "Estou pronto para aprender.", "next": None, "trigger": "start_rhythm_game:fado_lisboa"},
                    {"text": "Pode me falar mais sobre a história do fado em Lisboa?", "next": "ana_history"}
                ]
            },
            "ana_decline": {
                "speaker": "Ana",
                "lines": [
                    "Claro, entendo. Lisboa tem muito a oferecer.",
                    "Quando quiser conhecer mais sobre o fado, me procure na Casa de Fado à noite."
                ],
                "responses": [
                    {"text": "Obrigado, voltarei em breve.", "next": None}
                ]
            },
            "ana_history": {
                "speaker": "Ana",
                "lines": [
                    "O fado nasceu aqui em Lisboa, nos bairros populares como Alfama e Mouraria.",
                    "No início, era cantado em tabernas, por marinheiros e pessoas do povo.",
                    "Amália Rodrigues foi quem elevou o fado ao status de arte reconhecida mundialmente.",
                    "Hoje, o fado é Patrimônio Cultural Imaterial da Humanidade pela UNESCO."
                ],
                "responses": [
                    {"text": "Fascinante! Estou pronto para aprender a tocar.", "next": None, "trigger": "start_rhythm_game:fado_lisboa"},
                    {"text": "Obrigado pela explicação. Voltarei mais tarde.", "next": None}
                ]
            }
        }
    
    def get_dialogue(self, dialogue_id):
        """Retorna um diálogo específico"""
        return self.dialogues.get(dialogue_id)
    
    def process_response(self, dialogue_id, response_index):
        """Processa a resposta selecionada pelo jogador"""
        if dialogue_id in self.dialogues:
            dialogue = self.dialogues[dialogue_id]
            if 0 <= response_index < len(dialogue["responses"]):
                response = dialogue["responses"][response_index]
                
                # Verificar se há gatilhos para executar
                if "trigger" in response:
                    trigger = response["trigger"]
                    return {
                        "next_dialogue": response["next"],
                        "trigger": trigger
                    }
                
                return {
                    "next_dialogue": response["next"],
                    "trigger": None
                }
        
        return None
